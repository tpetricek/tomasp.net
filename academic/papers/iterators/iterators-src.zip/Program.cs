﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FunctionalCSharp;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace MonadsInCSharp
{
  #region Basic stuff

  /// <summary>
  /// Represents a type with no value - alternative to C# void in 
  /// situations where void can't be used
  /// </summary>
  public class Unit
  {
    private Unit() { }
    static Unit()
    {
      Value = new Unit();
    }
    public static Unit Value { get; private set; }
  }

  class MonadStep<T>
  {
    private bool valueAvailable = false;
    private T value;

    public T Value
    {
      get
      {
        if (!valueAvailable) throw new InvalidOperationException("Accessing 'Value' before 'yield return' is not allowed.");
        return value;
      }
      protected set
      {
        valueAvailable = true;
        this.value = value;
      }
    }

    protected Func<T, R> MakeContinuation<R>(Func<R> f)
    {
      return v => { this.Value = v; return f(); };
    }
  }

  class MonadReturn<T>
  {
    public MonadReturn(T value) {
      this.value = value;
    }

    private T value;

    protected R GetResult<R>() {
      try {
        return (R)(object)value;
      } catch {
        throw new InvalidOperationException("Cannot convert the returned value to the desired return type.");
      }
    }
  }

  #endregion

  #region Option monad

  static class OptionMonad {
    public static Option<R> Bind<T, R>(this Option<T> input, Func<T, Option<R>> cont) {
      T res;
      if (input.MatchSome(out res)) return cont(res);
      else return Option.None<R>();
    }

    public static Option<R> Return<R>(R value) {
      return Option.Some(value);
    }

    public static Option<Unit> Zero {
      get { return Option.Some(Unit.Value); }
    }
  }

  interface IOption {
    Option<R> BindStep<R>(Func<Option<R>> cont);
  }

  class OptionStep<T> : MonadStep<T>, IOption {
    private readonly Option<T> input;
    public OptionStep(Option<T> input) {
      this.input = input;
    }
    public Option<R> BindStep<R>(Func<Option<R>> cont) {
      return OptionMonad.Bind(input, MakeContinuation(cont));
    }
  }

  class OptionResult<T> : MonadReturn<T>, IOption
  {
    public OptionResult(T value) : base(value) { }

    public Option<R> BindStep<R>(Func<Option<R>> cont) {
      return OptionMonad.Return(GetResult<R>());
    }
  }

  class OptionResult {
    public static OptionResult<T> Create<T>(T value) {
      return new OptionResult<T>(value);
    }
  }

  static class OptionExtensions {
    public static OptionStep<T> AsStep<T>(this Option<T> value) {
      return new OptionStep<T>(value);
    }

    public static void Execute(this IEnumerator<IOption> en) {
      en.Execute<Unit>();
    }

    public static Option<R> Execute<R>(this IEnumerator<IOption> en) {
      if (!en.MoveNext()) {
        if (typeof(R) == typeof(Unit)) return (Option<R>)(object)OptionMonad.Zero;
        else throw new InvalidOperationException("Enumerator completed without returning a result!");
      }
      return en.Current.BindStep<R>(() => en.Execute<R>());
    }
  }

  #endregion

  #region Async monad

  class Async<T> {
    public Action<Action<T>> Function { get; set; }
  }

  static class AsyncMonad {
    public static Async<R> Bind<T, R>(this Async<T> input, Func<T, Async<R>> cont) {
      return new Async<R> { Function = f =>
        input.Function(value => cont(value).Function(f))
      };
    }

    public static Async<R> Return<R>(R value) {
      return new Async<R> { Function = f => f(value) };
    }

    public static Async<Unit> Zero {
      get { return new Async<Unit> { Function = f => f(Unit.Value) }; }
    }
  }

  interface IAsync {
    Async<R> BindStep<R>(Func<Async<R>> cont);
  }

  class AsyncStep<T> : MonadStep<T>, IAsync {
    private readonly Async<T> input;
    public AsyncStep(Async<T> input) {
      this.input = input;
    }
    public Async<R> BindStep<R>(Func<Async<R>> cont) {
      return AsyncMonad.Bind(input, MakeContinuation(cont));
    }
  }

  class AsyncResult<T> : MonadReturn<T>, IAsync
  {
    public AsyncResult(T value) : base(value) { }

    public Async<R> BindStep<R>(Func<Async<R>> cont) {
      return AsyncMonad.Return(GetResult<R>());
    }
  }

  class AsyncResult {
    public static AsyncResult<T> Create<T>(T value) {
      return new AsyncResult<T>(value);
    }
  }

  static class AsyncExtensions {
    public static void Spawn(this Async<Unit> async) {
      async.Function(_ => { });
    }

    public static AsyncStep<T> AsStep<T>(this Async<T> value) {
      return new AsyncStep<T>(value);
    }

    public static Async<Unit> Execute(this IEnumerator<IAsync> en) {
      return en.Execute<Unit>();
    }

    public static Async<R> Execute<R>(this IEnumerator<IAsync> en) {
      if (!en.MoveNext()) {
        if (typeof(R) == typeof(Unit)) return (Async<R>)(object)AsyncMonad.Zero;
        else throw new InvalidOperationException("Enumerator completed without returning a result!");
      }
      return en.Current.BindStep<R>(() => en.Execute<R>());
    }
  }

  static class Async 
  {
    #region System Extensions

    public static Async<T> BuildPrimitive<T>(Func<AsyncCallback, object, IAsyncResult> begin, Func<IAsyncResult, T> end) {
      return new Async<T> { Function =
			  cont => begin(delegate(IAsyncResult res) { cont(end(res)); }, null)
      };
		}


    /// <summary>
    /// Asynchronously gets response from the internet using BeginGetResponse method.
    /// </summary>
    public static Async<WebResponse> GetResponseAsync(this WebRequest req)
    {
      return BuildPrimitive<WebResponse>(req.BeginGetResponse, req.EndGetResponse);
    }

    /// <summary>
    /// Asynchronously reads data from a stream using BeginRead.
    /// </summary>
    /// <param name="stream">The stream on which the method is called</param>
    /// <param name="buffer">The buffer to read the data into</param>
    /// <param name="offset">Byte offset in the buffer</param>
    /// <param name="count">Maximum number of bytes to read</param>
    /// <returns>Returns non-zero if there are still some data to read</returns>
    public static Async<int> ReadAsync(this Stream stream, byte[] buffer, int offset, int count)
    {
      return BuildPrimitive<int>(
        (callback, st) => stream.BeginRead(buffer, offset, count, callback, st),
        stream.EndRead);
    }


    class ReadToEndState {
      MemoryStream ms = new MemoryStream();
      Stream stream;
      Action<string> k;

      public ReadToEndState(Stream stream, Action<string> k) {
        this.stream = stream;
        this.k = k;
      }

      internal void Step() {
        byte[] buffer = new byte[1024];
        stream.BeginRead(buffer, 0, 1024, ar => {
          var count = stream.EndRead(ar);
          ms.Write(buffer, 0, count);
          if (count == 0) {
            ms.Seek(0, SeekOrigin.Begin);
            string s = new StreamReader(ms).ReadToEnd();
            k(s);
          } else {
            Step();
          }
        }, null);
      }
    }
    static void ReadToEndAsyncUgly(this Stream stream, Action<string> k) {
      new ReadToEndState(stream, k).Step();
    }

    /// <summary>
    /// Reads asynchronously the entire content of the stream and returns it 
    /// as a string using StreamReader.
    /// </summary>
    /// <returns>Returns string using the 'Result' class.</returns>
    public static IEnumerator<IAsync> ReadToEndAsync(this Stream stream)
    {
      MemoryStream ms = new MemoryStream();
      int read = -1;
      while (read != 0)
      {
        byte[] buffer = new byte[1024];
        var count = stream.ReadAsync(buffer, 0, 1024).AsStep();
        yield return count;

        Console.WriteLine("[{0}] got data: {1}", "url", count.Value);
        ms.Write(buffer, 0, count.Value);
        read = count.Value;
      }

      ms.Seek(0, SeekOrigin.Begin);
      string s = new StreamReader(ms).ReadToEnd();
      yield return AsyncResult.Create(s);
    }

    /// <summary>
    /// Combines the given asynchronous methods and returns an asynchronous method that,
    /// when executed - executes the methods in parallel.
    /// </summary>
    public static Async<Unit> Parallel(params IEnumerator<IAsync>[] operations)
    {
      return new Async<Unit> { Function = (cont) =>
      {
        bool[] completed = new bool[operations.Length];
        for (int i = 0; i < operations.Length; i++)
          ExecuteAndSet(operations[i], completed, i, cont).Execute();
      }};
    }

    #region Implementation

    private static IEnumerator<IAsync> ExecuteAndSet(IEnumerator<IAsync> op, bool[] flags, int index, Action<Unit> cont)
    {
      while (op.MoveNext()) yield return op.Current;
      bool allSet = true;
      lock (flags)
      {
        flags[index] = true;
        foreach (bool b in flags) if (!b) { allSet = false; break; }
      }
      if (allSet) cont(Unit.Value);
    }

    #endregion

    #endregion

    public static Async<T> CallCC<T, R>(Func<Func<T, Async<R>>, Async<T>> f) {
      return new Async<T>
      {
        Function = k =>
        {
          var v = (f(a =>
          {
            Console.WriteLine("k called");
            return new Async<R> { Function = _ => k(a) };
          }));
          Console.WriteLine("calling f");
          v.Function(k);
          Console.WriteLine("f completed");
        }
      };
    }
  }

  #endregion

  class Program
  {
    #region Option monad

    static Option<int> ParseInt(string str) {
      int v;
      if (Int32.TryParse(str, out v))
        return Option.Some(v);
      else
        return Option.None<int>();
    }

    static IEnumerator<IOption> ReadInt() {
      Console.Write("Enter a number: ");
      var m = ParseInt(Console.ReadLine()).AsStep();
      yield return m;
      Console.WriteLine("Okay!");
      yield return OptionResult.Create(m.Value * 10);
    }

    static IEnumerator<IOption> TryCalculate() {
      var n = ReadInt().Execute<int>().AsStep();
      yield return n;
      var m = ReadInt().Execute<int>().AsStep();
      yield return m;
      var res = m.Value + n.Value;
      yield return OptionResult.Create(res);
    }

    private static void OptionMonadDemo() {
      var res = TryCalculate().Execute<int>();
      Console.WriteLine("Result: {0}", res);
    }

    #endregion

    #region Async monad

    static IEnumerator<IAsync> AsyncMethod(string url)
    {
      WebRequest req = HttpWebRequest.Create(url);
      Console.WriteLine("[{0}] starting", url);

      var response = req.GetResponseAsync().AsStep();
      yield return response;

      Console.WriteLine("[{0}] got response", url);
      Stream resp = response.Value.GetResponseStream();

      var html = resp.ReadToEndAsync().Execute<string>().AsStep();
      yield return html;

      Regex reg = new Regex(@"<title[^>]*>(.*)</title[^>]*>");
      string title = reg.Match(html.Value).Groups[1].Value;
      title = "".PadLeft((78 - title.Length) / 2) +
        title + "".PadRight((78 - title.Length) / 2);
      Console.WriteLine("[{0}] completed\n{2}\n{1}\n{2}",
        url, title, "".PadRight(79, '*'));
    }

    static IEnumerator<IAsync> DownloadAll()
    {
      var methods = Async.Parallel(
        AsyncMethod("http://www.microsoft.com"),
        AsyncMethod("http://www.google.com"),
        AsyncMethod("http://www.apple.com"),
        AsyncMethod("http://www.novell.com")).AsStep();
      yield return methods;

      Console.WriteLine("Completed all!");
    }

    static void AsyncMonadDemo()
    {
      DownloadAll().Execute<Unit>().Spawn();
      Console.ReadLine();
    }

    static void DownloadAsync(string url)
    {
      WebRequest req = HttpWebRequest.Create(url);
      req.BeginGetResponse((ar) =>
      {
        WebResponse response = req.EndGetResponse(ar);
        Stream resp = response.GetResponseStream();
        byte[] buffer = new byte[8192];
        resp.BeginRead(buffer, 0, 8192, (ar2) =>
        {
          int read = resp.EndRead(ar2);
          Console.WriteLine("got first {0} bytes", read);
        }, null);
      }, null);
    }

    #endregion

    static Func<int, Async<Unit>> Next;

    static IEnumerator<IAsync> Body(Func<int, Async<Unit>> k)
    {
      Next = k;
      yield return k(10).AsStep();
      Console.WriteLine("this should never be called");
    }

    static IEnumerator<IAsync> Test()
    {
      var r = Async.CallCC<int, Unit>(k => Body(k).Execute<int>()).AsStep();
      yield return r;

      Console.WriteLine(r.Value);
      yield return Next(r.Value + 1).AsStep();
    }

    IEnumerator<int> GetNumbers() {
      int num = 0;
      while (true) {
        Console.WriteLine("generating {0}", num);
        yield return num++;
      }
    }

    private static void ContinuationMonadDemo()
    {
      Test().Execute();
    }

    static void Main(string[] args)
    {
      var en = new Program().GetNumbers();
      en.MoveNext();
      Console.WriteLine("got {0}", en.Current);
      en.MoveNext();
      Console.WriteLine("got {0}", en.Current);

      //OptionMonadDemo();
      AsyncMonadDemo();
      //ContinuationMonadDemo();

      DownloadAsync("http://www.microsoft.com");
      Console.ReadLine();
    }
  }
}
