﻿open System

// Modules that contain functions for calculating 
// with geometric and arithmetic series

module Geometric = 
  let nthTerm (q:float) n = 
    pown q n
  let sumTerms (q:float) n =
    (1.0 - (pown q n)) / (1.0 - q)
    
module Arithmetic =     
  let nthTerm d n =
    (float n) * d
  let sumTerms d n = 
    0.5 * (float (n + 1)) * (nthTerm d n)

// The code that will run when the application starts
// (the last bit in the last file of the project)

let series = Console.ReadLine()
let sumFunc = 
  match series with 
  | "a" -> Arithmetic.sumTerms
  | "g" -> Geometric.sumTerms
  | _ -> failwith "unknown"
  
let res = sumFunc 2.0 10
printfn "Result = %f" res     