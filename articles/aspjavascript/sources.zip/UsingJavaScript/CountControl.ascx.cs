using System;
using System.Text;
using System.IO;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Reflection;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace UsingJavaScript
{
	/// <summary>
	///	Ovladaci prvek na zadavani cisla
	/// </summary>
	public class CountControl : System.Web.UI.UserControl, IPostBackEventHandler
	{
		#region WebControls

		protected TextBox txtNum;
		protected Literal ltrLinks;

		#endregion
		#region Generated code
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		
		#endregion

		#region Properties
		
		private string _quickNum;

		/// <summary> 
		/// Cisla pro rychle zadani (oddelena carkou)
		/// </summary>
		public string QuickNumbers
		{
			set { _quickNum=value; }
			get { return _quickNum; }
		}


		/// <summary>
		/// Hodnota v ovladacim prvku
		/// (pri spatnem zadani vraci 0)
		/// </summary>
		public int Value
		{
			get { 
				try { return Int32.Parse(txtNum.Text); } 
				catch { return 0; }
			}
			set { txtNum.Text=value.ToString(); }
		}

		#endregion
		#region Event handlers

		/// <summary>
		/// Pri nacteni - zaregistruje JS kod a vytvori odkazy
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// skript se bude vkladat pouze jednou
			if (!Page.IsClientScriptBlockRegistered("cont-control"))
			{
				// pomoci reflection ziska aktualni assembly
				Assembly asm=Assembly.GetExecutingAssembly();

				// nacte z ni resource "script.html"
				StreamReader sr=new StreamReader
					(asm.GetManifestResourceStream("UsingJavaScript.script.html"));
			
				// a vlozi do stranky JS blok 
				Page.RegisterClientScriptBlock("cont-control",sr.ReadToEnd());
				sr.Close();
			}



			// Generovani odkazu na nastaveni cisel..
			StringBuilder sb=new StringBuilder();
			if (QuickNumbers==null) return;
			
			string[] nums=QuickNumbers.Split(',');
			foreach(string n in nums)
			{
				try 
				{
					int i=Int32.Parse(n);

					// pomoci 'GetPostBackClientHyperlink' se vygeneruje
					// javascriptovy kod, ktery pomoci __doPostBack
					// zavola metodu RaisePostBackEvent (s parametrem 'i')
					sb.AppendFormat("<a href=\"{0}\">{1}</a>, ",
						Page.GetPostBackClientHyperlink(this,i.ToString()),i);
				} 
				catch {}
			}

			// skladani retezce pomoci StringBuilder je rychlejsi..
			if (sb.Length>0) 
			{
				sb.Remove(sb.Length-2,2);
				sb.Insert(0,"("); sb.Append(")");
				ltrLinks.Text=sb.ToString();
			}
			else
				ltrLinks.Text="";
		}


		/// <summary>
		/// Implementace metody z rozhrani IPostBackEventHandler
		/// Tato metoda je volana po kliknuti na odkaz generovany 
		/// pomoci 'GetPostBackClientHyperlink'
		/// </summary>
		/// <param name="eventArgument">Parametry - v tomto 
		/// pripade cislo, ktere se ma nastavit</param>
		public void RaisePostBackEvent(string eventArgument)
		{
			txtNum.Text=eventArgument;
			// vyvolat udalost
			OnLinkClick(EventArgs.Empty);
		}


		/// <summary>
		/// Vyvolava udalost kliknuti na tlacitko
		/// </summary>
		protected virtual void OnLinkClick(EventArgs e)
		{
			if (LinkClick!=null) LinkClick(this,e);
		}


		/// <summary>
		/// Udalost, ktera se vyvolava pri kliknuti na odkaz
		/// </summary>
		public event EventHandler LinkClick;

		#endregion
	}
}
