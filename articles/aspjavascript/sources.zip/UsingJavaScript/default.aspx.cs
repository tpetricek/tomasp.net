using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace UsingJavaScript
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnGet;
		protected System.Web.UI.WebControls.Label lblValues;
		protected System.Web.UI.WebControls.Label lblEvent;
		protected CountControl cc1,cc2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// zrusit zobrazovane hlasky
			lblValues.Text=""; lblEvent.Text="";
		}

		override protected void OnInit(EventArgs e)
		{
			// Obsluja udalosti ovladacich prvku
			cc1.LinkClick+=new EventHandler(ctrl_LinkClick);
			cc2.LinkClick+=new EventHandler(ctrl_LinkClick);

			// Vyzadovano Asp.Net
			InitializeComponent();
			base.OnInit(e);
		}
		
		#region Web Form Designer generated code
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Vypisuje hodnoty zadane v polickach
		/// </summary>
		private void btnGet_Click(object sender, System.EventArgs e)
		{
			lblValues.Text=string.Format("Zadane hodnoty jsou: {0}, {1}",
				cc1.Value,cc2.Value);
		}


		/// <summary>
		/// Vypisuje informaci ze uzivatel kliknul na odkaz
		/// </summary>
		private void ctrl_LinkClick(object sender, EventArgs e)
		{
			// Zjisti ktery ovladaci prvek vyvolal udalost
			CountControl cc=(CountControl)sender;

			// Vypsat informaci o kliknuti na tlacitko
			lblEvent.Text=string.Format("Kliknuli jste na odkaz u tlacitka '{0}'.<br />"+
				"Nova hodnota je: {1}",cc.ID,cc.Value);
		}
	}
}
