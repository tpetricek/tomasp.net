using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.IO;
using System.Net;

namespace WebDownload
{
	/// <summary>
	/// Ukazkova aplikace na stahovani souboru z internetu
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region Standard generated code

		private System.Windows.Forms.Button btnDownload;
		private System.Windows.Forms.TextBox txtUrl;
		private System.Windows.Forms.TextBox txtDownloaded;
		private System.Windows.Forms.Button btnSaveAs;
		private System.Windows.Forms.SaveFileDialog saveFileDlg;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnDownload = new System.Windows.Forms.Button();
			this.txtUrl = new System.Windows.Forms.TextBox();
			this.txtDownloaded = new System.Windows.Forms.TextBox();
			this.btnSaveAs = new System.Windows.Forms.Button();
			this.saveFileDlg = new System.Windows.Forms.SaveFileDialog();
			this.SuspendLayout();
			// 
			// btnDownload
			// 
			this.btnDownload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnDownload.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnDownload.Location = new System.Drawing.Point(264, 8);
			this.btnDownload.Name = "btnDownload";
			this.btnDownload.Size = new System.Drawing.Size(72, 23);
			this.btnDownload.TabIndex = 0;
			this.btnDownload.Text = "Download";
			this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
			// 
			// txtUrl
			// 
			this.txtUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtUrl.Location = new System.Drawing.Point(8, 8);
			this.txtUrl.Name = "txtUrl";
			this.txtUrl.Size = new System.Drawing.Size(248, 20);
			this.txtUrl.TabIndex = 1;
			this.txtUrl.Text = "http://www.vyvojar.cz";
			// 
			// txtDownloaded
			// 
			this.txtDownloaded.AcceptsReturn = true;
			this.txtDownloaded.AcceptsTab = true;
			this.txtDownloaded.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtDownloaded.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtDownloaded.Location = new System.Drawing.Point(8, 40);
			this.txtDownloaded.MaxLength = 0;
			this.txtDownloaded.Multiline = true;
			this.txtDownloaded.Name = "txtDownloaded";
			this.txtDownloaded.ReadOnly = true;
			this.txtDownloaded.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtDownloaded.Size = new System.Drawing.Size(408, 152);
			this.txtDownloaded.TabIndex = 2;
			this.txtDownloaded.Text = "";
			this.txtDownloaded.WordWrap = false;
			// 
			// btnSaveAs
			// 
			this.btnSaveAs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnSaveAs.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnSaveAs.Location = new System.Drawing.Point(344, 8);
			this.btnSaveAs.Name = "btnSaveAs";
			this.btnSaveAs.Size = new System.Drawing.Size(72, 23);
			this.btnSaveAs.TabIndex = 3;
			this.btnSaveAs.Text = "Save as...";
			this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(424, 198);
			this.Controls.Add(this.btnSaveAs);
			this.Controls.Add(this.txtDownloaded);
			this.Controls.Add(this.txtUrl);
			this.Controls.Add(this.btnDownload);
			this.Name = "MainForm";
			this.Text = "MainForm";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.Run(new MainForm());
		}


		/// <summary>
		/// Stahuje soubor z internetu pomoci objektu WebClient
		/// </summary>
		/// <param name="url">Adresa ktera se ma stahnout</param>
		/// <returns>Stazeny soubor</returns>
		private string Download1(string url)
		{
			// Vytvorit objekt WebClient
			WebClient wc=new WebClient();

			// Otevre stream pro cteni dat z URL a nacte data
			Stream stream=wc.OpenRead(url);
			StreamReader sr=new StreamReader(stream);
			string ret=sr.ReadToEnd();

			// Uzavrit stream
			sr.Close();
			return ret;
		}


		/// <summary>
		/// Stahuje soubor pomoci objektu WebRequest/WebResponse
		/// </summary>
		/// <param name="url">Adresa ktera se ma stahnout</param>
		/// <returns>Stazeny soubor</returns>
		private string Download2(string url)
		{
			// Vytvori request a ziska odpoved serveru
			WebRequest request=HttpWebRequest.Create(url);
			WebResponse response=request.GetResponse();

			// Ziska stream pro cteni dat a nacte data
			Stream responseStream=response.GetResponseStream();
			StreamReader reader=new StreamReader(responseStream,System.Text.Encoding.GetEncoding("windows-1251"));
			string ret=reader.ReadToEnd();

			// Uzavrit odpoved serveru
			response.Close();
			return ret;
		}


		/// <summary>
		/// Stahuje soubor z internetu....
		/// </summary>
		private void btnDownload_Click(object sender, System.EventArgs e)
		{
			try
			{
				// pomoci WebClient
				// txtDownloaded.Text=Download1(txtUrl.Text);
				
				// pomoci WebRequest/WebResponse
				txtDownloaded.Text=Download2(txtUrl.Text);
			}
			catch(Exception exc)
			{
				txtDownloaded.Text="Soubor se nepodarilo stahnout!\r\n\r\n"
					+exc.Message;
			}
		}


		/// <summary>
		/// Stahuje soubor z internetu a uklada ho do souboru
		/// </summary>
		private void btnSaveAs_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (saveFileDlg.ShowDialog()!=DialogResult.OK) return;

				// Vytvorit objekt WebClient
				WebClient wc=new WebClient();

				// Otevre stream pro cteni dat z URL a nacte data
				Stream readStream=wc.OpenRead(txtUrl.Text);

				// Vytvori soubor kam se ulozi obsah z internetu
				Stream writeStream=File.Create(saveFileDlg.FileName);

				// Zkopirovat data
				//  - napred se nactou data z internetu do bufferu
				//  - pote se ulozi z bufferu do souboru
				//  - Read vrati 0 kdyz je vse nacteno
				byte[] buffer=new byte[10240];
				int bytesRead;
				while((bytesRead=readStream.Read(buffer,0,buffer.Length))!=0)
					writeStream.Write(buffer,0,bytesRead);

				readStream.Close();
				writeStream.Close();
			}
			catch(Exception exc)
			{
				txtDownloaded.Text="Soubor se nepodarilo stahnout!\r\n\r\n"
					+exc.Message;
			}
		}
	}
}
