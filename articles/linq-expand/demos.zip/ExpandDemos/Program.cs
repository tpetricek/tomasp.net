﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Query;
using System.Xml.XLinq;
using System.Data.DLinq;
using System.Expressions;
using System.Reflection;

using EeekSoft.Expressions;
using EeekSoft.Query;
using LINQTest.Nwind;

namespace LINQTest
{
	class Program
	{
		static void Main(string[] args)
		{
			SimpleExpansion();
			DLinqExpandSelect();
			DLinqExpandMulti();
		}

		#region SimpleExpansion

		/// <summary>
		/// Simple demonstration of ExpandableExpression
		/// </summary>
		private static void SimpleExpansion()
		{
			Console.WriteLine("=== [ SimpleExpansion ] ===");

			// Declare expression 'calc' that will be used by other lambda expressions
			Expression<Func<int, int>> calc = i => i * 10;

			// Expression and Func that uses 'calc' expression
			// Invoke() is extension method from ExpressionExtensions class
			Expression<Func<int, int>> expr =
				i => calc.Invoke(i) + 2;
			Func<int, int> func =
				i => calc.Invoke(i) + 2;

			// Execute Func (calc is compiled at runtime)
			// [Prints] 
			//   42
			Console.WriteLine("Call func: {0}", func(4));

			// Now expand the expression
			// Expand() is extension method from ExpressionExtensions class
			Expression<Func<int, int>> expanded = expr.Expand();
			
			// Print original and expand expression 
			// [Prints]
			//	 Original: i => Add(i => Multiply(i, 10).Invoke(i), 2)
			//	 Expanded: i => Add(Multiply(i, 10), 2)
			// (as you can see invocation of lambda expression is replaced by its body)
			Console.WriteLine("Original: {0}", expr.ToString());
			Console.WriteLine("Expanded: {0}", expanded.ToString());

			// Compile and execute expanded expression
			// [Prints]
			//   42
			Console.WriteLine(expanded.Compile().Invoke(4));
		}

		#endregion
		#region DLinqExpandSelect

		// We can't use anonymous type because there are some troubles
		// with type inference in current beta...
		// You also can't use anonymous types when you want to delcare 
		// part of query in global class
		class CategoryInfo
		{
			public string CategoryName;
			public string Description;
			public string Product;
		}

		/// <summary>
		/// Advanced example that uses DLINQ for data access
		/// </summary>
		private static void DLinqExpandSelect()
		{
			Console.WriteLine("\n\n=== [ DLinqExpandSelect ] ===");

			// Initialize DB connection (connection string is in the config file)
			Nwind.NorthwindDataContext db = new Nwind.NorthwindDataContext();
			
			// ------------------------------------------------------------
			// ORIGINAL VERSION

			// we want to extract inner select out of the query, so it 
			// can be reused by other queries
			var q_1 = 
				from c in db.Categories 
					select new 
						{ 
							c.CategoryName, 
							c.Description, 
							Product = (from p in db.Products 
								where 
									(p.CategoryID == c.CategoryID) &&
									(p.UnitPrice == db.Products.Where(p2 => p2.CategoryID == c.CategoryID).Max(p2 => p2.UnitPrice))
								select p.ProductName).First()
						};

			// ------------------------------------------------------------
			// SOLUTION

			// Expression that will be used in multiple database queries 
			// takes Category from dabase and returns CategoryInfo 
			// (which was anonymous type in previous example)
			Expression<Func<Nwind.Category, CategoryInfo>> selectExpr = (c) =>
				new CategoryInfo
				{ 
					c.CategoryName, 
					c.Description, 
					Product = (from p in db.Products 
						where 
							(p.CategoryID == c.CategoryID) && 
							(p.UnitPrice == db.Products.Where(p2 => p2.CategoryID == c.CategoryID).Max(p2 => p2.UnitPrice))
						select p.ProductName).First()
				};


			// To use expression in Query call it using Invoke method
			// and call extension method ToExpandable() on table
			var q = from c in db.Categories.ToExpandable()
								select selectExpr.Invoke(c);

			// ------------------------------------------------------------
			// HOW DOES IT WORK?
	
			// You can write this, because selectExpr has correct type
			var q_2 = db.Categories.Select(selectExpr);


			// But, this is wrong!! 
			// DLINQ selects all results from DB and call to 'selectExpr' is evaluated in .NET
			// (this caueses new SQL query for every row!)
			var q_3 = db.Categories.Select(c => selectExpr.Invoke(c) );
			// .. and it is same as folowing code (notice that ToExpandable() is missing):
			var q_4 = from c in db.Categories select selectExpr.Invoke(c);


			// You can invoke ExpressionExtensions.Expand manually
			// this is correct because expression is expanded before sending to DLINQ
			var q_5 = db.Categories.Select(
				ExpressionExtensions.Expand<Func<Nwind.Category, CategoryInfo>>( c => selectExpr.Invoke(c) ));
			// (so this is what thin wrapper that is created using ToExpandable() does..)

			// ------------------------------------------------------------
			// PRINT RESULTS
			foreach(var row in q)
				Console.WriteLine("[{0}]\n  First product: {1}\n  Description:   {2}\n",
					row.CategoryName, row.Product, row.Description);
		}

		#endregion
		#region DLinqExpandMulti

		private static void DLinqExpandMulti()
		{
			Console.WriteLine("\n\n=== [ DLinqExpandMulti ] ===");

			// Initialize DB connection (connection string is in the config file)
			Nwind.NorthwindDataContext db = new Nwind.NorthwindDataContext();

			// We will rise price of product when we have ten or less items in stock 
			Expression<Func<Nwind.Product, bool>> risePrice =
				(r) => r.UnitsInStock < 10;

			// Defines lambda expression that calculates prcie (uses 'risePrice')
			// (value of vat variable is captured when expression is created)
			decimal vat = 1.19m;
			Expression<Func<Nwind.Product, decimal?>> calcPrice = 
				(p) => (risePrice.Invoke(p)?3:1) * p.UnitPrice * vat;

			// Query..
			// Select products with higher price than 30 
			// (and of course return price of product)
			var q = 
				from p in db.Products.ToExpandable()
					where calcPrice.Invoke(p) > 30.0m
					select new 
						{ 
							p.ProductName, p.UnitsInStock, p.UnitPrice,
							ShopPrice = calcPrice.Invoke(p), 
							ExtraPrice = risePrice.Invoke(p)
						};
  
			// ------------------------------------------------------------
			// PRINT RESULTS
			foreach(var row in q)
				Console.WriteLine("{0,-35} {2,-7:00.00}  {3,-7:00.00}  {1,-3} {4}", 
					row.ProductName, row.UnitsInStock, row.UnitPrice, row.ShopPrice, row.ExtraPrice ? "!!!" : "");
		}

		#endregion
	}
}
