#light
namespace Test

open System
open System.Threading

open EeekSoft.FSharp

module StatTests = begin
  (********************************* UTILITIES *********************************)
  /// Measures time taken by executing function passed as a parameter
  let measure_ms foo =   
    let tstart = DateTime.Now
    foo () |> ignore
    (DateTime.Now - tstart).TotalMilliseconds

  /// Measures average time taken by executing function passed as a parameter
  /// Function is executed 1000x to get better average result
  let measure_ms_avg foo =   
    let tstart = DateTime.Now
    let rep = 1000
    for i = 1 to rep do
      foo 0 |> ignore
    done
    ((DateTime.Now - tstart).TotalMilliseconds / float_of_int rep)


  (*********************************   TESTS   *********************************)
  /// Prints time taken by executing specified mapping function for specified 
  /// number of repetitions. This function uses parallel implementation of map 
  /// function ('ParallelList.map')
  /// Parameters:
  ///   reps : int list  - specifies repetition numbers
  ///   op : int -> unit - function to be executed by map
  let test_prl reps op = 
    reps
      |> List.map ( fun rep -> (rep, measure_ms ( fun () -> [1 .. rep] |> ParallelList.map op )) )
      |> List.iter ( fun (rep, ms) -> Console.Write("{0}, ", ms) )

  /// Prints time taken by executing specified mapping function for specified 
  /// number of repetitions. This function uses standard implementation of map 
  /// function ('List.map')
  /// Parameters:
  ///   reps : int list  - specifies repetition numbers
  ///   op : int -> unit - function to be executed by map
  let test_std reps op = 
    reps
      |> List.map ( fun rep -> (rep, measure_ms ( fun () -> [1 .. rep] |> List.map op )) )
      |> List.iter ( fun (rep, ms) -> Console.Write("{0}, ", ms) )
    

  (********************************* PROCESSING ********************************)
  /// List of operations to be executed - tuple contains:
  ///  - list of repetitions to be tested
  ///  - name (avg time which operation takes on my notebook :-))
  ///  - function representing operation
  let ops = [ 
              ([1 .. 100] |> List.map ( fun n -> n*100 ), "0.001[1..100 * 100] ",
                fun (n:int) -> for i=0 to 10 do ignore i done);
              ([1 .. 100] |> List.map ( fun n -> n*100 ), "0.01 [1..100 * 100] ",
                fun (n:int) -> for i=0 to 1300 do ignore i done);
              ([1 .. 100] |> List.map ( fun n -> n*100 ), "0.1  [1..100 * 100] ",
                fun (n:int) -> for i=0 to 13500 do ignore i done);
              ([1 .. 10] |> List.map ( fun n -> n*100 ),  "1    [1..10 * 100] ",
                fun (n:int) -> for i=0 to 133000 do ignore i done);
              ([1 .. 10] |> List.map ( fun n -> n*100 ),  "5    [1..10 * 100] ",
                fun (n:int) -> for i=0 to 650000 do ignore i done);
              ([1 .. 10] |> List.map ( fun n -> n*20 ),  "10   [1..10 * 20]  ",
                fun (n:int) -> for i=0 to 1300000 do ignore i done); 
            ]
            
  let stat_test () =          
    // Write times taken by single operations          
    Thread.Sleep(1000);
    Console.WriteLine("Operations take:")
    ops |> List.iter ( fun (_, n,op) -> Console.WriteLine("{0} - {1}ms", n, measure_ms_avg op) )

    // Test parallel execution
    Console.WriteLine("PARALLEL:");  
    ops |> List.iter ( fun (reps, n, op) ->
      Console.Write("{0}: ", n);
      test_prl reps op;
      Console.WriteLine(); )

    // Test standard executin
    Console.WriteLine("STANDARD");  
    ops |> List.iter ( fun (reps, n,op) ->
      Console.Write("{0}: ", n);
      test_std reps op;
      Console.WriteLine(); )
      
    Console.ReadLine() |> ignore
end