(*
#light
open System
open System.IO
open System.Reflection
open System.Text.RegularExpressions

open EeekSoft.FSharp
open EeekSoft.FSharp.Utils

let is_prime n =
  let max = int_of_float (Math.Sqrt( float_of_int n ))
  let anydiv = { 2 .. max } |> Seq.filter ( fun d -> n%d = 0) |> Seq.nonempty
  not ((n = 1) || anydiv)

let factorize primes n =
  let rec mul_count n d rep = 
    match (n%d) with 
      | 0 -> mul_count (n/d) d (rep + 1)
      | _ -> (rep, n)      
  let (fc, rem) = primes |> List.fold_left ( fun (fl, m) d ->
    let (rep, res) = mul_count n d 0
    match (rep) with | 0 -> (fl, m) | rep -> ((d, rep)::fl, res) ) ([], n)
  fc
  
let factorize2 n = factorize ([1 .. n] |> List.filter is_prime) n

let rec test_isprime () =
  let list_interval = [1 .. 1000000] 

  Console.Write("Hit Enter to start...");
  Console.ReadLine() |> ignore
  let c = measure ("Standard calculation took: {0}") ( fun () ->
    list_interval |> List.filter is_prime |> List.length )
  Console.WriteLine("Primes between 100M and 100.1M: {0}", c) 

  Console.Write("Hit Enter to start...");
  Console.ReadLine() |> ignore
  let c = measure ("Standard calculation took: {0}") ( fun () ->
    list_interval |> Parallel.filter is_prime |> List.length )
  Console.WriteLine("Primes between 100M and 100.1M: {0}", c) 
  Console.WriteLine()
  test_isprime()

let rec test_factorize () =
  let list_interval = [100000 .. 100015] 
  
  Console.Write("Hit Enter to start...");
  Console.ReadLine() |> ignore
  measure ("Standard calculation took: {0}") ( fun () ->
    list_interval |> List.map ( fun n -> (n, factorize2 n) ) |> List.iter ( fun (n, flist) -> 
      Console.Write("{0} = 1", n);
      flist |> List.iter ( fun (m, rep) -> Console.Write(" * {0}^{1}", m, rep); )
      Console.WriteLine(); ) )
  
  Console.Write("Hit Enter to start...");
  Console.ReadLine() |> ignore
  measure ("Parallel  calculation took: {0}") ( fun () ->
    list_interval |> Parallel.map ( fun n -> (n, factorize2 n) ) |> List.iter ( fun (n, flist) -> 
      Console.Write("{0} = 1", n);
      flist |> List.iter ( fun (m, rep) -> Console.Write(" * {0}^{1}", m, rep); )
      Console.WriteLine(); ) )
  Console.WriteLine()
  test_factorize()

let test_std () = 
  Console.WriteLine("STANDARD");
  let primes = measure "Searching for primes: {0}" ( fun () -> [1 .. 1000000] |> List.filter is_prime )
  measure "Factorizing: {0}" ( fun () -> [(1000000 - 500) .. 1000000] |> List.map (factorize primes) ) |> ignore
  
let test_parallel () = 
  Console.WriteLine("PARALLEL");
  let primes = measure "Searching for primes: {0}" ( fun () -> [1 .. 1000000] |> Parallel.filter is_prime )
  measure "Factorizing: {0}" ( fun () -> [(1000000 - 500) .. 1000000] |> Parallel.map (factorize primes) ) |> ignore

let rec test () = 
  Console.Write("Hit Enter to start...");
  Console.ReadLine() |> ignore
  test_std()
  test_parallel()
  test()

let f = new StreamReader("C:\\Tomas\\Tools\\MoMA\\missing.txt");
let list = f |> Seq.unfold ( fun f -> match f.ReadLine() with | null -> None | l -> Some(l, f) ) |> Seq.to_list

let members = measure "Finding members took: {0}" ( fun () ->
       Assembly.GetExecutingAssembly().GetReferencedAssemblies() 
    |> Array.map ( fun an -> Assembly.Load(an) )
    |> Array.to_list
    |> List.fold_left ( fun tlist asm -> (asm.GetTypes() |> Array.to_list)@tlist ) []
    |> List.fold_left ( fun mlist typ -> (typ.GetMembers() |> Array.to_list)@mlist ) [] )
let types = measure "Filtering members took: {0}" ( fun () ->
       members
    |> Parallel.filter ( fun m -> not (m.Name.IndexOf("") = -1) ) )

Console.ReadLine();

let regFilter = new Regex("`[2..9].*get_Item");
let regMap = new Regex("^[^\s]* .*?(?<c>[^\.\s]*)[^\.]*::.*$");
measure "Grep took: {0}" ( fun () -> 
  list 
    |> List.filter ( fun s -> regFilter.Match(s).Success ) 
    |> List.map ( fun s -> regMap.Match(s).Groups.get_Item("c").Value ) 
    |> List.iter ( fun s -> Console.WriteLine(s) ) )
  
Console.ReadLine();

//test()  
//test_factorize() 
//test_isprime()

*)