#light
open Test
open System

StatTests.stat_test()
MathTests.test_isprime();
MathTests.test_factorize();
MathTests.test_combine();
Console.ReadLine();