#light
namespace Test

open System
open System.IO
open System.Reflection
open System.Text.RegularExpressions

open EeekSoft.FSharp

module MathTests = begin

  let measure msg foo =   
    let tstart = DateTime.Now
    let ret = foo ()
    let tdiff = DateTime.Now - tstart
    Console.WriteLine(msg, tdiff.TotalMilliseconds);
    ret

  let is_prime n =
    let max = int_of_float (Math.Sqrt( float_of_int n ))
    let anydiv = { 2 .. max } |> Seq.filter ( fun d -> n%d = 0) |> Seq.nonempty
    not ((n = 1) || anydiv)

  let factorize primes n =
    let rec mul_count n d rep = 
      match (n%d) with 
        | 0 -> mul_count (n/d) d (rep + 1)
        | _ -> (rep, n)      
    let (fc, rem) = primes |> List.fold_left ( fun (fl, m) d ->
      let (rep, res) = mul_count n d 0
      match (rep) with | 0 -> (fl, m) | rep -> ((d, rep)::fl, res) ) ([], n)
    fc
    
  let factorize_slow n = factorize ([1 .. n] |> List.filter is_prime) n

  let rec test_isprime () =
    let list_interval = [1 .. 1000000] 
    
    Console.WriteLine("PRIME_TEST [STANDARD]");
    let c = measure (" - time: {0}") ( fun () ->
      list_interval |> List.filter is_prime |> List.length )
    Console.WriteLine(" - result: {0}", c) 
    
    Console.WriteLine("PRIME_TEST [PARALLEL]");
    let c = measure (" - time: {0}") ( fun () ->
      list_interval |> ParallelList.filter is_prime |> List.length )
    Console.WriteLine(" - result: {0}", c) 


  let rec test_factorize () =
    let list_interval = [100000 .. 100015] 
    let print_it ((n:int), flist) =
      Console.Write(" - {0} = 1", n);
      flist |> List.iter ( fun (m, rep) -> Console.Write(" * {0}^{1}", m, rep); )
      Console.WriteLine();     
    
    Console.WriteLine("FACTORIZATION [STANDARD]");
    measure (" - time: {0}") ( fun () ->
      list_interval |> List.map ( fun n -> (n, factorize_slow n) ) |> List.iter print_it )
    
    Console.WriteLine("FACTORIZATION [PARALLEL]");
    measure (" - time: {0}") ( fun () ->
      list_interval |> ParallelList.map ( fun n -> (n, factorize_slow n) ) |> List.iter print_it )


  let rec test_combine () = 
    Console.WriteLine("COMBINATION [STANDARD]");
    let primes = measure " - searching: {0}" ( fun () -> [1 .. 1000000] |> List.filter is_prime )
    measure " - factorizing: {0}" ( fun () -> [(1000000 - 500) .. 1000000] |> List.map (factorize primes) ) |> ignore
    
    Console.WriteLine("COMBINATION [PARALLEL]");
    let primes = measure " - searching: {0}" ( fun () -> [1 .. 1000000] |> ParallelList.filter is_prime )
    measure " - factorizing: {0}" ( fun () -> [(1000000 - 500) .. 1000000] |> ParallelList.map (factorize primes) ) |> ignore

end