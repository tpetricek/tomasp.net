#light

open nwind
open System
open System.IO
open System.Windows.Forms
open System.Data.SqlClient
open Microsoft.FSharp.Quotations.Typed
open Microsoft.FSharp.Bindings.DLinq
open Microsoft.FSharp.Bindings.DLinq.Query
open Microsoft.FSharp.Bindings.Linq

let db = new Northwind("Database=Northwind;Server=.;Integrated Security=SSPI")

let query = db.Customers 
  |> where <@ fun c -> c.Country="USA" @>
  |> select <@ fun c -> (c.CompanyName, c.City, c.Country) @>

Idioms.foreachG query ( fun (name,city,country) ->
  Console.WriteLine("{0} ({1}, {2})", name.PadRight(40), city, country) )
 
Console.ReadLine()