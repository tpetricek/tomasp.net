#light
namespace MyFSharp.Export

open System

type Customer = class
  val name:String
  val age:int
  val mutable income:int
  
  new(n,a) = { name = n; age = a; income=10000 }
  
  override this.ToString() =
    String.Format("(Name={0}, Age={1}, Income={2})", this.name, this.age, this.income);
    
  member this.Income 
    with get() = this.income
    and set(v) = this.income <- v
  
  member this.Age 
    with get() = this.age
    
  member this.Name 
    with get() = this.name
end