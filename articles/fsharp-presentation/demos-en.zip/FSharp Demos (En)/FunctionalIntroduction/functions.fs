﻿#light 

// Funkce (int -> int)
let add10_a(n) = 
  n + 10
  
// Ekvivalentní funkce (int -> int)
let add10_b(n) = 
  fun (n) -> n + 10
  
// Funkce bere jako parametr funkci 
// Typ: (int -> int -> int) -> int
let volani(func) =
  1 + func 2 3
  
// Předání funkce jako parametr
volani(fun a b -> a + b)