#light

open System
open System.Windows.Forms

let main() =
  let form = new Form()
  form.Text <- "F# Form"

  let btn = new Button()
  btn.Text <- "Click me!"
  form.Controls.Add(btn)
  
  btn.Click.AddHandler(new EventHandler(fun _ _ -> 
    ignore(MessageBox.Show("Hello world!"))
  ))
  Application.Run(form)        
    
[<STAThread>]    
do main()
