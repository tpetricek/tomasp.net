//----------------------------------------------------------------------------
// The Famous DirectX Demo
//
// reference dlls (various include paths, add yours if different) 
//
// THIS DEMO IS A SCRIPT - USE F# INTERACTIVE.  DO NOT COMPILE & RUN
//
//----------------------------------------------------------------------------

module Sample.DirectX.Basics
#I @"C:\WINDOWS\Microsoft.NET\DirectX for Managed Code\1.0.2902.0" ;; 
#I @"C:\WINDOWS\Microsoft.NET\DirectX for Managed Code\1.0.2903.0" ;; 
#r @"Microsoft.DirectX.dll";;
#r @"Microsoft.DirectX.Direct3D.dll" ;;
#r @"Microsoft.DirectX.Direct3Dx.dll" ;;

open System
open Drawing
open Threading  
open Windows.Forms
open Microsoft.DirectX
open Microsoft.DirectX.Direct3D
open Idioms
open Compatibility  
open List

//----------------------------------------------------------------------------
// common
//----------------------------------------------------------------------------

let mapR  a b f = List.init (b-a+1) (fun i -> f (a+i))
let rec iterR a b f = if a<=b then (f a; iterR (a+1) b f) else ()
type time = float

let now () = (float Environment.TickCount / 1000.0) 
let sqr (x:float) = x * x
let pi = Math.PI
let single x = Float32.of_float x
let double x = Float32.to_float x
let singleFun2 f (x,y) = single (f (double x,double y))


//----------------------------------------------------------------------------
// DirectX form
//
// Create an enclosing form which owns its own painting.
//----------------------------------------------------------------------------

type SmoothForm = class 
  inherit Form
  new() as x = 
    { inherit Form(); } 
    then 
       x.SetStyle(Enum.combine [ControlStyles.AllPaintingInWmPaint; ControlStyles.Opaque], true);
end

//----------------------------------------------------------------------------
// DirectX device
//----------------------------------------------------------------------------

// Presentation parameters 
let defaultPresentParams () = 
  let presentParams = new PresentParameters() in 
  presentParams.Windowed <- true;
  presentParams.SwapEffect <- SwapEffect.Discard;
  presentParams.EnableAutoDepthStencil <- true;            // Turn on a Depth stencil
  presentParams.AutoDepthStencilFormat <- DepthFormat.D16;  // And the stencil format
  presentParams

//----------------------------------------------------------------------------
// The drawScene event fires each time we draw the scene.
// The event is fired within the context of a BeginScene/EndScene
//----------------------------------------------------------------------------

type event<'a> = ('a -> unit) * IEvent<'a> 

//----------------------------------------------------------------------------
// We must reset the device if it is rudely taken from us
//----------------------------------------------------------------------------

let rec checkResetThen (device: Device) presentParams f = 
  if device.CheckCooperativeLevel() then begin
    f()
  end else begin
    let r = ref 0 in 
    if not (device.CheckCooperativeLevel(r)) then 
      if !r = Enum.to_int ResultCode.DeviceNotReset then begin
        device.Reset([|presentParams|]);
        checkResetThen device presentParams f
      end
  end;;

//----------------------------------------------------------------------------
// We don't render if the form's not visible
//----------------------------------------------------------------------------

let checkNotMinimizedThen (form : #Form) f = 
    let hidden = (form.WindowState = FormWindowState.Minimized) in
    if not hidden then f()
    
let checkVisibleThen (form : #Control) f = if form.Visible then f()
    
let clearScene (color:Color) (device:Device) =
  device.Clear(Enum.combine[ClearFlags.ZBuffer;ClearFlags.Target],color, 1.0f, 0)

//----------------------------------------------------------------------------
// The render function.  Basically raises the drawScene event
// after checking the device is ready for us.
//----------------------------------------------------------------------------

// doRender: if device available and not hidden, do the required device actions 
let doRender device presentParams form fireEvent = 
  checkResetThen device presentParams (fun () -> 
    checkVisibleThen form (fun () -> 
        device.BeginScene();
        clearScene Color.Black device;
        fireEvent();
        device.EndScene();
        try device.Present() with _ -> ()
    )
  )
    
// doInitialise: initialise device properties and invalidate to trigger redraw       
let doInitialise(device:Device) (form: #Control) =
    device.RenderState.ZBufferEnable <- true;
    device.RenderState.Ambient <- Drawing.Color.White;
    form.Invalidate()
  
//----------------------------------------------------------------------------
// vectors - origin, basis and operations - and - points
//----------------------------------------------------------------------------

let vector (x,y,z) = new Vector3(Float32.of_float x,Float32.of_float y,Float32.of_float z)
let scaleV k v = Vector3.Scale(v,k)  
    
let vO  = vector ( 0.0, 0.0, 0.0) // Require v0 to be "zero": All x. v0 + x = x 
let vX  = vector ( 1.0, 0.0, 0.0) // Basis vectors - all other vectors build on these 
let vY  = vector ( 0.0, 1.0, 0.0)
let vZ  = vector ( 0.0, 0.0, 1.0)

let dot       u v = Vector3.Dot(u,v)
let cross     u v = Vector3.Cross(u,v)
let normalize u   = Vector3.Normalize(u)
let scale     k u = Vector3.Scale(u,k)
let planeProject n v = v - scale (dot n v) n // n is plane normal 
let magnitude v = Vector3.Dot(v,v) |> double  

let colorPoint (c:Color) v = new CustomVertex.PositionNormalColored(v,vZ,c.ToArgb())
let point      v           = colorPoint Color.White v

let transformAt v m = Matrix.Translation(v) * m * Matrix.Translation(-v)  


//----------------------------------------------------------------------------
// DirectX - VertexBuffers
//----------------------------------------------------------------------------

let vertexBufferOfPoints (device:Device) (pts : CustomVertex.PositionNormalColored[]) =
  let vertexBuffer = new VertexBuffer((type CustomVertex.PositionNormalColored),
                                      pts.Length, // number pts 
                                      device,     
                                      Usage.None,
                                      CustomVertex.PositionNormalColored.Format,
                                      Pool.Managed) // Pool.Managed resources survive device loss 
  in
  let offset = 0 in
  vertexBuffer.SetData(pts,offset,LockFlags.None);
  vertexBuffer

//----------------------------------------------------------------------------
// DirectX - clear, lines, triangles
//----------------------------------------------------------------------------

let drawPrimitive vertexBuffer primitive nPrim (device:Device) =
    device.SetStreamSource(0,vertexBuffer,0); // stream number, stream data, offset 
    device.VertexFormat <- CustomVertex.PositionNormalColored.Format;
    device.DrawPrimitives(primitive,0,nPrim)

let drawLineList pts device =
  let ptsA = pts |> Array.of_list in
  let vb = vertexBufferOfPoints device ptsA in
  drawPrimitive vb PrimitiveType.LineList (ptsA.Length/2) device;
  vb.Dispose()

let drawTriangeStrip pts device =
  let ptsA = pts |> Array.of_list in
  let vb = vertexBufferOfPoints device ptsA in
  drawPrimitive vb PrimitiveType.TriangleStrip (ptsA.Length-2) device;
  vb.Dispose()


//----------------------------------------------------------------------------
// DirectX setup lighting
//----------------------------------------------------------------------------

let setupLights (device:Device) =
  let mutable material = new Direct3D.Material() in
  material.DiffuseColor <- ColorValue.FromColor(Color.White);
  material.AmbientColor <- ColorValue.FromColor(Color.White);
  device.Material <- material;
  device.RenderState.Lighting <- true;
  (device.Lights.Item(0)).Type      <- LightType.Directional;
  (device.Lights.Item(0)).Diffuse   <- System.Drawing.Color.White;
  (device.Lights.Item(0)).Direction <- new Vector3(0.0f,0.0f,-1.0f);
  (device.Lights.Item(0)).Enabled   <- true;
  device.RenderState.Ambient <- System.Drawing.Color.FromArgb(0x101010)

//----------------------------------------------------------------------------
// XY grid and axis box
//----------------------------------------------------------------------------

let planeN = 6  // number of division on XY plane grid 
let planeVs = 
  mapR 0 planeN (fun i -> 
    let k = float32 i / float32 planeN in
    [scaleV k vY;vX + scaleV k vY; 	// Line k.Y  to    X + k.Y 
     scaleV k vX;vY + scaleV k vX; ]    // Line k.X  to  k.X +   Y 
  ) |> concat
let planePts = map (colorPoint Color.Gray) planeVs

let boxPts =
  map point
    [vO ;vO  + vZ;
     vO ;vX;
     vX ;vX + vY;
    ] @
  map (colorPoint Color.Gray)
    [vY      ; vY      + vZ;
     vX + vY ; vX + vY + vZ;
     vO + vZ ; vY      + vZ;
     vY + vZ ; vX + vY + vZ;     
    ]

//----------------------------------------------------------------------------
// Color interpolation
//----------------------------------------------------------------------------
    
let colorRange x =
  let r,g,b =
    if x<0.0 then 1.0,0.0,0.0 else
    if x<0.5 then let z = 2.0 * x       in 1.0 - z,      z,0.0 else
    if x<1.0 then let z = 2.0 * x - 1.0 in 0.0    ,1.0 - z,z   else 0.0,0.0,1.0
  in
  let byte x = int_of_float (x * 255.0) in
  Color.FromArgb(0,byte r,byte g,byte b)


//----------------------------------------------------------------------------
// surface - index
//----------------------------------------------------------------------------

let triangleRow n m =
  // Generate triangle strip for row m.
  // Points (0,m)  .....(n-1,m)
  // Points (0,m+1).....(n-1,m+1)
   
  mapR 0 (2*n-1) (fun k ->
  let i = k / 2 in
  if k mod 2 = 0 then (i,m) else (i,m+1))
let triangleRows n m = mapR 0 (m-2) (fun m -> triangleRow n m)

//----------------------------------------------------------------------------
// Mouse events
//----------------------------------------------------------------------------

let mkMouseTracker (c : #Control) = 
  let fire,event = IEvent.create() in 
  let lastArgs = ref None in
  c.MouseDown.Add(fun args -> lastArgs := Some args);
  c.MouseUp.Add  (fun args -> lastArgs := None);
  c.MouseMove.Add(fun args -> 
      match !lastArgs with
      | Some last -> fire(last,args); lastArgs := Some args
      | None -> ());
  event
                                 
//----------------------------------------------------------------------------
// setView
//----------------------------------------------------------------------------
    
// yaw, pitch, roll, focus, zoom state
type view = { mutable ypr: Matrix;
              mutable focus: Vector3;
              mutable zoom: float }

let move view ((a:MouseEventArgs),(b:MouseEventArgs)) =
  let dx = b.X - a.X in
  let dy = b.Y - a.Y in
  if b.Button = MouseButtons.Left then
    if Form.ModifierKeys = Keys.Shift then
      view.zoom <- view.zoom * exp (float dy / 100.0) // Zoom 
    else
      let rx = float32 dx / 20.0f in
      let ry = float32 dy / 20.0f in    
      let m = Matrix.RotationYawPitchRoll(ry,0.0f,rx) in    // Rotate 
      let m = transformAt (scaleV -0.5f (vX + vY + vZ)) m in // at centre point 
      view.ypr <- m * view.ypr
  else
    let dv = scale (float32 (-dx) / 50.0f) vY + scale (float32 dy / 50.0f) vZ in
    view.focus <- view.focus + dv // Move focus 
   
let setView view (device:Device) =
  let eye = scaleV 2.0f (vX + vY + vZ) - scaleV (single view.zoom) vX in
  device.Transform.View <-
    Matrix.Invert(view.ypr) * 
    Microsoft.DirectX.Matrix.LookAtLH(
      eye,
      view.focus,
      vZ);
  device.Transform.Projection <-
    Microsoft.DirectX.Matrix.PerspectiveFovLH(
      single (Math.PI / 8.0),  // FOV 
      1.0f,                    // aspect 
      0.1f,                    // min depth 
      100.0f                   // max depth 
    );
  device.Transform.World <- Matrix.Identity;;
  
let mkMesh gx gy (m,n) = Array2.init n m (fun i j -> gx n i),Array2.init n m (fun i j -> gy m j)
let meshDims mesh = let X,Y = mesh in Array2.length1 X, Array2.length2 X
let meshGet mesh (i,j) = let X,Y = mesh in X.(i,j), Y.(i,j)


let ij2k mesh (i,j) = let m,n = meshDims mesh in i + j * n 
let k2ij mesh k = let m,n = meshDims mesh in k mod n,k / n   

let colorPlace mesh data c (i,j) =
  let k = ij2k mesh (i,j) in
  let x,y,z = data.(k) in
  let x,y,z = Float32.of_float x,Float32.of_float y,Float32.of_float z in
  colorPoint c (vO + scaleV x (vX - vO) + scaleV y (vY - vO) + scaleV z (vZ - vO))

let blendPlace mesh data (i,j) =
  let k = ij2k mesh (i,j) in
  let x,y,z = data.(k) in
  let c = colorRange z in    
  let x,y,z = Float32.of_float x,Float32.of_float y,Float32.of_float z in
  colorPoint c (vO + scaleV x vX + scaleV y vY + scaleV z vZ)

