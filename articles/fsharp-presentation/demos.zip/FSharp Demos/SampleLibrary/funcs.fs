#light

namespace MyFSharp.Export

module ExportModule = begin

  // faktorial
  let rec factorial n =
    if (n = 0) then 1 else n * (factorial (n-1))

  // prohazuje prvku ve dvojici
  let swapTuple (a,b) = 
    (b,a)
    
  // funkce
  let (call42hello func):unit =
    (func 42 "Hello!")
    
  // discriminated union
  type simple_expr = 
    | Int of int
    | Add of simple_expr * simple_expr 
    | Mul of simple_expr * simple_expr 
  
  let rec eval e =
    match e with
      | Int n -> n
      | Add (a, b) -> (eval a) + (eval b)
      | Mul (a, b) -> (eval a) * (eval b)
end