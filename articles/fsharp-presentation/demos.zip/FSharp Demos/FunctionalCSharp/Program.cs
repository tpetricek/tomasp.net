using System;
using System.Collections.Generic;
using System.Text;

namespace FunctionalCSharp
{
	class Program
	{
		static void Main(string[] args)
		{
			//Sorting.QuickSort();
			//Idioms.DemoMapFilterFoldL();
			Idioms.DemoLazy();
			Console.ReadLine();
		}
	}
}
