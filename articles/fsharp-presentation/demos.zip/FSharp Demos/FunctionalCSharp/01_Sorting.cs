using System;
using System.Collections.Generic;
using System.Text;

namespace FunctionalCSharp
{
	class Sorting
	{
		internal static void QuickSort()
		{
			int[] data = new int[] { 21, 68, 49, 84, 75, 14, 23, 15, 6, 47, 89, 4, 56, 12, 31, 56, 49, 84, 2, 31 };
			
			qsort(data, 0, data.Length-1);	

			foreach(int i in data) Console.Write("{0}, ", i);
		}

		private static void qsort(int[] data,int left,int right)
		{
			int l_hold = left, r_hold = right;
			int pivot = data[left];

			while (left < right)
			{
				while ((data[right] >= pivot) && (left < right)) right--;

				if (left != right)
				{
					data[left] = data[right];
					left++;
				}

				while ((data[left] <= pivot) && (left < right)) left++;

				if (left != right)
				{
					data[right] = data[left];
					right--;
				}
			}

			data[left] = pivot;
			if (l_hold < left)
			{
				qsort(data, l_hold, left-1);
			}

			if (r_hold > left)
			{
				qsort(data, left+1, r_hold);
			}
		}
	}
}
