#light

open System
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw

let EFInt32 = efInt32
let EFApps = efApps
let EFAnyTopDefn = efAnyTopDefn

// ------------------------------------------------------------------
type simple_expr =
  | Int of int
  | Add of simple_expr * simple_expr
  | Sub of simple_expr * simple_expr
  | Mul of simple_expr * simple_expr
  | Div of simple_expr * simple_expr

// ------------------------------------------------------------------
let rec eval = fun e ->
  match e with
    | Int i -> i
    | Add (x,y) -> eval x + eval y
    | Sub (x,y) -> eval x - eval y
    | Mul (x,y) -> eval x * eval y
    | Div (x,y) -> eval x / eval y
  
// ------------------------------------------------------------------
let rec tostring e = 
  match e with
    | Int n -> n.ToString()
    | Add (x,y) -> "("^(tostring x)^" + "^(tostring y)^")"
    | Sub (x,y) -> "("^(tostring x)^" - "^(tostring y)^")"
    | Mul (x,y) -> "("^(tostring x)^" * "^(tostring y)^")"
    | Div (x,y) -> "("^(tostring x)^" / "^(tostring y)^")"

// ------------------------------------------------------------------
let rec parse x =
  match x with  
    | EFInt32 (x) -> Int(x)
    | EFApps (op,args) -> 
    
      // Volani nejake funkce
      let op = match op with  
        | EFAnyTopDefn (a,_) -> let t1,t2 = a.topDefPath in t2
        | _ -> failwith ("Function is not a top level definition.") in
      let av = List.to_array(List.map (fun arg -> parse arg) args) in
      match op with
        | "op_Addition"    -> Add(av.(0),av.(1))
        | "op_Subtraction" -> Sub(av.(0),av.(1))
        | "op_Multiply"    -> Mul(av.(0),av.(1))
        | "op_Division"    -> Div(av.(0),av.(1))
        | _ ->
          failwith ("Neznama operace - "^op)
    | _ -> 
      // something else than efApps and efInt32 - error
      failwith ("Nepodporovana konstrukce")
    
    
// ------------------------------------------------------------------

let my_quot = <@@ (2*3 + 10/5)/2 - 2 @@> in
let my_parsed = parse my_quot in
  
printf "Expression: %s\n" (tostring(my_parsed))
printf "Evaluated: %i\n" (eval(my_parsed))

ignore(Console.ReadLine())
