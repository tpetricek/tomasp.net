using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.FSharp;
using MyFSharp.Export;

namespace SampleLibraryUse
{
	class Program
	{
		static void Main(string[] args)
		{
			TestFunctions();
			TestClasses();
		}

		private static void TestFunctions()
		{
			// Faktorial
			int f = ExportModule.factorial(5);
			Console.WriteLine("Faktorial: {0}", f);

			// Tuple
			Tuple<string, int> rev = ExportModule.swapTuple(10, "Ahoj");
			Console.WriteLine("Tuple: #1 = {0}, #2 = {1}", 
				rev.Item1, rev.Item2);

			// Funkce
			FastFunc<int, FastFunc<string, Unit>> func = FuncConvert.ToFastFunc<int, string>(
				delegate(int n, string s)
				{
					Console.WriteLine("Volani z F#: {0}, {1}", n, s);
				});
			ExportModule.call42hello(func);

			// Discriminated union
			ExportModule.simple_expr e = 
				new ExportModule.simple_expr._Mul(
					new ExportModule.simple_expr._Int(3),
					new ExportModule.simple_expr._Add(
						new ExportModule.simple_expr._Int(2),
						new ExportModule.simple_expr._Int(3)));
			Console.WriteLine("Eval e: {0}", ExportModule.eval(e));
		}

		private static void TestClasses()
		{
			Customer cust = new Customer("John Doe", 30);
			cust.Income = 20000;
			Console.WriteLine("\nCustomer.ToString(): {0}", cust);
		}
	}
}
