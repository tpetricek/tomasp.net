//---------------------------------------------------------------------------------------
// ACCELERATOR using F# quotations
//---------------------------------------------------------------------------------------
// This sample uses F# quotations and meta-programming features to translate
// code written in F# to code that is executed on GPU using the Accelerator library.
//---------------------------------------------------------------------------------------

module FSharp.Accelerator.Samples.Main

open System
open System.Drawing
open System.Windows.Forms

open Microsoft.FSharp.Math
open Microsoft.FSharp.Quotations

module Matrix = Math.Matrix.Generic

open FSharp
open FSharp.Math
open FSharp.Math.DataParallel
open FSharp.Accelerator
open FSharp.Accelerator.EvalTransformation


//---------------------------------------------------------------------------------------
// PI CALCULATION 
//---------------------------------------------------------------------------------------

[<ReflectedDefinition>]
let piSize = 2048

/// Gets X and Y coordinates of points in range (0, 1) and returns the
/// number of points that are located inside a circle in the square
[<ReflectedDefinition>]
let countInCircle x y =
  // Transform points to have a center in (0, 0) and range (-1, 1)
  let xc = (x -| 0.5f) *| 2.0f
  let yc = (y -| 0.5f) *| 2.0f
  // Calculate distance of (x, y) from (0, 0)
  let pdist = pointwiseSqrt ((xc .* xc) .+ (yc .* yc))
  
  // Create an array of 1's if distance <= 1 or 0 otherwise
  let incirc = 
    select 
      ((onef (piSize, piSize)) .- pdist) 
      (onef (piSize, piSize)) (zerof (piSize,piSize))
  // The number inside the circle is the sum of the entire InCircle array
  sum incirc

//---------------------------------------------------------------------------------------

let piCalculation() =
  // Generate random point locations
  let rnd = new Random()
  let gen x y = float32(rnd.NextDouble())
  let x = Matrix.init piSize piSize gen
  let y = Matrix.init piSize piSize gen
  
  // Monte-Carlo on CPU
  for i = 1 to 5 do
    let count = Utils.printTime "Calculating on CPU" (fun () ->
      countInCircle x y )
    let pi = 4.0f * count / float32(piSize * piSize)
    printf " * PI = %f\n\n" pi
  
  let countInCircleAcc = Utils.printTime "Accelerating 'countInCircle'" (fun () ->
    Accelerate.accelerate <@@ countInCircle @@> )
    
  // Monte-Carlo on GPU using Accelerator
  let target = new Microsoft.ParallelArrays.DX9Target() 
  for i = 1 to 5 do
    let count = Utils.printTime "Executing 'countInCircle' on GPU" (fun () ->
      eval<float32> target countInCircleAcc [ makeValue x; makeValue y ])
    let pi = 4.0f * count / float32(piSize * piSize)
    printf " * PI = %f\n\n" pi

  // Monte-Carlo on multi-core CPU using Accelerator
  let target = new Microsoft.ParallelArrays.X64MulticoreTarget() 
  for i = 1 to 5 do
    let count = Utils.printTime "Executing 'countInCircle' on multi-core" (fun () ->
      eval<float32> target countInCircleAcc [ makeValue x; makeValue y ])
    let pi = 4.0f * count / float32(piSize * piSize)
    printf " * PI = %f\n\n" pi
  
  Console.ReadLine() |> ignore

//---------------------------------------------------------------------------------------
// LIFE SAMPLE - using expandable function
//---------------------------------------------------------------------------------------

// Inside translated methods, we can use only functions understood by the trnaslator.
// This means that we cannot mix code executed on CPU with GPU code. In this sample,
// we use 'ExpandableList.foldTuples', which is evaluated during the translation
// (using arguments specified before translation). 
//
// This means that the code sent to GPU will look like:
//   init .+ (rotate num -1 -1) .+ (rotate num 0 -1) .+ (rotate num 1 -1) .+ ...
//
// For other expandable functions, see the 'ExpandableList' module in 'Accelerate.fs'


// Functions and values that are used inside the code that is translated 
// using Accelerator - we need to make it available to the translator
[<ReflectedDefinition>]
let (|>) x f = f x

[<ReflectedDefinition>]
let lifeSize = 512

[<ReflectedDefinition>]
let zeroLife = zerof (lifeSize, lifeSize)

[<ReflectedDefinition>]
let threeLife = threef (lifeSize, lifeSize)

[<ReflectedDefinition>]
let twoLife = twof (lifeSize, lifeSize)

// Initial state of the Life Game
let initialData = Matrix.init lifeSize lifeSize ( fun x y -> 
  if (x = (lifeSize / 2)) || (y = (lifeSize / 2)) || (x = y) 
    then 1.0f else 0.0f )

/// Evaluate next generation of the life game state
[<ReflectedDefinition>]
let nextGeneration offs (blife:Matrix<float32>) =
  let sum = offs |> ExpandableList.foldTuples ( fun st dx dy -> 
    st .+ (rotate blife dy dx) ) zeroLife
  (sum =. threeLife) ||. ((sum =. twoLife) &&. blife)
    
let offs = 
  [ (-1, -1); (-1, 0); (-1, 1); (0, -1); 
    (0, 1);   (1, -1); (1, 0);  (1, 1); ]

let lifeGameSample(bacc, target) =
  // Since the offsets are expanded during the translation, we need to pass the 
  // argument before expansion, so that the translator can process 'foldTuples' call
  let nextGenerationAcc = Utils.printTime "Accelerating life func" (fun () -> 
    Accelerate.accelerate <@@ nextGeneration offs @@> )
  
  let runAcc m = 
    Utils.printTime "Calculating next generation on GPU" (fun () -> 
      eval<Matrix<float32>> target nextGenerationAcc [ makeValue m ] )
  let run m =
    Utils.printTime "Calculating next generation on CPU" (fun () -> nextGeneration offs m)
  
  DrawingForm.Run
    (initialData, (if bacc then runAcc else run), 
     Conversions.bitmapOfMatrix (fun f -> if f > 0.5f then Color.DarkOliveGreen else Color.White))

//---------------------------------------------------------------------------------------
// LIFE SAMPLE - using explicit meta-programming
//---------------------------------------------------------------------------------------

// In this sample, we dynamically build quotation that is then run using Accelerator.
// This way, we can mix CPU and GPU code (and it is more flexible than using expandable
// functions). The quoted code will be executed on GPU using Accelerator and the code
// that builds it will run on CPU (only once)

let variable<'TResult> str = 
  let var = Var.Global(str, typeof<'TResult>)
  let expr = Expr.Cast<'TResult>(Expr.Var(var))
  var, expr
  
/// Builds a quoted function that evaluates the next step of the life game
/// (the type of the built function is Matrix<float32> -> Matrix<float32>)
let makeNextGeneration offs =
  let lifeVar, lifeExpr = variable<Matrix<float32>> "blife"
  let expr = offs |> List.fold (fun currentExpr (dx, dy) -> 
    <@ (%currentExpr) .+ (rotate (%lifeExpr) dy dx) @>) <@ zeroLife @>
  let body =
    <@ let sum = (%expr) 
       (sum =. threeLife) ||. ((sum =. twoLife) &&. (%lifeExpr)) @>
  Expr.Lambda(lifeVar, body)

let lifeGameMetaProgramming(target) =
  let run = 
    let nextGen = Utils.printTime "Accelerating life func" (fun () -> 
      Accelerate.accelerate (makeNextGeneration offs) )
    (fun m ->
      Utils.printTime "Calculating next generation on GPU" (fun () -> 
        eval<Matrix<float32>> target nextGen [ makeValue m ] ))
    
  DrawingForm.Run
    (initialData, run, 
     Conversions.bitmapOfMatrix (fun f -> 
       if f > 0.5f then Color.DarkOliveGreen else Color.White))

//---------------------------------------------------------------------------------------
// ROTATION SAMPLE
//---------------------------------------------------------------------------------------

/// Implements image (matrix) rotation only using data-parallel operations
[<ReflectedDefinition>]
let rotateImage s c w h whalf hhalf (data:Matrix<float4>) =
  // Initialize arrays with X and Y coordinates of a bitmap 
  // [0 0 0..., 1 1 1..., 2 2 2...] and [0 1 2..., 0 1 2..., 0 1 2...]
  // and convert numbers to mid-image coordinates
  let posX = (Conversions.singleOfInt (positions w h 0)) -| whalf
  let posY = (Conversions.singleOfInt (positions w h 1)) -| hhalf

  // Calculate rotated coordinates 
  let rotatedX = posX *| c .- posY *| s
  let rotatedY = posY *| c .+ posX *| s

  // Convert back to corner coordinates.
  let posX' = rotatedX +| whalf
  let posY' = rotatedY +| hhalf

  // Lookup to find pixels at the calculated locations
  let fracX = fraction posX'
  let fracY = fraction posY'
  
  // Calculate indices of neighboring pixels
  let indX0 = Conversions.intOfSingle (posX' .- fracX)
  let indY0 = Conversions.intOfSingle (posY' .- fracY)
  let indX1 = indX0 +| 1
  let indY1 = indY0 +| 1
  
  // Get values of 4 nearby pixels 
  let y0x0 = gather data indX0 indY0
  let y0x1 = gather data indX0 indY1
  let y1x0 = gather data indX1 indY0
  let y1x1 = gather data indX1 indY1

  // Perform linear interpolation (based on the fractions fracX, fracY)
  let y0  = interpolatef4 (Conversions.float4OfSingle fracX) y0x1 y0x0
  let y1  = interpolatef4 (Conversions.float4OfSingle fracX) y1x1 y1x0  
  let res = interpolatef4 (Conversions.float4OfSingle fracY) y1 y0  
  res 
  
let rotateSample(bacc, target) =
  let bmp = Bitmap.FromFile(Application.StartupPath+"\\prague.jpg") :?> Bitmap   
  let data = bmp |> Conversions.matrixOfBitmap Float4.ofColor
  
  /// Performs pre-computation of sin and cos values and then
  /// invokes the rotation function passed as the first parameter
  let rotationStep invokeRotation (_, angle) =    
    let angle = if (angle >= 359.0) then 0.0 else (angle + 1.0)
    let angleRad = Math.PI / 180.0 * angle
    let (s, c) = float32(Math.Sin(angleRad)), float32(Math.Cos(angleRad))      
    let (w, h) = (bmp.Width, bmp.Height)
    (invokeRotation s c w h ((float32 w) / 2.0f) ((float32 h) / 2.0f), angle)
    
  // CPU version of the function
  let run = rotationStep ( fun sn cs wid hgt widhalf hgthalf ->
      Utils.printTime "Rotating on CPU" (fun () -> 
        rotateImage sn cs wid hgt widhalf hgthalf data))
      
  // accelerated GPU version
  let runAcc =    
    let accelerated = Utils.printTime "Accelerating 'rotateImage'" (fun () -> 
      Accelerate.accelerate <@@ rotateImage @@>)
    rotationStep (fun sn cs wid hgt widhalf hgthalf ->
      Utils.printTime "Rotating on GPU" (fun () -> 
        ( eval<Matrix<float4>> target accelerated 
            [ makeValue sn; makeValue cs; makeValue wid; makeValue hgt;  
              makeValue widhalf; makeValue hgthalf; makeValue data ] )))
  
  DrawingForm.Run
    ((data, 0.0), (if bacc then runAcc else run),
     fst >> Conversions.bitmapOfMatrix Float4.toColor)

//---------------------------------------------------------------------------------------
// BLUR SAMPLE
//---------------------------------------------------------------------------------------

// In this sample we use 'ExpandableList.foldIndex' which is expanded during 
// the translation (see desciption for LIFE sample). Here we calulate coefficients  
// for the blur function and expand it to the code that looks like this:
//
//   let res = xini .+ ((shift pa 0 0) *| 0.2f) .+ ((shift pa 0 1) *| 0.3f) 
//                  .+ ((shift pa 0 2) *| 0.4f) .+ ...
//
// (This could be also implemented using explicit meta-programming)

[<ReflectedDefinition>]
let blurImage kernel (input:Matrix<float4>) =
  let initial = zerof4 input.Dimensions
  // Convolve in X direction.
  let convolvedX = ExpandableList.foldIndex (fun i st v -> 
    st .+ (shift input 0 i) *| v ) initial kernel    
  // Convolve in Y direction.
  let convolvedXY = ExpandableList.foldIndex (fun i st v -> 
    st .+ (shift convolvedX i 0) *| v ) initial kernel
  convolvedXY
  
// Compute coefficients for blur algorithm
let computeCoefficients fs sigma =
  let ia = List.init fs (fun i -> 
    Math.Exp(-float ((i - fs/2) * (i - fs/2)) / (2.0 * sigma * sigma)))
  let sum = List.sum ia
  [ for v in ia -> Float4.ofSingle(float32(v / sum)) ]
      

let blurSample(bacc, target) =
  let bmp = Bitmap.FromFile(Application.StartupPath+"\\prague.jpg") :?> Bitmap 
         |> Conversions.matrixOfBitmap Float4.ofColor
  let coefs = computeCoefficients 9 2.0
  
  // Original CPU version of blur        
  let run data = Utils.printTime "Bluring on CPU" (fun () -> 
    blurImage coefs data)
  
  // Accelerated version of blur
  let runAcc = 
    let accelerated = Utils.printTime "Accelerating 'blurImage'" (fun () -> 
      Accelerate.accelerate <@@ blurImage coefs @@> )
    (fun data ->   
      Utils.printTime "Bluring on GPU" (fun () -> 
        eval<Matrix<float4>> target accelerated [ makeValue data ]))
  
  DrawingForm.Run
    (bmp, (if bacc then runAcc else run), 
     Conversions.bitmapOfMatrix Float4.toColor)
  
//---------------------------------------------------------------------------------------
// BLUR SAMPLE - using explicit meta-programming
//---------------------------------------------------------------------------------------

let makeBlurImage (kernel:_ list) =
  let half = kernel.Length / 2
  let kernel = List.zip kernel [-half .. kernel.Length - half - 1]
  let inputVar, inputExpr = variable<Matrix<float4>> "input"
  // Compose convolution in X direction
  let initial = <@ zerof4 (%inputExpr).Dimensions @>
  let convolvedX = 
    kernel |> List.fold (fun st (v, idx) -> 
    <@ (%st) .+ (shift (%inputExpr) 0 idx) *| v @>) initial 
  
  // Store the convolved result in a variable
  let convXVar, convXExpr = variable<Matrix<float4>> "convolvedX"
      
  // Compose convolution in Y direction
  let body = kernel |> List.fold (fun st (v, idy) -> 
    <@ (%st) .+ (shift (%convXExpr) idy 0) *| v @>) initial 
  
  let convXDecl = Expr.Let(convXVar, convolvedX, body)
  Expr.Lambda(inputVar, convXDecl)
  
let blurSampleMetaProgramming(target) =
  let bmp = Bitmap.FromFile(Application.StartupPath+"\\prague.jpg") :?> Bitmap 
         |> Conversions.matrixOfBitmap Float4.ofColor
  let coefs = computeCoefficients 9 2.0
  
  // Accelerated version of blur
  let runAcc = 
    let accelerated = Utils.printTime "Accelerating 'blurImage'" (fun () -> 
      Accelerate.accelerate (makeBlurImage coefs))
    (fun data ->   
      Utils.printTime "Bluring on GPU" (fun () -> 
        eval<Matrix<float4>> target accelerated [ makeValue data ]))
  
  DrawingForm.Run
    (bmp, runAcc, 
     Conversions.bitmapOfMatrix Float4.toColor)
  
//-----------------------------------------------------------------------------

do
  // Choose one of the samples...  
  let execute = "blurex"
  let useAccelerator = true

  // Runs the selected example  
  let target = new Microsoft.ParallelArrays.X64MulticoreTarget()
  match execute with
  | "pi"     -> piCalculation()
  | "life"   -> lifeGameSample(useAccelerator, target)
  | "lifeex" -> lifeGameMetaProgramming(target)
  | "rotate" -> rotateSample(useAccelerator, target)
  | "blur"   -> blurSample(useAccelerator, target)
  | "blurex" -> blurSampleMetaProgramming(target)
  | _ -> printf "Unknown example!"