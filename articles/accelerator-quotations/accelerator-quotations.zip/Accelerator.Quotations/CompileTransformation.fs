//---------------------------------------------------------------------------------------
// COMPILING TRANFORMATION 
//---------------------------------------------------------------------------------------
// This module provides primitive functions that are used to construct computations
// during the translation (from Accelerate.fs). In this module, the result is a function
// that takes input arguments and runs code using Accelerator. This means that we 
// can process quotations in advance only once and then we can efficiently invoke
// the returned function multiple times. 
//---------------------------------------------------------------------------------------
module FSharp.Accelerator.CompileTransformation

open System
open Microsoft.FSharp.Math
open Microsoft.ParallelArrays

open FSharp
open FSharp.Math
open FSharp.Math.DataParallel

type AccFloat4 = Microsoft.ParallelArrays.Float4
type FPA = Microsoft.ParallelArrays.FloatParallelArray
type F4PA = Microsoft.ParallelArrays.Float4ParallelArray
type IPA = Microsoft.ParallelArrays.IntParallelArray
type BPA = Microsoft.ParallelArrays.BoolParallelArray
type PA = Microsoft.ParallelArrays.ParallelArrays

module Matrix = Math.Matrix.Generic

//---------------------------------------------------------------------------------------

/// The TransformContext type is kept as a parameter during the translation
/// in this module we use it for remembering the types of bound variables
type TransformContext = Map<String, Type>

/// The ArgContext type is a parameter for a function that calls Accelerator
/// methods. It contains variable bindings.
type ArgContext = Map<String, VariableBinding> 

/// The 'Result' member is used to prevent calculation of the 
/// same value more than once.
and VariableBinding = 
  { Value  : TransformValue
    Result : EvalTransformation.TransformValue option ref }

/// The TransformValue type represents the result of convertsion
and TransformValue =
  | FloatMatrixValue of (ArgContext -> FPA)
  | Float4MatrixValue of (ArgContext -> F4PA)
  | IntMatrixValue of (ArgContext -> IPA)
  | BoolMatrixValue of (ArgContext -> BPA)
  
  | FloatValue of (ArgContext -> FPA)
  | IntValue of (ArgContext -> IPA)
  
  | FloatConst of (ArgContext -> float32)
  | Float4Const of (ArgContext -> float4)
  | IntConst of (ArgContext -> int)

//---------------------------------------------------------------------------------------
// INTERNAL - Utilities (conversion of values, etc.)
//---------------------------------------------------------------------------------------
  
module Internal =
  let valueOfEvalValue (v:EvalTransformation.TransformValue) = 
    match v with
    | EvalTransformation.FloatMatrixValue v  -> FloatMatrixValue ( fun _ -> v )
    | EvalTransformation.Float4MatrixValue v -> Float4MatrixValue ( fun _ -> v )
    | EvalTransformation.IntMatrixValue v    -> IntMatrixValue ( fun _ -> v )
    | EvalTransformation.BoolMatrixValue v   -> BoolMatrixValue ( fun _ -> v )
    | EvalTransformation.FloatValue v        -> FloatValue ( fun _ -> v )
    | EvalTransformation.IntValue v          -> IntValue ( fun _ -> v )
    | EvalTransformation.FloatConst v        -> FloatConst ( fun _ -> v )
    | EvalTransformation.Float4Const v       -> Float4Const ( fun _ -> v )
    | EvalTransformation.IntConst v          -> IntConst ( fun _ -> v )
   
  let valueToEvalValue (v:TransformValue) args =
    match v with
    | FloatMatrixValue f  -> EvalTransformation.FloatMatrixValue (f args)
    | Float4MatrixValue f -> EvalTransformation.Float4MatrixValue (f args)
    | BoolMatrixValue f   -> EvalTransformation.BoolMatrixValue (f args)
    | IntMatrixValue f    -> EvalTransformation.IntMatrixValue (f args)
    | IntConst f          -> EvalTransformation.IntConst (f args)
    | FloatConst f        -> EvalTransformation.FloatConst (f args)
    | Float4Const f       -> EvalTransformation.Float4Const (f args)
    | IntValue f          -> EvalTransformation.IntValue (f args)
    | FloatValue f        -> EvalTransformation.FloatValue (f args)

  /// Initialize a new variable with the given value
  let newVariable v = { Value=v; Result=ref None; }

  /// Read variable from the context
  let readVariable name args = 
    let v = (Map.find name args)
    if (!v.Result = None) then
      let res = (valueToEvalValue v.Value args) 
      v.Result := Some res
    match !v.Result with 
    | Some v -> valueOfEvalValue v
    | None -> failwith "readVariable - Unreachable code!"

//---------------------------------------------------------------------------------------
// CONTEXT AND VARIABLES - here we use context to store values of variables
//---------------------------------------------------------------------------------------

open Internal

/// Creates empty context that remembers types of variables
let createEmptyContext () = (Map.empty : TransformContext)
       
/// Store variable value in the context
let declareVariableBinding (name:String) (ty:Type) (pval:TransformValue) (ctx:TransformContext) = 
  Map.add name ty ctx

/// This can modify the 'bindto' value to include declaration of the 'var' variable
/// Here, we add variable to the 'argcontext' of the function.
let bindVariable (var:String) (ty:Type) (pval:TransformValue) (bindto:TransformValue) =
  let bind f args = f (Map.add var (newVariable pval) args)
  match bindto with 
  | FloatMatrixValue f -> FloatMatrixValue ( fun args -> bind f args)
  | Float4MatrixValue f -> Float4MatrixValue ( fun args -> bind f args)
  | BoolMatrixValue f -> BoolMatrixValue ( fun args -> bind f args)
  | IntMatrixValue f -> IntMatrixValue ( fun args -> bind f args)
  | IntConst f -> IntConst ( fun args -> bind f args)
  | FloatConst f -> FloatConst ( fun args -> bind f args)
  | Float4Const f -> Float4Const ( fun args -> bind f args)
  | IntValue f -> IntValue ( fun args -> bind f args)
  | FloatValue f -> FloatValue ( fun args -> bind f args)

/// Read variable value (depending on the type of the variable, return appropriate value)      
let readBoundVariable (ctx:TransformContext) (name:String) = 
  // Extracts value using given destructor and wraps it into the desired constructor
  let readAndFormatVariable constr destr = 
    let (|Destr|_|) a = destr a
    constr (fun args -> 
      match readVariable name args with 
      | Destr v -> v args 
      | _ -> failwith "readBoundVariable - unexpected type of value" )
  match Map.find name ctx with
  // Handling of matrix-types
  | ty when ty = typeof<Matrix<float4>> ->
      readAndFormatVariable Float4MatrixValue (function Float4MatrixValue(v) -> Some(v) | _ -> None)
  | ty when ty = typeof<Matrix<int>> ->
      readAndFormatVariable IntMatrixValue (function IntMatrixValue(v) -> Some(v) | _ -> None)
  | ty when ty = typeof<Matrix<float32>> ->
      readAndFormatVariable FloatMatrixValue (function FloatMatrixValue(v) -> Some(v) | _ -> None)
  | ty when ty = typeof<Matrix<bool>> ->
      readAndFormatVariable BoolMatrixValue (function BoolMatrixValue(v) -> Some(v) | _ -> None)
  // Handling of scalar values
  | ty when ty = typeof<int> ->
      readAndFormatVariable IntConst (function IntConst(v) -> Some(v) | _ -> None)
  | ty when ty = typeof<float4> ->
      readAndFormatVariable Float4Const (function Float4Const(v) -> Some(v) | _ -> None)
  | ty when ty = typeof<float32> ->
      readAndFormatVariable FloatConst (function FloatConst(v) -> Some(v) | _ -> None)
  | _ -> failwith "readBoundVariable - unexpected type of variable in context!"

/// Wraps the returned function so it accepts EvalTransformation.TransformValue as a parameter
/// (this is used inside the Accelerate.fs module)
let wrapResultFunction pval names =
  let wrap f args = 
    f (List.zip names args |> List.fold (fun st (n,v) -> 
      Map.add n (newVariable (valueOfEvalValue v)) st ) Map.empty)
  match pval with 
  | FloatMatrixValue f -> ( fun args -> EvalTransformation.FloatMatrixValue (wrap f args) )
  | Float4MatrixValue f -> ( fun args -> EvalTransformation.Float4MatrixValue (wrap f args) )
  | BoolMatrixValue f -> ( fun args -> EvalTransformation.BoolMatrixValue (wrap f args) )
  | IntMatrixValue f -> ( fun args -> EvalTransformation.IntMatrixValue (wrap f args) )
  | IntValue f -> ( fun args -> EvalTransformation.IntValue (wrap f args) )
  | FloatValue f -> ( fun args -> EvalTransformation.FloatValue (wrap f args) )
  | _ -> failwith "wrapResultFunction - unexpected argument type"
    
//---------------------------------------------------------------------------------------
// Constructing parameters & decomposing to F# types
  
let makeIntConst v = IntConst (fun _ -> v)
let makeFloatConst v = FloatConst (fun _ -> v)
let makeFloat4Const v = Float4Const (fun _ -> v)

let makeIntMatrix fm = IntMatrixValue (let pa = new IPA(fm |> Matrix.toArray2D) in fun _ -> pa )
let makeFloatMatrix fm = FloatMatrixValue (let pa = new FPA(fm |> Matrix.toArray2D) in fun _ -> pa )
let makeFloat4Matrix fm = Float4MatrixValue (let pa = new F4PA(fm |> Matrix.toArray2D |> Array2D.map Float4.toAccFloat4) in fun _ -> pa )
let makeBoolMatrix bm = BoolMatrixValue (let pa = new BPA(bm |> Matrix.toArray2D) in fun _ -> pa )

/// Wraps any supported value into a 'TransformValue' used
/// internally by the translator.
let makeValue v = 
  match box v with
  | :? float32 as f -> makeFloatConst f
  | :? float4 as f -> makeFloat4Const f
  | :? int as i -> makeIntConst i
  | :? Matrix<int> as mi -> makeIntMatrix mi
  | :? Matrix<bool> as mb -> makeBoolMatrix mb
  | :? Matrix<float32> as mf -> makeFloatMatrix mf
  | :? Matrix<float4> as mf -> makeFloat4Matrix mf
  | _ -> failwithf "Not supported type of constant value (%s)!" (v.GetType().Name)
    
/// Evaluates the given accelerated function ('f') using Accelerator target 
/// provided as the first parameter ('target'). Arguments to the accelerated 
/// function are passed as a list of 'TransformValue' values (which can be 
/// constructed using 'makeValue' function).
let eval<'TResult> (target:Target) f args = EvalTransformation.eval<'TResult> target f args
  
//---------------------------------------------------------------------------------------
// BASICS - math, logical operations, comparison...
//---------------------------------------------------------------------------------------
  
let multiplyValues (a, b) = 
  match a,b with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue ( fun args -> PA.Multiply(fpa1 args, fpa2 args))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Multiply(fpa1 args, fpa2 args))
  | Float4MatrixValue f4pa1, Float4MatrixValue f4pa2 -> Float4MatrixValue ( fun args -> PA.Multiply(f4pa1 args, f4pa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.Multiply"
let addValues (a, b) = 
  match a,b with
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Add(fpa1 args, fpa2 args))
  | Float4MatrixValue f4pa1, Float4MatrixValue f4pa2 -> Float4MatrixValue ( fun args -> PA.Add(f4pa1 args, f4pa2 args))
  | IntMatrixValue ipa1, IntMatrixValue ipa2 -> IntMatrixValue ( fun args -> PA.Add(ipa1 args, ipa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.Add"
let subtractValues (a, b) = 
  match a,b with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue ( fun args -> PA.Subtract(fpa1 args, fpa2 args))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Subtract(fpa1 args, fpa2 args))
  | Float4MatrixValue fpa1, Float4MatrixValue fpa2 -> Float4MatrixValue ( fun args -> PA.Subtract(fpa1 args, fpa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.Subtract"
let minValues (a) = 
  match a with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue ( fun args -> PA.Min(fpa1 args, fpa2 args))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Min(fpa1 args, fpa2 args))
  | Float4MatrixValue fpa1, Float4MatrixValue fpa2 -> Float4MatrixValue ( fun args -> PA.Min(fpa1 args, fpa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.Min"
let maxValues (a) = 
  match a with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue ( fun args -> PA.Max(fpa1 args, fpa2 args))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Max(fpa1 args, fpa2 args))
  | Float4MatrixValue fpa1, Float4MatrixValue fpa2 -> Float4MatrixValue ( fun args -> PA.Max(fpa1 args, fpa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.Max"

let sqrtValue (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatMatrixValue ( fun args -> PA.Sqrt(fpa args))
  | Float4MatrixValue fpa -> Float4MatrixValue ( fun args -> PA.Sqrt(fpa args))
  | _ -> failwith "Not supported combination of arguments for PA.Sqrt"
let fractionValues (a) =             
  match a with
  | FloatMatrixValue fpa -> FloatMatrixValue ( fun args -> PA.Fraction(fpa args))
  | Float4MatrixValue f4pa -> Float4MatrixValue ( fun args -> PA.Fraction(f4pa args))
  | _ -> failwith "Not supported combination of arguments for PA.Fraction"
    
let logicalAndValues (a, b) = 
  match a,b with
  | BoolMatrixValue bpa1, BoolMatrixValue bpa2 -> BoolMatrixValue ( fun args -> PA.And(bpa1 args, bpa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.And"
let logicalOrValues (a, b) = 
  match a,b with
  | BoolMatrixValue bpa1, BoolMatrixValue bpa2 -> BoolMatrixValue ( fun args -> PA.Or(bpa1 args, bpa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.Or"
let compareValues (a, b) = 
  match a,b with
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> BoolMatrixValue ( fun args -> PA.CompareEqual(fpa1 args, fpa2 args))
  | IntMatrixValue ipa1, IntMatrixValue ipa2 -> BoolMatrixValue ( fun args -> PA.CompareEqual(ipa1 args, ipa2 args))
  | _ -> failwith "Not supported combination of arguments for PA.CompareEqual"
        
//---------------------------------------------------------------------------------------
// FOLDS
//---------------------------------------------------------------------------------------
  
let foldSumValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue ( fun args -> PA.Sum(fpa args))
  | IntMatrixValue ipa -> IntValue ( fun args -> PA.Sum(ipa args))
  | _ -> failwith "Not supported combination of arguments for PA.Sum"
let foldProdValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue ( fun args -> PA.Product(fpa args))
  | IntMatrixValue ipa -> IntValue ( fun args -> PA.Product(ipa args))
  | _ -> failwith "Not supported combination of arguments for PA.Product"
let foldMinValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue ( fun args -> PA.MinVal(fpa args))
  | IntMatrixValue ipa -> IntValue ( fun args -> PA.MinVal(ipa args))
  | _ -> failwith "Not supported combination of arguments for PA.MinVal"
let foldMaxValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue ( fun args -> PA.MaxVal(fpa args))
  | IntMatrixValue ipa -> IntValue ( fun args -> PA.MaxVal(ipa args))
  | _ -> failwith "Not supported combination of arguments for PA.MaxVal"

//---------------------------------------------------------------------------------------
// CONVERSIONS
//---------------------------------------------------------------------------------------

let toFloatValues (a) = 
  match a with
  | IntMatrixValue ipa -> FloatMatrixValue ( fun args -> PA.ToFloatParallelArray(ipa args))
  | BoolMatrixValue bpa -> FloatMatrixValue ( fun args -> let r = bpa args in PA.Cond(r, new FPA(1.0f, r.Shape), new FPA(0.0f, r.Shape)))
  | _ -> failwith "Not supported combination of arguments for toFloatValues"

let toFloat4Values (a) = 
  match a with
  | FloatMatrixValue fpa -> Float4MatrixValue ( fun args -> PA.ToFloat4ParallelArray(fpa args))
  | IntMatrixValue ipa -> Float4MatrixValue ( fun args -> PA.ToFloat4ParallelArray(PA.ToFloatParallelArray(ipa args)))
  | BoolMatrixValue bpa -> Float4MatrixValue ( fun args -> let r = bpa args in PA.ToFloat4ParallelArray(PA.Cond(r, new FPA(1.0f, r.Shape), new FPA(0.0f, r.Shape))))
  | _ -> failwith "Not supported combination of arguments for toFloat4Values"
  
let toIntValues (a) = 
  match a with
  | FloatMatrixValue fpa -> IntMatrixValue ( fun args -> PA.ToIntParallelArray(fpa args))
  | BoolMatrixValue bpa -> IntMatrixValue ( fun args -> let r = bpa args in PA.Cond(r, new IPA(1, r.Shape), new IPA(0, r.Shape) ))
  | _ -> failwith "Not supported combination of arguments for toIntValues"

let toBoolValues (a) = 
  match a with
  | FloatMatrixValue fpa -> BoolMatrixValue ( fun args -> let r = fpa args in PA.CompareNotEqual(r, new FPA(0.0f, r.Shape) ))
  | IntMatrixValue ipa -> BoolMatrixValue ( fun args -> let r = ipa args in PA.CompareNotEqual(r, new IPA(0, r.Shape) ))
  | _ -> failwith "Not supported combination of arguments for toBoolValues"
    
//---------------------------------------------------------------------------------------
// DATA-PARALLEL - operations provided by Accelerator
//---------------------------------------------------------------------------------------
  
let selectValues (tst, v1, v2) =
  match tst, v1, v2 with
  | FloatMatrixValue fts, FloatMatrixValue fv1, FloatMatrixValue fv2 -> 
      FloatMatrixValue ( fun args -> PA.Select(fts args, fv1 args, fv2 args))
  | IntMatrixValue its, IntMatrixValue iv1, IntMatrixValue iv2 -> 
      IntMatrixValue ( fun args -> PA.Select(its args, iv1 args, iv2 args))
  | FloatMatrixValue fts, IntMatrixValue iv1, IntMatrixValue iv2 -> 
      IntMatrixValue ( fun args -> PA.ToIntParallelArray( PA.Select(fts args, PA.ToFloatParallelArray(iv1 args), PA.ToFloatParallelArray(iv2 args)) ))
  | _ -> failwith "Not supported combination of arguments for PA.Select"

let padValues (expr, bf:int[], af, v) =
  match expr, v with
  | FloatMatrixValue fpa, FloatConst fv  -> FloatMatrixValue( fun args -> PA.Pad(fpa args, bf, af, fv args) )
  | Float4MatrixValue fpa, FloatConst fv  -> Float4MatrixValue( fun args -> PA.Pad(fpa args, bf, af, fv args) )
  | Float4MatrixValue fpa, Float4Const fv  -> Float4MatrixValue( fun args ->
      let fv = fv args
      if fv.Item1 = fv.Item2 && fv.Item1 = fv.Item3 && fv.Item1 = fv.Item4 then
        PA.Pad(fpa args, bf, af, fv.Item1)
      else
        failwith "Accelerator doesn't provide Pad function handling float4, constant should be float32" )
  | _ -> failwith "Not supported combination of arguments for PA.Pad"

let gatherValues (src, yind, xind) =
  let pos = 
    match yind, xind with 
    | IntMatrixValue yi, IntMatrixValue xi -> (fun args -> [|yi args; xi args|])
    | _ -> failwith "Not supported indices arguments for PA.Gather"
  match src with
  | FloatMatrixValue fpa -> FloatMatrixValue( fun args -> PA.Gather(fpa args, pos args) )
  | Float4MatrixValue f4pa -> Float4MatrixValue( fun args -> PA.Gather(f4pa args, pos args) )
  | BoolMatrixValue bpa -> BoolMatrixValue( fun args -> PA.Gather(bpa args, 0, pos args) )
  | IntMatrixValue ipa -> IntMatrixValue( fun args -> PA.Gather(ipa args, pos args) )
  | _ -> failwith "Not supported combination of arguments for PA.Gather"

let interpolateValues (a, b, c) =
  match a, b, c with
  | FloatMatrixValue fpa, FloatMatrixValue fpb, FloatMatrixValue fpc -> FloatMatrixValue( fun args -> PA.Interpolate(fpa args, fpb args, fpc args) )
  | Float4MatrixValue fpa, Float4MatrixValue fpb, Float4MatrixValue fpc -> Float4MatrixValue( fun args -> PA.Interpolate(fpa args, fpb args, fpc args) )
  | _ -> failwith "Not supported combination of arguments for PA.Interpolate"

let fillPositionValues (hex, wex, dind) =
  match hex, wex, dind with
  | IntConst ih, IntConst iw, IntConst idim -> 
    IntMatrixValue ( fun args -> PA.Positions([| ih args; iw args; |], idim args))
  | _ -> failwith "Not supported combination of arguments for PA.Positions"

let shiftValues (exp, edy, edx) =
  let sz = 
    match edx, edy with 
    | IntConst x, IntConst y -> ( fun args -> [|y args; x args|] ) 
    | _ -> failwith "Not supported offset arguments for PA.Shift"
  match exp with
  | FloatMatrixValue fpa -> FloatMatrixValue( fun args -> PA.Shift(fpa args, sz args) );
  | Float4MatrixValue fpa -> Float4MatrixValue( fun args -> PA.Shift(fpa args, sz args) );
  | IntMatrixValue ipa -> IntMatrixValue( fun args -> PA.Shift(ipa args, sz args) );
  | _ -> failwith "Not supported combination of arguments for PA.Shift"
    
let rotateValues (exp, edy, edx) =
  let sz = 
    match edx, edy with 
    | IntConst x, IntConst y -> ( fun args -> [|y args; x args|] ) 
    | _ -> failwith "Not supported offset arguments for PA.Rotate"
  match exp with
  | FloatMatrixValue fpa -> FloatMatrixValue ( fun args -> PA.Rotate(fpa args, sz args))
  | IntMatrixValue ipa -> IntMatrixValue ( fun args -> PA.ToIntParallelArray(PA.Rotate(PA.ToFloatParallelArray(ipa args), sz args)))
  | _ -> failwith "Not supported combination of arguments for PA.Rotate"

//---------------------------------------------------------------------------------------
// CONSTANTS - creating constant matrices
//---------------------------------------------------------------------------------------
    
let getConstMatrixKnownSize (shape:int []) value =
  match value with 
  | FloatConst f -> FloatMatrixValue(fun args -> new FPA(f args, shape))
  | IntConst i -> IntMatrixValue(fun args -> new IPA(i args, shape))
  | _ -> failwith "Not supported argument for getConstMatrixKnownSize"
 
let getConstMatrixSameSize matrix value =
  let shape = 
    match matrix with 
    | FloatMatrixValue fpa -> ( fun args -> (fpa args).Shape )
    | Float4MatrixValue f4pa -> ( fun args -> (f4pa args).Shape )
    | IntMatrixValue ipa -> ( fun args -> (ipa args).Shape )
    | _ -> failwith "Not supported matrix argument for getConstMatrixSameSize"
  match value with 
  | FloatConst f -> FloatMatrixValue( fun args -> new FPA(f args, shape args))
  | IntConst i -> IntMatrixValue( fun args -> new IPA(i args, shape args))
  | Float4Const f -> Float4MatrixValue( fun args -> new F4PA((let f = f args in new AccFloat4(f.Item1,f.Item2,f.Item3,f.Item4)), shape args))
  | _ -> failwith "Not supported value argument for getConstMatrixSameSize"
