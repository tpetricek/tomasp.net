//---------------------------------------------------------------------------------------
// EVALUATING TRANFORMATION 
//---------------------------------------------------------------------------------------
// This module provides primitive functions that are used to construct computations
// during the translation (from Accelerate.fs). In this module, we directly 
// evaluate (interpret) the code, so we calculate the result as the translator 
// analyzes quotations.
//
// This isn't as efficient, because we need to analyze quotoations again each time
// we run the function. However, the code is easy to understand. A more sophisticated
// approach is available in CompileTransformation.fs.
//---------------------------------------------------------------------------------------
module FSharp.Accelerator.EvalTransformation

open System
open Microsoft.FSharp.Math
open Microsoft.ParallelArrays

open FSharp
open FSharp.Math
open FSharp.Math.DataParallel

type AccFloat4 = Microsoft.ParallelArrays.Float4
type FPA = Microsoft.ParallelArrays.FloatParallelArray
type F4PA = Microsoft.ParallelArrays.Float4ParallelArray
type IPA = Microsoft.ParallelArrays.IntParallelArray
type BPA = Microsoft.ParallelArrays.BoolParallelArray
type PA = Microsoft.ParallelArrays.ParallelArrays

module Matrix = Math.Matrix.Generic

//---------------------------------------------------------------------------------------

/// The TransformContext type is kept as a parameter during the translation
/// in this module we use it for remembering values bound to variables
type TransformContext = Map<String, TransformValue> 

/// The TransformValue type represents the result of convertsion
and TransformValue =
  | FloatMatrixValue of FPA
  | Float4MatrixValue of F4PA
  | IntMatrixValue of IPA
  | BoolMatrixValue of BPA
  
  | FloatValue of FPA
  | IntValue of IPA
  
  | FloatConst of float32
  | Float4Const of float4
  | IntConst of int

//---------------------------------------------------------------------------------------
// CONTEXT AND VARIABLES - here we use context to store values of variables
//---------------------------------------------------------------------------------------

/// Creates empty context that is kept during the translation
let createEmptyContext() = (Map.empty : TransformContext)

/// Store variable value in the context
let declareVariableBinding (name:string) (ty:Type) (pval:TransformValue) (ctx:TransformContext) = 
  (match Map.tryFind name ctx with
   | None -> ctx
   | _ -> Map.remove name ctx) |> Map.add name pval

/// This can modify the 'bindto' value to include declaration of the 'var' variable
/// (we don't need it when evaluating expressions immediately)
let bindVariable (var:string) (ty:Type) (pval:TransformValue) (bindto:TransformValue) =
  bindto

/// Read the value from the context
let readBoundVariable (ctx:TransformContext) (name:String) = ctx.[name]

//---------------------------------------------------------------------------------------

module Internal = 
  /// Dispose all the disposable (IPA, FPA, F4PA..) parameters 
  let applyAndDispose (args:_ list) f =
    let res = f() 
    for a in args do
      match a with
      | Float4MatrixValue mf -> mf.Dispose()
      | FloatMatrixValue mf -> mf.Dispose()
      | IntMatrixValue mf -> mf.Dispose()
      | BoolMatrixValue mf -> mf.Dispose()
      | _ -> ()
    res  

  /// Evaluate accelerated code (function 'f') with the specified parameters
  /// (a list 'args'), dispose arguments. Extract the specified type of 
  /// result using 'recognizer' and format it using 'formatter'
  /// The function casts result to 'TResult' type parameter.
  let evalGeneric<'TResult, 'TValue, 'TReturned> 
      (recognizer : TransformValue -> 'TValue option) 
      (formatter  : 'TValue -> 'TReturned) f args =     
    let (|ValueRecognizer|_|) e = recognizer e
    applyAndDispose args (fun () -> 
      match (f args) with 
      | ValueRecognizer x -> 
        Utils.printTime "Executing Accelerator code" (fun () -> 
          x |> formatter |> unbox<'TResult>)
      | _ -> failwith "Evaluation failed - requested different value type than available.")
  
//---------------------------------------------------------------------------------------
// Constructing parameters & decomposing to F# types

open Internal

let makeIntConst v = IntConst v
let makeFloatConst v = FloatConst v
let makeFloat4Const v = Float4Const v

let makeIntMatrix fm = IntMatrixValue(new IPA(fm |> Matrix.toArray2D))
let makeFloatMatrix fm = FloatMatrixValue(new FPA(fm |> Matrix.toArray2D))
let makeFloat4Matrix fm = Float4MatrixValue(new F4PA(fm |> Matrix.toArray2D |> Array2D.map Float4.toAccFloat4))
let makeBoolMatrix bm = BoolMatrixValue(new BPA(bm |> Matrix.toArray2D))

/// Wraps any supported value into a 'TransformValue' used
/// internally by the translator.
let makeValue v = 
  match box v with
  | :? float32 as f -> makeFloatConst f
  | :? float4 as f -> makeFloat4Const f
  | :? int as i -> makeIntConst i
  | :? Matrix<int> as mi -> makeIntMatrix mi
  | :? Matrix<bool> as mb -> makeBoolMatrix mb
  | :? Matrix<float32> as mf -> makeFloatMatrix mf
  | :? Matrix<float4> as mf -> makeFloat4Matrix mf
  | _ -> failwithf "Not supported type of constant value (%s)!" (v.GetType().Name)

/// Evaluates the given accelerated function ('f') using Accelerator target 
/// provided as the first parameter ('target'). Arguments to the accelerated 
/// function are passed as a list of 'TransformValue' values (which can be 
/// constructed using 'makeValue' function).
let eval<'TResult> (target:Target) f args = 
  match typeof<'TResult> with 
  // Cases that evaluate to a result of type Matrix<'T> for some 'T
  | t when t = typeof<Matrix<float32>> ->
      evalGeneric<'TResult, _, _> 
        (function FloatMatrixValue(v) -> Some(v) | _ -> None) 
        (target.ToArray2D >> Matrix.ofArray2D) 
        f args
  | t when t = typeof<Matrix<float4>> ->
      evalGeneric<'TResult, _, _>
        (function Float4MatrixValue(v) -> Some(v) | _ -> None)
        (target.ToArray2D >> Array2D.map Float4.ofAccFloat4 >> Matrix.ofArray2D)
        f args
  | t when t = typeof<Matrix<bool>> ->
      evalGeneric<'TResult, _, _>
        (function BoolMatrixValue(v) -> Some(v) | _ -> None) 
        (target.ToArray2D >> Matrix.ofArray2D)
        f args
  | t when t = typeof<Matrix<int>> ->
      evalGeneric<'TResult, _, _>
        (function IntMatrixValue(v) -> Some(v) | _ -> None) 
        (target.ToArray2D >> Matrix.ofArray2D)
        f args
  
  // Cases that evaluate to a result of some scalar value
  | t when t = typeof<int> ->
      evalGeneric<'TResult, _, _>
        (function IntValue(v) -> Some(v) | _ -> None) 
        (fun v -> target.ToArray1D(v).[0])
        f args
  | t when t = typeof<float32> ->
      evalGeneric<'TResult, _, _>
        (function FloatValue(v) -> Some(v) | _ -> None) 
        (fun v -> target.ToArray1D(v).[0])
        f args
        
  | t -> failwithf "Cannot evaluate accelerated code to value of type %s" t.Name

//---------------------------------------------------------------------------------------
// BASICS - math, logical operations, comparison...
//---------------------------------------------------------------------------------------

let multiplyValues (a, b) = 
  match a,b with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue (PA.Multiply(fpa1, fpa2))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue (PA.Multiply(fpa1, fpa2))
  | Float4MatrixValue f4pa1, Float4MatrixValue f4pa2 -> Float4MatrixValue (PA.Multiply(f4pa1, f4pa2))
  | _ -> failwith "Not supported combination of arguments for PA.Multiply"
let addValues (a, b) = 
  match a,b with
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue (PA.Add(fpa1, fpa2))
  | Float4MatrixValue f4pa1, Float4MatrixValue f4pa2 -> Float4MatrixValue (PA.Add(f4pa1, f4pa2))
  | IntMatrixValue ipa1, IntMatrixValue ipa2 -> IntMatrixValue (PA.Add(ipa1, ipa2))
  | _ -> failwith "Not supported combination of arguments for PA.Add"      
let subtractValues (a, b) = 
  match a,b with
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue (PA.Subtract(fpa1, fpa2))
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue (PA.Subtract(fpa1, fpa2))
  | Float4MatrixValue fpa1, Float4MatrixValue fpa2 -> Float4MatrixValue (PA.Subtract(fpa1, fpa2))
  | _ -> failwith "Not supported combination of arguments for PA.Subtract"       
let minValues (a, b) = 
  match a,b with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue (PA.Min(fpa1, fpa2))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue (PA.Min(fpa1, fpa2))
  | Float4MatrixValue fpa1, Float4MatrixValue fpa2 -> Float4MatrixValue (PA.Min(fpa1, fpa2))
  | _ -> failwith "Not supported combination of arguments for PA.Min"       
let maxValues (a, b) = 
  match a,b with
  | IntMatrixValue fpa1, IntMatrixValue fpa2 -> IntMatrixValue (PA.Max(fpa1, fpa2))
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue (PA.Max(fpa1, fpa2))
  | Float4MatrixValue fpa1, Float4MatrixValue fpa2 -> Float4MatrixValue (PA.Max(fpa1, fpa2))
  | _ -> failwith "Not supported combination of arguments for PA.Max"

let sqrtValue (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatMatrixValue (PA.Sqrt(fpa))
  | Float4MatrixValue fpa -> Float4MatrixValue (PA.Sqrt(fpa))
  | _ -> failwith "Not supported combination of arguments for PA.Sqrt"
let fractionValues (a) =             
  match a with
  | FloatMatrixValue fpa -> FloatMatrixValue (PA.Fraction(fpa))
  | Float4MatrixValue f4pa -> Float4MatrixValue (PA.Fraction(f4pa))
  | _ -> failwith "Not supported combination of arguments for PA.Fraction"
       
let logicalAndValues (a, b) = 
  match a,b with
  | BoolMatrixValue bpa1, BoolMatrixValue bpa2 -> BoolMatrixValue (PA.And(bpa1, bpa2))
  | _ -> failwith "Not supported combination of arguments for PA.And"
let logicalOrValues (a, b) = 
  match a,b with
  | BoolMatrixValue bpa1, BoolMatrixValue bpa2 -> BoolMatrixValue (PA.Or(bpa1, bpa2))
  | _ -> failwith "Not supported combination of arguments for PA.Or"
let compareValues (a, b) = 
  match a,b with
  | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> BoolMatrixValue (PA.CompareEqual(fpa1, fpa2))
  | IntMatrixValue ipa1, IntMatrixValue ipa2 -> BoolMatrixValue (PA.CompareEqual(ipa1, ipa2))
  | _ -> failwith "Not supported combination of arguments for PA.CompareEqual"
      
//---------------------------------------------------------------------------------------
// FOLDS
//---------------------------------------------------------------------------------------

let foldSumValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue (PA.Sum(fpa))
  | IntMatrixValue ipa -> IntValue (PA.Sum(ipa))
  | _ -> failwith "Not supported combination of arguments for PA.Sum"
let foldProdValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue (PA.Product(fpa))
  | IntMatrixValue ipa -> IntValue (PA.Product(ipa))
  | _ -> failwith "Not supported combination of arguments for PA.Product"
let foldMinValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue (PA.MinVal(fpa))
  | IntMatrixValue ipa -> IntValue (PA.MinVal(ipa))
  | _ -> failwith "Not supported combination of arguments for PA.MinVal"
let foldMaxValues (a) = 
  match a with
  | FloatMatrixValue fpa -> FloatValue (PA.MaxVal(fpa))
  | IntMatrixValue ipa -> IntValue (PA.MaxVal(ipa))
  | _ -> failwith "Not supported combination of arguments for PA.MaxVal"

//---------------------------------------------------------------------------------------
// CONVERSIONS
//---------------------------------------------------------------------------------------

let toFloatValues (a) = 
  match a with
  | IntMatrixValue ipa -> FloatMatrixValue (PA.ToFloatParallelArray(ipa))
  | BoolMatrixValue bpa -> FloatMatrixValue (PA.Cond(bpa, new FPA(1.0f, bpa.Shape), new FPA(0.0f, bpa.Shape)))
  | _ -> failwith "Not supported combination of arguments for toFloatValues"
  
let toFloat4Values (a) = 
  match a with
  | IntMatrixValue ipa -> Float4MatrixValue (PA.ToFloat4ParallelArray(PA.ToFloatParallelArray(ipa)))
  | FloatMatrixValue fpa -> Float4MatrixValue (PA.ToFloat4ParallelArray(fpa))
  | BoolMatrixValue bpa -> Float4MatrixValue (PA.ToFloat4ParallelArray(PA.Cond(bpa, new FPA(1.0f, bpa.Shape), new FPA(0.0f, bpa.Shape))))
  | _ -> failwith "Not supported combination of arguments for toFloat4Values"

let toIntValues (a) = 
  match a with
  | FloatMatrixValue fpa -> IntMatrixValue (PA.ToIntParallelArray(fpa))
  | BoolMatrixValue bpa -> IntMatrixValue (PA.Cond(bpa, new IPA(1, bpa.Shape), new IPA(0, bpa.Shape) ))
  | _ -> failwith "Not supported combination of arguments for toIntValues"
  
let toBoolValues (a) = 
  match a with
  | FloatMatrixValue fpa -> BoolMatrixValue (PA.CompareNotEqual(fpa, new FPA(0.0f, fpa.Shape) ))
  | IntMatrixValue ipa -> BoolMatrixValue (PA.CompareNotEqual(ipa, new IPA(0, ipa.Shape) ))
  | _ -> failwith "Not supported combination of arguments for toBoolValues"
    
//---------------------------------------------------------------------------------------
// DATA-PARALLEL - operations provided by Accelerator
//---------------------------------------------------------------------------------------

let selectValues (tst, v1, v2) =
  match tst, v1, v2 with
  | FloatMatrixValue fts, FloatMatrixValue fv1, FloatMatrixValue fv2 -> 
      FloatMatrixValue (PA.Select(fts, fv1, fv2))
  | IntMatrixValue its, IntMatrixValue iv1, IntMatrixValue iv2 -> 
      IntMatrixValue (PA.Select(its, iv1, iv2))
  | FloatMatrixValue fts, IntMatrixValue iv1, IntMatrixValue iv2 -> 
      IntMatrixValue (PA.ToIntParallelArray(PA.Select(fts, PA.ToFloatParallelArray(iv1), PA.ToFloatParallelArray(iv2)) ))
  | _ -> failwith "Not supported combination of arguments for PA.Select"

let padValues (expr, bf:int[], af, v) =
  match expr, v with
  | FloatMatrixValue fpa, FloatConst fv  -> FloatMatrixValue( PA.Pad(fpa, bf, af, fv) )
  | Float4MatrixValue fpa, FloatConst fv  -> Float4MatrixValue( PA.Pad(fpa, bf, af, fv) )
  | Float4MatrixValue fpa, Float4Const fv  -> 
      if fv.Item1 = fv.Item2 && fv.Item1 = fv.Item3 && fv.Item1 = fv.Item4 then
        Float4MatrixValue(PA.Pad(fpa, bf, af, fv.Item1) )
      else
        failwith "Accelerator doesn't provide Pad function handling float4, constant should be float32"
  | _ -> failwith "Not supported combination of arguments for PA.Pad"

let gatherValues (src, yind, xind) =
  let pos = 
    match yind, xind with 
    | IntMatrixValue yi, IntMatrixValue xi -> [|yi; xi|] 
    | _ -> failwith "Not supported indices arguments for PA.Gather"
  match src with
  | FloatMatrixValue fpa -> FloatMatrixValue( PA.Gather(fpa, pos) )
  | Float4MatrixValue f4pa -> Float4MatrixValue( PA.Gather(f4pa, pos) )
  | BoolMatrixValue bpa -> BoolMatrixValue( PA.Gather(bpa, 0, pos) ) // NOTE: additional parameter that's not used - Accelerator issue
  | IntMatrixValue ipa -> IntMatrixValue( PA.Gather(ipa, pos) )
  | _ -> failwith "Not supported combination of arguments for PA.Gather"

let interpolateValues (a, b, c) =
  match a, b, c with
  | FloatMatrixValue fpa, FloatMatrixValue fpb, FloatMatrixValue fpc -> FloatMatrixValue( PA.Interpolate(fpa, fpb, fpc) )
  | Float4MatrixValue fpa, Float4MatrixValue fpb, Float4MatrixValue fpc -> Float4MatrixValue( PA.Interpolate(fpa, fpb, fpc) )
  | _ -> failwith "Not supported combination of arguments for PA.Interpolate"

let fillPositionValues (hex, wex, dind) =
  match hex, wex, dind with
  | IntConst ih, IntConst iw, IntConst idim -> 
    IntMatrixValue (PA.Positions([| ih; iw; |], idim))
  | _ -> failwith "Not supported combination of arguments for PA.Positions"

let shiftValues (exp, edy, edx) =
  let sz = 
    match edx, edy with 
    | IntConst x, IntConst y -> [|y; x|] 
    | _ -> failwith "Not supported offset arguments for PA.Shift"
  match exp with
  | FloatMatrixValue fpa -> FloatMatrixValue( PA.Shift(fpa, sz) );
  | Float4MatrixValue fpa -> Float4MatrixValue( PA.Shift(fpa, sz) );
  | IntMatrixValue ipa -> IntMatrixValue( PA.Shift(ipa, sz) );
  | _ -> failwith "Not supported combination of arguments for PA.Shift"
    
let rotateValues (exp, edy, edx) =
  let sz = 
    match edx, edy with 
    | IntConst x, IntConst y -> [|y; x|] 
    | _ -> failwith "Not supported offset arguments for PA.Rotate"
  match exp with
  | FloatMatrixValue fpa -> FloatMatrixValue (PA.Rotate(fpa, sz))
  | IntMatrixValue ipa -> IntMatrixValue (PA.Rotate(ipa, sz))
  | _ -> failwith "Not supported combination of arguments for PA.Rotate"
  
//---------------------------------------------------------------------------------------
// CONSTANTS - creating constant matrices
//---------------------------------------------------------------------------------------
  
let getConstMatrixKnownSize (shape:int []) value =
  match value with 
  | FloatConst f -> FloatMatrixValue(new FPA(f, shape))
  | IntConst i -> IntMatrixValue(new IPA(i, shape))
  | _ -> failwith "Not supported argument for getConstMatrixKnownSize"

let getConstMatrixSameSize matrix value =
  let shape = 
    match matrix with 
    | FloatMatrixValue fpa -> fpa.Shape
    | Float4MatrixValue f4pa -> f4pa.Shape
    | IntMatrixValue ipa -> ipa.Shape
    | _ -> failwith "Not supported matrix argument for getConstMatrixSameSize"
  match value with 
  | FloatConst f -> FloatMatrixValue(new FPA(f, shape))
  | IntConst i -> IntMatrixValue(new IPA(i, shape))
  | Float4Const f -> Float4MatrixValue(new F4PA(new AccFloat4(f.Item1,f.Item2,f.Item3,f.Item4), shape))
  | _ -> failwith "Not supported value argument for getConstMatrixSameSize"
