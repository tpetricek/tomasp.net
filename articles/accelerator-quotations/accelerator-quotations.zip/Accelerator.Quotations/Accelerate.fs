//---------------------------------------------------------------------------------------
// ACCELERATE - transforms F# quotations of data-parallel code to use Accelerator
//---------------------------------------------------------------------------------------
// We can use either 'EvalTransformations' or 'CompileTransformations'. In the first 
// case, the accelerator functions are called during the translation of F# quotations. 
// This is easier to debug and read, but the performance isn't very good, because
// the quotations representing the tree are analysed every time when the function is 
// executed. 
//
// In the second case, the 'accelerate' function builds and returns a function that
// takes all the parameters, calls Accelerator functions and returns result. This
// means that the quotations is analysed only for the first time and the performance
// is much better. 

namespace FSharp.Accelerator

open System
open Microsoft.FSharp.Math
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Patterns
open Microsoft.FSharp.Quotations.DerivedPatterns

open FSharp.Math
open FSharp.Math.DataParallel
open FSharp.Math.DataParallel.Conversions
open FSharp.Quotations

module Matrix = Math.Matrix.Generic

#if COMPILE_TRANSFORM
open FSharp.Accelerator.CompileTransformation
#else  
open FSharp.Accelerator.EvalTransformation
#endif

//---------------------------------------------------------------------------------------
// EXPANDABLE LIST
//---------------------------------------------------------------------------------------

/// Functions in this module are expanded by the translator.
/// This means that if you use one of the following functions, you'll have
/// to include the last parameter inside quotation "<@ foo value @>"
module ExpandableList = 

  /// Fold that sends index as a parameter to the provided function
  let foldIndex (f : int -> 'a -> 'b -> 'a) (acc: 'a) (lst:'b list) =
    let rec foldIndex' n f acc lst =
      match lst with 
        | a::r -> foldIndex' (n+1) f (f n acc a) r
        | [] -> acc;
    foldIndex' 0 f acc lst
  
  /// Standard fold function
  let fold = List.fold

  /// Fold that sends index as a parameter to the provided function and works on tuple types
  let foldTuplesIndex (f : int -> 'a -> 'b -> 'c -> 'a) (acc: 'a) (lst:('b * 'c) list) =
    let rec foldTuplesIndex' n f acc lst =
      match lst with 
        | (a,b)::r -> foldTuplesIndex' (n+1) f (f n acc a b) r
        | [] -> acc;
    foldTuplesIndex' 0 f acc lst

  // Standard fold that works on tuple types
  let foldTuples (f : 'a -> 'b -> 'c -> 'a) (acc: 'a) (lst:('b * 'c) list) =
    foldTuplesIndex (fun _ a b c -> f a b c) acc lst

//---------------------------------------------------------------------------------------
// ACCELERATION
//---------------------------------------------------------------------------------------

module Accelerate =     

  /// Language that the translator understands (this should mostly
  /// correspond to the functions from DataParallel.fsi)
  let lang = 
    [ 
      // matrix operations
      <@@ matrixConstant @@>; <@@ matrixBinaryBuiltin @@>;
      <@@ matrixUnaryOperation @@>; <@@ matrixBinaryOperation @@>;
      
      // operations on matrix elements
      <@@ Internal.cptAdd @@>; <@@ Internal.cptMul @@>; <@@ Internal.cptSub @@>; 
      <@@ Internal.cptMax @@>; <@@ Internal.cptMin @@>; 
      <@@ Internal.boolAnd @@>; <@@ Internal.boolOr @@>; <@@ Internal.genericEquality @@>;
      
      // generic functions
      <@@ shift @@>; <@@ rotate @@>; <@@ select @@>; <@@ positions @@>; 
      <@@ pad @@>; <@@ gather @@>; <@@ pointwiseSqrt @@>; <@@ pointwiseSqrtf4 @@>; 
      <@@ fraction @@>; <@@ fractionf4 @@>; <@@ interpolate @@>; <@@ interpolatef4 @@>; 

      // conversion
      <@@ Internal.singleOfInt @@>; <@@ Internal.singleOfBool @@>;
      <@@ Internal.intOfSingle @@>; <@@ Internal.intOfBool @@>; 
      <@@ Internal.boolOfSingle @@>; <@@ Internal.boolOfInt @@>;
      <@@ Internal.float4OfSingle @@>; <@@ Internal.float4OfInt @@>; <@@ Internal.float4OfBool @@>; 
      
      // reductions      
      <@@ matrixGenericFold @@>; <@@ Internal.prodFoldOp @@>; <@@ Internal.sumFoldOp @@>; 
      <@@ Internal.minFoldOp @@>; <@@ Internal.maxFoldOp @@>; 
      
      // expandable functions
      <@@ ExpandableList.fold @@>; <@@ ExpandableList.foldIndex @@>;
      <@@ ExpandableList.foldTuples @@>; <@@ ExpandableList.foldTuplesIndex @@>
      
      // constants
      <@@ float4 @@>
    ]

  //---------------------------------------------------------------------------------------
  // PATTERNS
  //---------------------------------------------------------------------------------------

  /// Constant of type Float4
  let (|Float4|_|) = function
    | SpecificCall <@@ float4 @@> (None, [], [Value(v1, _); Value(v2, _); Value(v3, _); Value(v4, _)]) ->
       Some(float4(v1 :?> float32, v2 :?> float32, v3 :?> float32, v4 :?> float32))
    | _ -> None
    
  /// Is the expression tuple with two int values?
  let (|SizeTuple|_|) = function
    | Int32(w), Int32(h) -> Some [|w; h|] 
    | _ -> None

  /// Is the expression reading of dimension of matrix stored in variable?
  let (|SameDimension|_|) = function
    | TupleGet(MatchExpressions <@@ (hole:Matrix<TypeHole>).Dimensions @@> [Var(v1)], 0),
      TupleGet(MatchExpressions <@@ (hole:Matrix<TypeHole>).Dimensions @@> [Var(v2)], 1) when v1 = v2 -> Some(v1.Name)
    | _ -> None

  /// Is expression lambda function with more than one parameter?
  let (|AnyLambdas|_|) = function 
    | Lambdas(args,e) when args <> [] -> Some(args, e)
    | _ -> None

  /// Is the expression lambda returning constant value?      
  let (|ConstantValue|_|) ctx = function
    | Value(:? float32 as v, _) 
    | Single v -> Some(makeFloatConst v) 
    | Value(:? int as i, _) 
    | Int32 i -> Some(makeIntConst i) 
    | Value(:? float4 as v, _) 
    | Float4 v -> Some(makeFloat4Const v)
    | Var v -> Some(readBoundVariable ctx v.Name)
    | _ -> None
                    
  /// Matches specified F# function (represented as .NET method) converted 
  /// to a function value - F# compiler translates <@@ foo @@> to
  /// <@@ (fun x y -> foo x y) @@> inside quotations (but sometimes
  /// also uses the usual quotation <@@ foo @@>)
  let (|SpecificFunctionValue|_|) expr arg = 
    match expr with
    | Lambdas(vars, (SpecificCall arg ((inst, ty, args) as res))) when vars <> [] && args.Length = vars.Length -> Some(res)
    | SpecificCall arg res -> Some(res)
    | _ -> None

  /// Value embedded inside a quotation
  let (|LiftedValue|_|) e = 
    match e with 
    | PropertyGet (None, prop, []) ->
      Some(prop.GetGetMethod().Invoke(null, [| |]))
    | _ -> None

  /// Converts Tuple<A,B> type stored in obj to Tuple<obj, obj>
  let convToTuple o =
    let a = (new obj(), new obj()) :> obj in
    let tupty = a.GetType().GetGenericTypeDefinition().MakeGenericType((o :> obj).GetType().GetGenericArguments())    
    let i1 = tupty.GetProperty("Item1").GetValue(o, [| |]);
    let i2 = tupty.GetProperty("Item2").GetValue(o, [| |]);
    (i1, i2);
    
  /// Extracts 'obj list' from expression containing ''a list' as a lifted value.
  let extractLiftedList lv : obj list = 
    match lv with 
    | LiftedValue(list) | Value(list, _) -> 
      [ for a in (list :?> System.Collections.IEnumerable) -> a ]
    | _ -> failwith "List passed as a parameter to expandable functions must be stored as a lifted value!"

  /// Returns Some if the list of lists contains only single-element lists
  let rec (|FlatList|_|) list = 
    match list with 
    | [] -> Some([])
    | [v]::(FlatList res) -> Some(v::res)
    | _ -> None
    
  /// Matches one of the expandable fold functions and returns appropriate parameters
  let (|ExpandableFold|_|) tdef e =
    match e with
    | SpecificCall tdef (None, _, [le; einit; liftedList]) ->
      match le with
      | Lambdas(FlatList(vars), lexpr) when vars <> [] -> 
          let ll = extractLiftedList liftedList
          let lvars = vars |> List.map ( fun v -> v.Name )
          let ltypes = vars |> List.map ( fun v -> v.Type )
          Some (einit, lexpr, lvars, ltypes, ll)
      | _ -> failwith "Function parameter of expandable functions must be lambda expression (with flat parameters)!"
    | _ -> None

  //---------------------------------------------------------------------------------------
  // TRANSFORMATIONS - translates quotations of primitive operations using 
  // functions from the specified 'Transformation' module
  //---------------------------------------------------------------------------------------
                
  /// Builtin binary operators                
  let transformBinaryBuiltinOperation (a1:TransformValue) (a2:TransformValue) opf =
    match opf with 
    | SpecificFunctionValue <@@ Internal.cptMul @@> _ -> multiplyValues (a1, a2)
    | SpecificFunctionValue <@@ Internal.cptAdd @@> _ -> addValues (a1, a2)
    | SpecificFunctionValue <@@ Internal.cptSub @@> _ -> subtractValues (a1, a2)
    | SpecificFunctionValue <@@ Internal.cptMax @@> _ -> maxValues (a1, a2)
    | SpecificFunctionValue <@@ Internal.cptMin @@> _ -> minValues (a1, a2)
    | _ -> failwithf "Unknown builtin binary operator: %A" opf

  /// Reduce functions
  let transformFold e (a:TransformValue) =
    match e with 
    | SpecificFunctionValue <@@ Internal.sumFoldOp @@>  _ -> foldSumValues a
    | SpecificFunctionValue <@@ Internal.prodFoldOp @@> _ -> foldProdValues a
    | SpecificFunctionValue <@@ Internal.minFoldOp @@>  _ -> foldMinValues a
    | SpecificFunctionValue <@@ Internal.maxFoldOp @@>  _ -> foldMaxValues a
    | _ -> failwithf "Unknown reduce operator: %A" e

  /// Unary operators - conversions
  let transformUnaryOperation e opf =
    match opf with 
    | SpecificFunctionValue <@@ Internal.singleOfBool @@> _   -> toFloatValues e
    | SpecificFunctionValue <@@ Internal.singleOfInt @@> _    -> toFloatValues e
    | SpecificFunctionValue <@@ Internal.intOfBool @@> _      -> toIntValues e
    | SpecificFunctionValue <@@ Internal.intOfSingle @@> _    -> toIntValues e
    | SpecificFunctionValue <@@ Internal.boolOfInt @@> _      -> toBoolValues e
    | SpecificFunctionValue <@@ Internal.boolOfSingle @@> _   -> toBoolValues e
    | SpecificFunctionValue <@@ Internal.float4OfSingle @@> _ -> toFloat4Values e
    | SpecificFunctionValue <@@ Internal.float4OfBool @@> _   -> toFloat4Values e
    | SpecificFunctionValue <@@ Internal.float4OfInt @@> _    -> toFloat4Values e
    | _ -> failwithf "Unknown unary matrix operation: %A" opf
        
  /// Binary operators
  let transformBinaryOperation e1 e2 opf =
    match opf with 
    | SpecificFunctionValue <@@ Internal.boolAnd @@> _ -> 
        logicalAndValues (e1,e2)
    | SpecificFunctionValue <@@ Internal.boolOr @@>  _ -> 
        logicalOrValues (e1,e2)
    | SpecificFunctionValue <@@ Internal.genericEquality @@>  _ -> 
        compareValues (e1,e2)
    | _ -> failwithf "Unknown binary matrix operation: %A" opf

  //---------------------------------------------------------------------------------------
  // MAIN - the main recursive quotation-processing function
  //---------------------------------------------------------------------------------------

  /// Declare bindings of multiple variables 
  let declareVariableBindings (names:String list) (types:Type list) (values:TransformValue list) ctx = 
    List.zip3 names types values |> List.fold (fun st (n,t,v) -> 
      declareVariableBinding n t v st) ctx

  /// Bind multiple variables
  let bindVariables (names:String list) (types:Type list) (values:TransformValue list) ctx = 
    List.zip3 names types values |> List.fold (fun st (n,t,v) -> 
      bindVariable n t v st) ctx
    
  // The main recursive function
  let rec transformExpr (ctx:TransformContext) e = 
    match e with
    // Expandable functions 
    | ExpandableFold <@@ ExpandableList.fold @@> (einit, lexpr, lvars, ltypes, ll) ->
        ll |> ExpandableList.fold (fun st v -> 
            let nctx = declareVariableBindings lvars ltypes [st; makeValue v] ctx
            bindVariables lvars ltypes [st; makeValue v] (transformExpr nctx lexpr)
          )  (transformExpr ctx einit)

    | ExpandableFold <@@ ExpandableList.foldIndex @@> (einit, lexpr, lvars, ltypes, ll) ->
        ll |> ExpandableList.foldIndex (fun i st v -> 
            let nctx = declareVariableBindings lvars ltypes [makeIntConst i; st; makeValue v] ctx
            bindVariables lvars ltypes [makeIntConst i; st; makeValue v] (transformExpr nctx lexpr)              
          )  (transformExpr ctx einit)

    | ExpandableFold <@@ ExpandableList.foldTuplesIndex @@> (einit, lexpr, lvars, ltypes, ll) ->
        let tl = ll |> List.map convToTuple
        tl |> ExpandableList.foldTuplesIndex (fun i st a b -> 
            let nctx = declareVariableBindings lvars ltypes [makeIntConst i; st; makeValue a; makeValue b] ctx
            bindVariables lvars ltypes [makeIntConst i; st; makeValue a; makeValue b] (transformExpr nctx lexpr)
          )  (transformExpr ctx einit)

    | ExpandableFold <@@ ExpandableList.foldTuples @@> (einit, lexpr, lvars, ltypes, ll) ->
        let tl = ll |> List.map convToTuple
        tl |> ExpandableList.foldTuples (fun st a b -> 
            let nctx = declareVariableBindings lvars ltypes [st; makeValue a; makeValue b] ctx
            bindVariables lvars ltypes [st; makeValue a; makeValue b] (transformExpr nctx lexpr)
          )  (transformExpr ctx einit)
  
    // Generic unary, binary, ternary...
    | SpecificCall <@@ matrixUnaryOperation @@> (None, _, [expr; f]) ->
        transformUnaryOperation (transformExpr ctx expr) f

    | SpecificCall <@@ matrixBinaryBuiltin @@> (None, _, [exp1; exp2; f]) ->
        transformBinaryBuiltinOperation (transformExpr ctx exp1) (transformExpr ctx exp2) f

    | SpecificCall <@@ matrixBinaryOperation @@> (None, _, [exp1; exp2; f]) ->
        transformBinaryOperation (transformExpr ctx exp1) (transformExpr ctx exp2) f

    // Reductions
    | SpecificCall <@@ matrixGenericFold @@> (None, _, [foldf; a]) ->
        let te = (transformExpr ctx a) in transformFold foldf te

    // Accelerator matrix operations 
    | SpecificCall <@@ rotate @@> (None, _, [expr; edy; edx]) ->
        rotateValues (transformExpr ctx expr, transformExpr ctx edy, transformExpr ctx edx)

    | SpecificCall <@@ select @@> (None, _, [test; val1; val2]) ->
        selectValues (transformExpr ctx test, transformExpr ctx val1, transformExpr ctx val2)

    | SpecificCall <@@ pad @@> (None, _, [exp; tbef1; tbef2; taft1; taft2; v]) ->
        match (tbef1, tbef2), (taft1, taft2) with
        | SizeTuple(bef), SizeTuple(aft) ->
            padValues (transformExpr ctx exp, bef, aft, transformExpr ctx v)
        | _ -> failwith "Pad!"
        
    | SpecificCall <@@ gather @@> (None, _, [src; yind; xind]) ->
        gatherValues (transformExpr ctx src, transformExpr ctx yind, transformExpr ctx xind)

    | SpecificCall <@@ interpolatef4 @@> (None, _, [expa; expb; expc]) ->
        interpolateValues (transformExpr ctx expa, transformExpr ctx expb, transformExpr ctx expc)

    | SpecificCall <@@ interpolate @@> (None, _, [expa; expb; expc]) ->
        interpolateValues (transformExpr ctx expa, transformExpr ctx expb, transformExpr ctx expc)

    | SpecificCall <@@ matrixConstant @@> (None, _, [f; dim1; dim2]) ->
        let v = match f with | ConstantValue ctx c -> c | _ -> failwith "not supported constant";
        match dim1, dim2 with 
        | SizeTuple sz -> getConstMatrixKnownSize sz v 
        | SameDimension vn -> getConstMatrixSameSize (readBoundVariable ctx vn) v
        | _ -> failwithf "not supported dimension calculation: %A" (dim1, dim2);

    | SpecificCall <@@ positions @@> (None, _, [wex; hex; dimind]) ->
        fillPositionValues (transformExpr ctx wex, transformExpr ctx hex, transformExpr ctx dimind)

    | SpecificCall <@@ shift @@> (None, _, [exp; edy; edx]) ->
        shiftValues (transformExpr ctx exp, transformExpr ctx edy, transformExpr ctx edx)

    | SpecificCall <@@ fraction @@> (None, _, [exp]) ->
        fractionValues (transformExpr ctx exp)

    // Other explicitly handled functions
    | SpecificCall <@@ pointwiseSqrt @@> (None, _, [e]) ->
        sqrtValue (transformExpr ctx e) 
    | SpecificCall <@@ pointwiseSqrtf4 @@> (None, _, [e]) ->
        sqrtValue (transformExpr ctx e) 

    // To make 'pad' work with float4 .. (TODO: ad-hoc case)
    //| SpecificCall <@@ float4OfSingle @@> (None, _, [Single(f)]) ->
    //    makeFloatConst f

    // Constants and variables  
    | Float4 f -> makeFloat4Const f
    | Int32 i -> makeIntConst i      
    | Single f -> makeFloatConst f      
    | Var n -> readBoundVariable ctx (n.Name)
    
    // Variable bindings
    | Let(bvar, bval, expr) ->
        let tvar = (transformExpr ctx bval)
        let nctx = declareVariableBinding bvar.Name bvar.Type tvar ctx
        (bindVariable bvar.Name bvar.Type tvar (transformExpr nctx expr))
    
    | _ ->
        failwithf "Unknown expression in the accelerated function: %A" e
          
  //---------------------------------------------------------------------------------------
  // ACCELERATE FUNCTION
  //---------------------------------------------------------------------------------------
            
  #if COMPILE_TRANSFORM
  
  /// Takes expression and builds a function that can be used to execute the code on GPU.
  /// The function is created using construction functions from 'CompileTransformation' module.
  /// NOTE: This function is optimized for partial function application!
  let accelerate (e:Expr) =
    let exp = expandAndSimplify lang e 
    match exp with 
    | AnyLambdas (FlatList p, expr) ->
        let ctx = 
          declareVariableBindings 
            (p |> List.map (fun n -> n.Name)) 
            (p |> List.map (fun n -> n.Type)) 
            (p |> List.map (fun _ -> CompileTransformation.IntConst(fun _ -> failwith "Empty value")))
            (createEmptyContext ())
        wrapResultFunction (transformExpr ctx expr) (p |> List.map (fun n -> n.Name))
    | _ -> failwith "Unexpected quotation structure in 'accelerate' function!"

  #else

  /// Takes expression and arguments and evaluates the code on GPU using
  /// functions from the 'EvalTransformation' module.
  let accelerate (e:Expr) (args:TransformValue list) =
    let exp = expandAndSimplify lang e
    match exp with 
    | AnyLambdas (FlatList(p), expr) ->
        let ctx = 
          declareVariableBindings 
            (p |> List.map (fun n -> n.Name)) 
            (p |> List.map (fun n -> n.Type)) 
            args (createEmptyContext ())
        transformExpr ctx expr
    | _ -> failwith "Unexpected quotation structure in 'accelerate' function!"

  #endif