//---------------------------------------------------------------------------------------
// DATA PARALLEL operations with Matrix type
//---------------------------------------------------------------------------------------
// This file defines data-parallel operations that can be used to work
// with the Matrix<_> type. It provides a naive non-parallel implementation.
//---------------------------------------------------------------------------------------

module FSharp.Math.DataParallel

open System
open System.Drawing
open Microsoft.FSharp.Math
open FSharp.Math

module Matrix = Math.Matrix.Generic

//-------------------------------------------------------------------------------------
// INTERNAL FUNCTIONS
//-------------------------------------------------------------------------------------

/// Various operations that are handled by the translator, which understands them when 
/// used as function argument to understood higher order functions (e.g. 
/// matrixUnaryOperation, matrixBinaryOperation and others)

module Internal = 
  // TRANSLATOR
  // - Understands following functions when used with 'matrixUnaryOperation'
  
  let singleOfInt    a = (float32 : int -> float32) a
  let singleOfBool   a = if a then 1.0f else 0.0f  
  
  let intOfSingle    a = (int : float32 -> int) a
  let intOfBool      a = if a then 1 else 0

  let boolOfInt      a = if a > 0  then true else false
  let boolOfSingle   a = if a > 0.0  then true else false

  let float4OfSingle a = Float4.ofSingle a
  let float4OfInt    a = Float4.ofSingle (float32 a)
  let float4OfBool   a = Float4.ofSingle (if a then 1.0f else 0.0f)


  // Dimension checkers - throws exception if matrices passed as 
  // parameters don't have corresponding sizes.
  // TRANSLATOR
  // - Should never see these functions (used only internally)
  
  let checkDimensions1 (a:Matrix<_>) = a.Dimensions

  let checkDimensions2 (a:Matrix<_>, b:Matrix<_>) = 
    let (w1,h1) = a.Dimensions
    let (w2,h2) = b.Dimensions
    if (w1 <> w2 || h1 <> h2) then
      failwith "Dimensions of matrices must match!"
    else
      (w1,h1)
      
  let checkDimensions3 (a:Matrix<_>, b:Matrix<_>, c:Matrix<_>) = 
    let (w1,h1) = a.Dimensions
    let (w2,h2) = b.Dimensions
    let (w3,h3) = c.Dimensions
    if (w1 <> w2 || w2 <> w3 || h1 <> h2 || h2 <> h3) then
      failwith "Dimensions of matrices must match!"
    else
      (w1,h1)    

  // Boolean operations - exposes operators as functions with nice name
  // TRANSLATOR
  // - Understands these functions when used with 'matrixBinaryOperation'
  
  let boolAnd a b         = a && b
  let boolOr a b          = a || b
  let genericEquality a b = a = b

  // Matrix operations - exposes operators as functions with nice name
  // TRANSLATOR
  // - Understands these functions when used with 'matrixBinaryBuiltin'
  
  let cptMul = ((.*) : Matrix<_> -> Matrix<_> -> Matrix<_>)
  let cptDiv = (fun (x:Matrix<_>) y -> x .* (Matrix.map (fun x -> x / 1.0f) y))
  let cptAdd = ((+)  : Matrix<_> -> Matrix<_> -> Matrix<_>)
  let cptSub = ((-)  : Matrix<_> -> Matrix<_> -> Matrix<_>)
  let cptMin = Matrix.cptMin
  let cptMax = Matrix.cptMax

  // Fold operations - exposes operators understood by translator
  // TRANSLATOR
  // - Understands these functions when used with 'matrixGenericFold'
  
  let sumFoldOp = (fun (n:INumeric<'a>) -> (n.Add, Some n.Zero))
  let prodFoldOp = (fun (n:INumeric<'a>) -> (n.Multiply, Some n.One))
  let minFoldOp = (fun (n:INumeric<'a>) -> 
    (fun (a, b) -> if (n.Compare(a, b) < 0) then a else b), None)
  let maxFoldOp = (fun (n:INumeric<'a>) -> 
    (fun (a, b) -> if (n.Compare(a, b) > 0) then a else b), None)

//-------------------------------------------------------------------------------------
// INITIALIZATION
//-------------------------------------------------------------------------------------

// Initialization of matrix - these function create new matrix from a number
// of other matrices and accept function that is executed for every index
// in the matrix (pointwise operation).
// TRANSLATOR
// - Understands the following funcs and performs translation to Accelerator
//   primitives depending on the 'f' passed as an argument.
 
let matrixConstant v (w, h) = 
  Matrix.init w h ( fun _ _ -> v )

let matrixUnaryOperation v f =
  let (w,h) = Internal.checkDimensions1 v
  Matrix.init w h (fun i j -> f (Matrix.get v i j))

let matrixBinaryOperation a b f =
  let (w,h) = Internal.checkDimensions2 (a,b)
  Matrix.init w h (fun i j -> f (Matrix.get a i j) (Matrix.get b i j))

// Note: 'f' is a builtin Matrix operator and not an operation to be run element-wisely
// (in the previous cases, 'f' was a point-wise operation). For some operators we can
// use F# Matrix operations directly (e.g. *., + etc. operators), so we use this function

let matrixBinaryBuiltin a b f =
  let (w,h) = Internal.checkDimensions2 (a,b)
  f a b
  
// Functions to construct common constants (when dimensions are specified)
// TRANSLATOR 
// - No special handling needed - translator understands 'matrixConstant'
  
[<ReflectedDefinition>]
let trueb  = matrixConstant true
[<ReflectedDefinition>]
let falseb = matrixConstant false

[<ReflectedDefinition>]
let zero   = matrixConstant 0
[<ReflectedDefinition>]
let one    = matrixConstant 1
[<ReflectedDefinition>]
let two    = matrixConstant 2
[<ReflectedDefinition>]
let three  = matrixConstant 3

[<ReflectedDefinition>]
let zerof   = matrixConstant 0.0f
[<ReflectedDefinition>]
let onef    = matrixConstant 1.0f
[<ReflectedDefinition>]
let twof    = matrixConstant 2.0f
[<ReflectedDefinition>]
let threef  = matrixConstant 3.0f

[<ReflectedDefinition>]
let zerof4   = matrixConstant (float4(0.0f, 0.0f, 0.0f, 0.0f))
[<ReflectedDefinition>]
let onef4    = matrixConstant (float4(1.0f, 1.0f, 1.0f, 1.0f))
[<ReflectedDefinition>]
let twof4    = matrixConstant (float4(2.0f, 2.0f, 2.0f, 2.0f))
[<ReflectedDefinition>]
let threef4  = matrixConstant (float4(3.0f, 3.0f, 3.0f, 3.0f))

//---------------------------------------------------------------------------------------
// BUILTIN ACCELERATOR FUNCTIONS
//---------------------------------------------------------------------------------------

// TRANSLATOR
// - Understands all of them and translates them to corresponding Accelerator calls

let rotate a dy dx = 
  let (w,h) = Internal.checkDimensions1 a
  Matrix.init w h (fun i j -> Matrix.get a ((i+dx+w)%w) ((j+dy+h)%h))

let select a b c = 
  let (w,h) = Internal.checkDimensions3 (a,b,c)
  Matrix.init w h (fun i j -> 
    let v1, v2, v3 = (Matrix.get a i j), (Matrix.get b i j), (Matrix.get c i j)
    if (v1 >= 0.0f) then v2 else v3 )

let positions h w dim = Matrix.init h w ( fun i j -> 
  if (dim = 0) then i else j )
      
let pad data (bx, by) (ax, ay) v = 
  let (w, h) = Internal.checkDimensions1 data
  Matrix.init (w+bx+ax) (h+by+ay) ( fun i j ->  
    if (i < bx || j < by || i >= (bx+w) || j >= (ax+h)) then v 
      else (Matrix.get data (i - bx) (j - by)) )

let gather (data:Matrix<'a>) xind yind = 
  let zero = (GlobalAssociations.GetNumericAssociation<'a>()).Zero
  let (w, h) = Internal.checkDimensions2 (xind, yind)
  let (dw, dh) = Internal.checkDimensions1 data
  Matrix.init w h ( fun i j -> 
    let yi = (Matrix.get yind i j)  
    let xi = (Matrix.get xind i j)
    if (xi < 0 || yi < 0 || xi >= dw || yi >= dh) then zero
      else Matrix.get data xi yi  )

let shift a dy dx = 
  let (w,h) = Internal.checkDimensions1 a
  Matrix.init w h (fun i j -> 
    let ni = if (i+dx) >= w then w-1 else i+dx
    let nj = if (j+dy) >= h then h-1 else j+dy      
    Matrix.get a ni nj)

let pointwiseSqrt a = matrixUnaryOperation a ( fun (v:float32) -> 
  float32(Math.Sqrt(float v)) ) 

let pointwiseSqrtf4 (a:Matrix<float4>) = matrixUnaryOperation a ( fun (v) -> 
  let (f1, f2, f3, f4) = v.Tuple in
  let sqf n = float32(Math.Sqrt(float n))
  v - float4(sqf f1, sqf f2, sqf f3, sqf f4) ) 

let fraction a = matrixUnaryOperation a ( fun (v) ->  
  v - float32(Math.Floor(float v)) ) 

let fractionf4 (a:Matrix<float4>) = matrixUnaryOperation a ( fun (v) ->  
  let (f1, f2, f3, f4) = v.Tuple in
  let ff n = float32(Math.Floor(float n))
  v - (float4(ff f1, ff f2, ff f3, ff f4)) ) 

let interpolate (a:Matrix<float32>) b c = 
  let (w,h) = Internal.checkDimensions3 (a,b,c)
  Matrix.init w h (fun i j -> 
    let v1, v2, v3 = (Matrix.get a i j), (Matrix.get b i j), (Matrix.get c i j)
    v3 + v1 * (v2 - v3)) 

let interpolatef4 (a:Matrix<float4>) b c =
  let (w,h) = Internal.checkDimensions3 (a,b,c)
  Matrix.init w h (fun i j -> 
    let v1, v2, v3 = (Matrix.get a i j), (Matrix.get b i j), (Matrix.get c i j)
    v3 + v1 * (v2 - v3))

//---------------------------------------------------------------------------------------
// POINTWISE OPERATIONS
//---------------------------------------------------------------------------------------

// TRANSLATOR
// - These are expressed using constructs understood by translator
  
[<ReflectedDefinition>]
let ( .&& ) a b = matrixBinaryOperation a b Internal.boolAnd
[<ReflectedDefinition>]
let ( .|| ) a b = matrixBinaryOperation a b Internal.boolOr
[<ReflectedDefinition>]
let ( .= )  a b = matrixBinaryOperation a b Internal.genericEquality

[<ReflectedDefinition>]
let ( .+ ) a b = matrixBinaryBuiltin a b Internal.cptAdd
[<ReflectedDefinition>]
let ( .- ) a b = matrixBinaryBuiltin a b Internal.cptSub
[<ReflectedDefinition>]
let ( .* ) a b = matrixBinaryBuiltin a b Internal.cptMul
[<ReflectedDefinition>]
let ( ./ ) a b = matrixBinaryBuiltin a b Internal.cptDiv

[<ReflectedDefinition>]
let pointwiseMin a b = matrixBinaryBuiltin a b Internal.cptMin
[<ReflectedDefinition>]
let pointwiseMax a b = matrixBinaryBuiltin a b Internal.cptMax

[<ReflectedDefinition>]
let ( +| ) a c = let m = a in m .+ (matrixConstant c m.Dimensions)
[<ReflectedDefinition>]
let ( -| ) a c = let m = a in m .- (matrixConstant c m.Dimensions)
[<ReflectedDefinition>]
let ( *| ) a c = let m = a in m .* (matrixConstant c m.Dimensions)
[<ReflectedDefinition>]
let ( /| ) a c = let m = a in m ./ (matrixConstant c m.Dimensions)
[<ReflectedDefinition>]
let ( |+ ) c a = let (m:Matrix<_>) = a in (matrixConstant c m.Dimensions) .+ m
[<ReflectedDefinition>]
let ( |- ) c a = let (m:Matrix<_>) = a in (matrixConstant c m.Dimensions) .+ m
[<ReflectedDefinition>]
let ( |* ) c a = let (m:Matrix<_>) = a in (matrixConstant c m.Dimensions) .* m
[<ReflectedDefinition>]
let ( |/ ) c a = let (m:Matrix<_>) = a in (matrixConstant c m.Dimensions) ./ m

// Simulation of boolena operators using floats

[<ReflectedDefinition>]
let ( &&. ) a b = pointwiseMin a b
[<ReflectedDefinition>]
let ( ||. ) a b = pointwiseMax a b
[<ReflectedDefinition>]
let ( =. )  a b = 
  let res = matrixBinaryOperation a b Internal.genericEquality
  matrixUnaryOperation res Internal.singleOfBool

//---------------------------------------------------------------------------------------
// FOLDS
//---------------------------------------------------------------------------------------

// Generic fold function that uses 'GetNumericAssociation' to support all possible 
// numeric types. First parameter is a function that takes INumeric as a parameter 
// and returns 'reduce' function and initial value
let matrixGenericFold fgetf (m:Matrix<'a>) = 
  let numeric = GlobalAssociations.GetNumericAssociation<'a>()
  let (freduce, vinit) = fgetf numeric
  // workaround for min/max - take the first element, because INumeric doesn't have min/max
  let vinit = 
    match vinit with
    | None -> m.[0, 0]
    | Some(vinit) -> vinit
  Matrix.fold (fun a b -> freduce (a,b) ) vinit m

// TRANSLATOR 
// - Understands 'matrixGenericFold' and functions used as parameters

[<ReflectedDefinition>]
let sum  m = matrixGenericFold Internal.sumFoldOp m
[<ReflectedDefinition>]
let prod m = matrixGenericFold Internal.prodFoldOp m
[<ReflectedDefinition>]
let findMin m = matrixGenericFold Internal.minFoldOp m
[<ReflectedDefinition>]
let findMax m = matrixGenericFold Internal.maxFoldOp m

//---------------------------------------------------------------------------------------
// CONVERSIONS
//---------------------------------------------------------------------------------------

module Conversions = 
  // Functions for converting several matrix types and bitmaps
  // TRANSLATOR
  // - Understands 'matrixUnaryOperation' and functions used as parameters

  [<ReflectedDefinition>]    
  let singleOfInt    a = matrixUnaryOperation a Internal.singleOfInt
  [<ReflectedDefinition>]    
  let singleOfBool   a = matrixUnaryOperation a Internal.singleOfBool
  
  [<ReflectedDefinition>]
  let intOfBool     a = matrixUnaryOperation a Internal.intOfBool
  [<ReflectedDefinition>]
  let intOfSingle    a = matrixUnaryOperation a Internal.intOfSingle
  
  [<ReflectedDefinition>]
  let boolOfInt     a = matrixUnaryOperation a Internal.boolOfInt
  [<ReflectedDefinition>]
  let boolOfSingle  a = matrixUnaryOperation a Internal.boolOfSingle
  
  [<ReflectedDefinition>]
  let float4OfSingle a = matrixUnaryOperation a Internal.float4OfSingle
  [<ReflectedDefinition>]
  let float4OfInt    a = matrixUnaryOperation a Internal.float4OfInt
  [<ReflectedDefinition>]
  let float4OfBool   a = matrixUnaryOperation a Internal.float4OfBool

  // TRANSLATOR
  // - the following function is not handled by the translator in any way
  //   (and cannot be used as part of the accelerated code)
 
  let bitmapOfMatrix f (matrix:Matrix<_>) =
    // Create bitmap & lock it in the memory, so that we can access it directly
    let w, h = matrix.Dimensions
    let bmp = new Bitmap(w, h)
    let rect = new Rectangle(0, 0, w, h)
    let bmpData = bmp.LockBits(rect, Imaging.ImageLockMode.ReadWrite, 
                               Imaging.PixelFormat.Format32bppArgb)
         
    // Using pointer arithmethic to copy all the bits
    let ptr0 = bmpData.Scan0 
    let stride = bmpData.Stride
    for i = 0 to bmp.Width - 1 do
      for j = 0 to bmp.Height - 1 do
        let offset = i*4 + stride*j
        let clr = (f(matrix.[i,j]) : Color).ToArgb()
        System.Runtime.InteropServices.Marshal.WriteInt32(ptr0, offset, clr)
    
    bmp.UnlockBits(bmpData)
    bmp

  let matrixOfBitmap f (bmp:Bitmap) =
    let rect    = new Rectangle(0,0,bmp.Width,bmp.Height) in
    let bmpData = bmp.LockBits(rect,Imaging.ImageLockMode.ReadWrite,Imaging.PixelFormat.Format32bppArgb) in
    let ptr0    = bmpData.Scan0 : IntPtr in
    let stride  = bmpData.Stride in
    let res = Matrix.init bmp.Width bmp.Height ( fun i j ->
      let offset = i*4 + stride*j in
      f (Color.FromArgb(System.Runtime.InteropServices.Marshal.ReadInt32(ptr0,offset))) )
    bmp.UnlockBits(bmpData)
    res  
  
(*
*)
(*
  let bitmap_of_array f (m:_[,]) =
    let (w,h)   = m.GetLength(0), m.GetLength(1)
    let bmp     = new Bitmap(w,h)
    let rect    = new Rectangle(0,0,bmp.Width,bmp.Height) in
    let bmpData = bmp.LockBits(rect,Imaging.ImageLockMode.ReadWrite,Imaging.PixelFormat.Format32bppArgb) in
    let ptr0    = bmpData.Scan0 : IntPtr in
    let stride  = bmpData.Stride in
    for i = 0 to bmp.Width - 1 do
      for j = 0 to bmp.Height - 1 do
        let offset = i*4 + stride*j in
        let (clr:Color) = f (m.[i, j])
        System.Runtime.InteropServices.Marshal.WriteInt32(ptr0,offset,clr.ToArgb())
    bmp.UnlockBits(bmpData)
    bmp
*)    
(*    
  let bitmap_of_float4 (m:Matrix<float4>) =
    let (w,h)   = m.Dimensions
    let bmp     = new Bitmap(w,h)
    let rect    = new Rectangle(0,0,bmp.Width,bmp.Height) in
    let bmpData = bmp.LockBits(rect,Imaging.ImageLockMode.ReadWrite,Imaging.PixelFormat.Format32bppArgb) in
    let ptr0    = bmpData.Scan0 : IntPtr in
    let stride  = bmpData.Stride in
    for i = 0 to bmp.Width - 1 do
      for j = 0 to bmp.Height - 1 do
        let offset = i*4 + stride*j in
        let clr = Internal.color_of_float4 (Matrix.get m i j)
        System.Runtime.InteropServices.Marshal.WriteInt32(ptr0,offset,clr.ToArgb())
    bmp.UnlockBits(bmpData)
    bmp
    
  let bitmap_of_bool (m:Matrix<_>) =
    let (w,h)   = m.Dimensions
    let bmp     = new Bitmap(w,h)
    let rect    = new Rectangle(0,0,bmp.Width,bmp.Height) in
    let bmpData = bmp.LockBits(rect,Imaging.ImageLockMode.ReadWrite,Imaging.PixelFormat.Format32bppArgb) in
    let ptr0    = bmpData.Scan0 : IntPtr in
    let stride  = bmpData.Stride in
    let c1      = Color.FromArgb(0, 0, 0).ToArgb() 
    let c2      = Color.FromArgb(255, 255, 255).ToArgb()
    for i = 0 to bmp.Width - 1 do
      for j = 0 to bmp.Height - 1 do
        let offset = i*4 + stride*j in
        let clr = if (Matrix.get m i j) then c1 else c2
        System.Runtime.InteropServices.Marshal.WriteInt32(ptr0,offset,clr)
    bmp.UnlockBits(bmpData)
    bmp  
*)
