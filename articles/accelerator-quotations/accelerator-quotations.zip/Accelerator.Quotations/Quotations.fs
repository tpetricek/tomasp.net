﻿//---------------------------------------------------------------------------------------
// QUOTATIONS - Generally useful functions for processing quotations 
//---------------------------------------------------------------------------------------
module FSharp.Quotations

open System
open System.Reflection
open Microsoft.FSharp.Math
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Patterns
open Microsoft.FSharp.Quotations.DerivedPatterns

//---------------------------------------------------------------------------------------
// HOLES - Matching F# quotations against holes
//---------------------------------------------------------------------------------------

// NOTE: This is a bit experimental implementation (not all corner cases covered)

/// If used inside quotations, represents a hole e.g.
/// <@@ 10 + hole @@> matches <@@ 10 + 2 @@>
let hole<'a> = failwith "hole" : 'a
/// Represents a type hole. For example:
/// <@@ a.Foo<TypeHole>(hole) @@> matches <@@ a.Foo<int>(10) @@>
type TypeHole = Hole

module Internal = 
  // Method info corresponding to <@@ hole : int @@>
  let holeInfo = 
    let specific = match <@@ hole : int @@> with Call(_, mi, _) -> mi | _ -> failwith "!"
    specific.GetGenericMethodDefinition()
    
  let (|MemberInfo|) mi = (mi :> MemberInfo)

open Internal

/// Matches the specified quotation against pattern which can contain
/// holes and returns the list of expressions that correspond to holes.
/// For example:
///   matchExpressions <@@ (hole : int) + (hole : int) @@> <@@ 5 + 2 @@> 
/// Returns:
///   Some [ <@@ 5 @@>; <@@ 2 @@> ]
let rec matchExpressions pattern expr =
  let variablesEqual (v1:Var) (v2:Var) = 
    v1.Name = v2.Name && v1.Type = v2.Type && v1.IsMutable = v2.IsMutable
  
  let processExpressions exprs1 exprs2 =
    List.zip exprs1 exprs2 |> List.fold (fun st (pattern, expr) -> 
      match st, expr with
      | Some(l), MatchExpressions pattern filling -> Some(l @ filling)
      | _ -> None ) (Some [])
  
  let matchTypeArguments tys1 tys2 = 
    Seq.zip tys1 tys2 |> Seq.forall (fun (pt, et) -> pt = typeof<TypeHole> || pt = et)

  let matchGenericMemberInfos (pat:Reflection.MemberInfo) (exp:Reflection.MemberInfo) = 
    let pat, exp = 
      if (pat.DeclaringType.IsGenericType && exp.DeclaringType.IsGenericType) &&
         (matchTypeArguments (pat.DeclaringType.GetGenericArguments()) (exp.DeclaringType.GetGenericArguments())) then
        // Types are equal, now let's find member info in the exp's type corresponding to pat
        let pat = 
          match pat with
          | :? Reflection.MethodInfo as mi -> 
            // Reflection is really painful.
            // This isnt's still quite right - i guess it won't work for generic methods
            (exp.DeclaringType.GetMethod(mi.Name, [| for t in mi.GetParameters() -> t.ParameterType |]) :> Reflection.MemberInfo)
          | :? Reflection.PropertyInfo as pi -> 
            (exp.DeclaringType.GetProperty(pi.Name, pi.PropertyType) :> Reflection.MemberInfo)
          | _ -> pat // something went wrong
        pat, exp
      else
        pat, exp
    
    match pat, exp with
    | (:? Reflection.MethodInfo as pat), (:? Reflection.MethodInfo as exp) 
        when pat.IsGenericMethod && exp.IsGenericMethod ->
        // e.g. Foo<int, TypeHole> should accept Foo<int, string>
        // currently, we don't handle Foo<T<TypeHole>> <--> Foo<T<int>>
        (pat.GetGenericMethodDefinition() = exp.GetGenericMethodDefinition()) &&
        (matchTypeArguments (pat.GetGenericArguments()) (exp.GetGenericArguments()))
    | _ -> pat = exp
    
  // Match the expression against pattern by following expression shape
  match pattern, expr with
  | Call(None, mi, []), matching when mi.IsGenericMethod && (mi.GetGenericMethodDefinition() = holeInfo) ->
      Some([matching])
  
  // <@@ (a : T<TypeHole>).Foo @@> should match <@@ (a : T<int>).Foo @@>
  | PropertyGet(patInst, MemberInfo patMi, patArgs), PropertyGet(expInst, MemberInfo expMi, expArgs) 
  | Call(patInst, MemberInfo patMi, patArgs), Call(expInst, MemberInfo expMi, expArgs) 
      when matchGenericMemberInfos patMi expMi ->
      match patInst, expInst with
      | Some(pi), Some(ei) -> processExpressions (pi::patArgs) (ei::expArgs)
      | None, None -> processExpressions patArgs expArgs
      | _ -> None
      
  | ExprShape.ShapeVar(v1), ExprShape.ShapeVar(v2) when variablesEqual v1 v2 -> Some []
  | ExprShape.ShapeLambda(v1, e1), ExprShape.ShapeLambda(v2, e2) when variablesEqual v1 v2 ->
      matchExpressions e1 e2
  | ExprShape.ShapeCombination(o1, exprs1), ExprShape.ShapeCombination(o2, exprs2) -> 
      // To compare objects representing operations, we need to do some magic (probably?)
      // Objects are actually tuples of (ExprConstInfo * Expr list). We compare only the
      // first thing using 'Equals' method that compares discriminated unions
      let getExprConstInfo o = o.GetType().GetProperty("Item1").GetGetMethod().Invoke(o, [| |])
      let o1Info = getExprConstInfo o1
      let o2Info = getExprConstInfo o2
      // Get & run the equals method
      let equalsMethod = o1Info.GetType().GetMethod("Equals", [| o2Info.GetType() |])
      let operationsEqual = equalsMethod.Invoke(o1Info, [| o2Info |]) :?> bool
      
      if not operationsEqual then None
      else processExpressions exprs1 exprs2
  | _ -> None        

and (|MatchExpressions|_|) pattern expr = matchExpressions pattern expr

//---------------------------------------------------------------------------------------
// EXPANSION & SIMPLIFICATION 
//---------------------------------------------------------------------------------------

let (|InLang|_|) lang e = 
  let res = List.exists (fun m -> 
    match e with SpecificCall m x -> true | _ -> false) lang 
  if res then Some(e) else None    

/// Expands all constructs to their definition if they are not 
/// inside the specified language. This means, method calls to 
/// reflected defintion methods are expanded.
let rec expand lang = 
  let matrixType = typeof<Matrix<int>>.GetGenericTypeDefinition()
  function
  | InLang lang (ExprShape.ShapeCombination(o, exprs)) ->
      ExprShape.RebuildShapeCombination(o, exprs |> List.map (expand lang))
      
  | Call(inst, MethodWithReflectedDefinition(body), args) 
  | PropertyGet(inst, PropertyGetterWithReflectedDefinition(body), args) ->
      match inst with 
      | Some(inst) -> failwith "Not implemented - instance call"
      | _ -> Expr.Applications(body, [ for a in args -> [a]]) |> expand lang
      
  | Call(inst, mi, args) ->  
      failwithf "Call to unknown function: %s" mi.Name

  // Expand let bindings that don't declare int/float32/matrix value...
  | Let(var, value, body) when 
      // This may sometimes work for integers & floats too, but only
      // if they are used as a result of some computation..
      // Maybe we should do this reduction later when we know, whether
      // we can translate the code or not...
      ((not var.Type.IsGenericType) || (var.Type.GetGenericTypeDefinition() <> matrixType)) ->
      body.Substitute(fun v -> if v = var then Some(value) else None) |> expand lang
      
  | ExprShape.ShapeLambda(v, body) ->
      Expr.Lambda(v, expand lang body)
  | ExprShape.ShapeCombination(o, exprs) ->
      ExprShape.RebuildShapeCombination(o, exprs |> List.map (expand lang))
  | ExprShape.ShapeVar(_) as e -> e
 
/// Performs one step beta-reduction and also simplifies some uses of
/// tuples (e.g. fst (<e1>, <e2> ~> <e1>)
let rec simplify expr = 
  match expr with
  | Application(Lambda(vdef, body), subst) ->
      Some(body.Substitute(fun v -> 
        if v = vdef then Some(subst) else None ))  
  // This reduces some noise in the quotation encoding - sometimes
  // this would break recognition of some patterns (e.g. (|SizeTuple|_|)) 
  | TupleGet(NewTuple(args), index) -> 
      Some(args.[index])
  | ExprShape.ShapeLambda(v, body) -> 
      simplify body |> Option.map (fun body ->
        Expr.Lambda(v, body))
  | ExprShape.ShapeCombination(o, exprs) -> 
      let simplified = exprs |> List.map simplify
      // Continue if we simplified some subexpression
      if simplified |> List.exists Option.isSome then
        let exprs = List.zip simplified exprs |> List.map (function 
          | None, e | Some(e), _ -> e)
        Some(ExprShape.RebuildShapeCombination(o, exprs))
      else
        None
  | ExprShape.ShapeVar(_) -> None

/// Performs beta-reduction repeatedly until no further reductions are possible
let rec simplifyWhilePossible e = 
  match simplify e with
  | Some(simplified) -> simplifyWhilePossible simplified
  | None -> e
  
/// Reduces the expression to known language, but doesn't perform 
/// beta-reduction on let .. in .. bindings, because these are supported
/// by the translator.
let expandAndSimplify lang (e:Expr) : Expr =   
  //printfn "INPUT: %A\n\n" e 
  let res = expand lang e
  //printfn "EXPANDED: %A\n\n" res
  let res = simplifyWhilePossible res
  //printfn "SIMPLIFIED: %A\n\n" res
  res
