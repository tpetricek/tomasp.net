//---------------------------------------------------------------------------------------
// FLOAT4
//---------------------------------------------------------------------------------------
// This files defines 'Float4' type that is needed for some 
// Accelerator operations. The type corresponds to Float4 in Accelerator
// but provides full aritmethics usable from F# (to execute code on CPU).
//---------------------------------------------------------------------------------------
namespace FSharp.Math

open System
open System.Globalization
open Microsoft.FSharp.Math

//---------------------------------------------------------------------------------------
/// Type representing quadruple with element type float32. 
[<Struct>]
type Float4(f1:float32, f2:float32, f3:float32, f4:float32) =
#if COMPILED
  static do 
    // This is a totally ugly workaround due to recursive declarations...
    // (we need to define numerics after module Float4, but we need to use it here
    // and it cannot be really merged into a type, because 'struct' can't contain lets)
    let flags = System.Reflection.BindingFlags.Static ||| System.Reflection.BindingFlags.NonPublic
    let numerics = 
      System.Reflection.Assembly.GetExecutingAssembly()
        .GetType("FSharp.Math.Float4Helper").GetProperty("Numerics", flags)
        .GetGetMethod(true).Invoke(null, [| |]) :?> INumeric<Float4>
    GlobalAssociations.RegisterNumericAssociation(numerics)
#endif    

  member x.Item1 = f1
  member x.Item2 = f2
  member x.Item3 = f3
  member x.Item4 = f4
  member x.Tuple = (f1, f2, f3, f4)
  member x.ToString(fmt, fmtprovider) =
    "(" + f1.ToString(fmt,fmtprovider) + "," + f2.ToString(fmt,fmtprovider) + "," +
          f3.ToString(fmt,fmtprovider) + "," + f4.ToString(fmt,fmtprovider) + ")"
  override x.ToString() = x.ToString("g", CultureInfo.InvariantCulture) 
  
  
/// Type representing quadruple with element type float32. 
/// This is an abbreviation for Float4 type from FSharp.Math.
type float4 = Float4

// Open the following module to make the function available automatically
[<AutoOpen>]
module Float4TopLevelOperations =

  /// Builds a float4 value from four values of type float32
  let float4 (f1,f2,f3,f4) = Float4(f1, f2, f3, f4)

//---------------------------------------------------------------------------------------
/// Module with functions for working with float4 type
[<CompilationRepresentation(CompilationRepresentationFlags.ModuleSuffix)>]
module Float4 = 

  // Constructors and predefined constants
  let zero = float4(0.0f,0.0f,0.0f,0.0f)
  let one = float4(1.0f,1.0f,1.0f,1.0f) 
  
  // Binary operations
  let inline binaryop f (a:float4) (b:float4) = 
    float4(f a.Item1 b.Item1, f a.Item2 b.Item2, f a.Item3 b.Item3, f a.Item4 b.Item4)
  
  let add (a:float4) (b:float4) = binaryop ( + ) a b
  let sub (a:float4) (b:float4) = binaryop ( - ) a b
  let mul (a:float4) (b:float4) = binaryop ( * ) a b
  let div (a:float4) (b:float4) = binaryop ( / ) a b
  
  // Unary operations
  let inline float32_abs f = if (f >= 0.0f) then f else -f
  let inline float32_sqrt f = float32 (Math.Sqrt(float f))
  let inline float32_sin f = float32 (Math.Sin(float f))
  let inline float32_cos f = float32 (Math.Cos(float f))
  
  let inline unaryop f (a:float4) = float4(f a.Item1, f a.Item2, f a.Item3, f a.Item4)
  
  let neg  (a:float4) = unaryop (~-) a
  let abs  (a:float4) = unaryop float32_abs a
  let sqrt (a:float4) = unaryop float32_sqrt a
  let cos  (a:float4) = unaryop float32_cos a
  let sin  (a:float4) = unaryop float32_sin a
  
  let smul (a:float32) (b:float4) = unaryop (fun n -> a * n) b
  let muls (a:float4) (b:float32) = unaryop (fun n -> n * b) a

  // String formating and parsing functions
  let to_string (x:float4) = x.ToString("g", CultureInfo.InvariantCulture)
  let of_string (s:string) = (failwith "Conversion from string is not implemented":float4)

  // Conversion routines  
  [<ReflectedDefinition>]
  let ofSingle f = float4(f,f,f,f)

  let ofColor (clr:System.Drawing.Color) = 
    let conv (v:byte) = (float32 v) / 255.0f
    float4(conv clr.A, conv clr.R, conv clr.G, conv clr.B)

  let toColor (f:float4) = 
    let conv (v:float32) = int (v * 255.0f)
    System.Drawing.Color.FromArgb(conv f.Item1, conv f.Item2, conv f.Item3, conv f.Item4)
    
#if ACCELERATOR
  type AccFloat4 = Microsoft.ParallelArrays.Float4
  
  /// Conversion from Float4 type declared in Accelerator
  let ofAccFloat4 (fl:AccFloat4) =
    float4(fl.f1, fl.f2, fl.f3, fl.f4)

  /// Conversion from Float4 type declared in Accelerator
  let toAccFloat4 (f:float4) =
    new AccFloat4(f.Item1, f.Item2, f.Item3, f.Item4)
#endif  

//---------------------------------------------------------------------------------------
open Float4

type Float4Helper =   
  // Implementation of abstract numeric type (so float4 can be used with Matrix<_> etc..)
  static member Numerics = 
    { new INumeric<_> with 
        member ops.Zero = zero
        member ops.One = one
        member ops.Add(a,b) = add a b
        member ops.Subtract(a,b) = sub a b
        member ops.Multiply(a,b) = mul a b
        member ops.Negate(a) = neg a
        member ops.Abs(a) = abs a
        member ops.Equals(a, b) = a = b
        member ops.Compare(a, b) = if (a > b) then +1 else (if a = b then 0 else -1)
        member ops.Sign(a) = failwith "Sign of float4 is not defined."
        member ops.ToString((x:float4),fmt,fmtprovider) = x.ToString(fmt, fmtprovider)
        member ops.Parse(s,numstyle,fmtprovider) = 
          (failwith "Conversion from string is not implemented":float4) }

#if INTERACTIVE
module Float4Init = 
  GlobalAssociations.RegisterNumericAssociation(Float4Helper.Numerics)
#endif
  
/// Type representing quadruple with element type float32.
type Float4 with 
    // Constants & constructors
    static member Create(v) = float4 (v)
    static member Zero = Float4.zero
    static member One = Float4.one 
    
    // Binary operators
    static member ( + ) (a,b) = Float4.add a b
    static member ( - ) (a,b) = Float4.sub a b
    static member ( * ) (a,b) = Float4.mul a b
    static member ( / ) (a,b) = Float4.div a b

    static member ( * ) (a,b) = Float4.smul a b
    static member ( * ) (a,b) = Float4.muls a b 

    // Unary operators    
    static member ( ~- ) a     = Float4.neg a