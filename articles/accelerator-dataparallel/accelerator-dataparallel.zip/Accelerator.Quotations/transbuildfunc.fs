// Copyright (c) Microsoft Corporation 2005-2007.
// This sample code is provided "as is" without warranty of any kind. 
// We disclaim all warranties, either express or implied, including the 
// warranties of merchantability and fitness for a particular purpose. 

// NOTE: This sample uses 'light' syntax.  This means whitespace is signficant.
#light
namespace AcceleratorSample

open System
open AcceleratorSample
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.Math
open Microsoft.Research.DataParallelArrays

module Matrix = Math.Matrix.Generic

module TransformBuildFunc = begin
  open InternalConversions

  /// The TransformContext type is kept as a parameter during the translation
  /// in this module we use it for remembering the types of bound variables
  type TransformContext = Map<String, Type>
  
  /// The ArgContext type is a parameter for a function that calls Accelerator
  /// methods. It contains variable bindings.
  type ArgContext = Map<String, VariableBinding> 
  
  /// The 'Result' member is used to prevent calculation of the 
  /// same value more than once.
  and VariableBinding = { Value:TransformValue; Result:TransformExec.TransformValue option ref }
  
  /// The TransformValue type represents the result of convertsion
  and TransformValue =
    | FloatMatrixValue of (ArgContext -> FPA)
    | Float4MatrixValue of (ArgContext -> F4PA)
    | IntMatrixValue of (ArgContext -> IPA)
    | BoolMatrixValue of (ArgContext -> BPA)
    
    | FloatValue of (ArgContext -> FPA)
    | IntValue of (ArgContext -> IPA)
    
    | FloatConst of (ArgContext -> float32)
    | Float4Const of (ArgContext -> float32_4)
    | IntConst of (ArgContext -> int)

  //-----------------------------------------------------------------------------
  // Context & variables 
  
  let createEmptyContext () = (Map.empty : TransformContext)
  
  let valueOfExecValue (v:TransformExec.TransformValue) = 
    match v with
      | TransformExec.FloatMatrixValue v -> FloatMatrixValue ( fun _ -> v )
      | TransformExec.Float4MatrixValue v -> Float4MatrixValue ( fun _ -> v )
      | TransformExec.IntMatrixValue v -> IntMatrixValue ( fun _ -> v )
      | TransformExec.BoolMatrixValue v -> BoolMatrixValue ( fun _ -> v )
      | TransformExec.FloatValue v -> FloatValue ( fun _ -> v )
      | TransformExec.IntValue v -> IntValue ( fun _ -> v )
      | TransformExec.FloatConst v -> FloatConst ( fun _ -> v )
      | TransformExec.Float4Const v -> Float4Const ( fun _ -> v )
      | TransformExec.IntConst v -> IntConst ( fun _ -> v )
   
  let applyArgs (v:TransformValue) args =
    match v with  
      | FloatMatrixValue f -> TransformExec.FloatMatrixValue (f args)
      | Float4MatrixValue f -> TransformExec.Float4MatrixValue (f args)
      | BoolMatrixValue f -> TransformExec.BoolMatrixValue (f args)
      | IntMatrixValue f -> TransformExec.IntMatrixValue (f args)
      | IntConst f -> TransformExec.IntConst (f args)
      | FloatConst f -> TransformExec.FloatConst (f args)
      | Float4Const f -> TransformExec.Float4Const (f args)
      | IntValue f -> TransformExec.IntValue (f args)
      | FloatValue f -> TransformExec.FloatValue (f args)
         
  let declareVariableBinding (name:String) (ty:Type) (pval:TransformValue) (ctx:TransformContext) = 
    (Map.add name ty ctx)
  
  let newVariable v = { Value=v; Result=ref None; }
  
  let readVariable name args = 
    let v = (Map.find name args)
    if (!v.Result = None) then
      let res = (applyArgs v.Value args) 
      v.Result := Some res;
    match !v.Result with | Some v -> valueOfExecValue v; | None -> assert(false)
  
  /// Wraps the returned function so it accepts TransformExec.TransformValue as a parameter
  /// (these are easier to work with)
  let wrapResultFunction pval names =
    let wrap f args = f (List.zip names args |> List.fold_left ( fun st (n,v) -> Map.add n (newVariable (valueOfExecValue v)) st ) Map.empty ) 
    match pval with 
      | FloatMatrixValue f -> ( fun args -> TransformExec.FloatMatrixValue (wrap f args) )
      | Float4MatrixValue f -> ( fun args -> TransformExec.Float4MatrixValue (wrap f args) )
      | BoolMatrixValue f -> ( fun args -> TransformExec.BoolMatrixValue (wrap f args) )
      | IntMatrixValue f -> ( fun args -> TransformExec.IntMatrixValue (wrap f args) )
      | IntValue f -> ( fun args -> TransformExec.IntValue (wrap f args) )
      | FloatValue f -> ( fun args -> TransformExec.FloatValue (wrap f args) )
      | _ -> failwith "wrap!"

  /// Bind variable in a function that will be returned
  let bindVariable (var:String) (ty:Type) (pval:TransformValue) (bindto:TransformValue) =
    let bind f args = f (Map.add var (newVariable pval) args)
    match bindto with 
      | FloatMatrixValue f -> FloatMatrixValue ( fun args -> bind f args)
      | Float4MatrixValue f -> Float4MatrixValue ( fun args -> bind f args)
      | BoolMatrixValue f -> BoolMatrixValue ( fun args -> bind f args)
      | IntMatrixValue f -> IntMatrixValue ( fun args -> bind f args)
      | IntConst f -> IntConst ( fun args -> bind f args)
      | FloatConst f -> FloatConst ( fun args -> bind f args)
      | Float4Const f -> Float4Const ( fun args -> bind f args)
      | IntValue f -> IntValue ( fun args -> bind f args)
      | FloatValue f -> FloatValue ( fun args -> bind f args)
      
  /// Read variable value (depending on the type of the variable)      
  let readBoundVariable (ctx:TransformContext) (name:String) = 
    let ty = Map.find name ctx in 
    if (ty = (type System.Drawing.Bitmap)) then 
      Float4MatrixValue ( fun args -> match (readVariable name args) with | Float4MatrixValue v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Matrix<float32_4>)) then 
      Float4MatrixValue ( fun args -> match (readVariable name args) with | Float4MatrixValue v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Matrix<int>)) then 
      IntMatrixValue ( fun args -> match (readVariable name args) with | IntMatrixValue v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Matrix<float32>)) then 
      FloatMatrixValue ( fun args -> match (readVariable name args) with | FloatMatrixValue v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Matrix<bool>)) then 
      BoolMatrixValue ( fun args -> match (readVariable name args) with | BoolMatrixValue v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Int32)) then 
      IntConst ( fun args -> match (readVariable name args) with | IntConst v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Float32_4)) then 
      Float4Const ( fun args -> match (readVariable name args) with | Float4Const v -> (v args) | _ -> failwith "rr!" )
    else if (ty = (type Single)) then 
      FloatConst ( fun args -> match (readVariable name args) with | FloatConst v -> (v args) | _ -> failwith "rr!" )
    else 
      failwith "readvar!";      

  //-----------------------------------------------------------------------------
  // Constructing parameters & decomposing to F# types
  
  let makeIntConst v = IntConst (fun _ -> v)
  let makeFloatConst v = FloatConst (fun _ -> v)
  let makeConstUntyped (v:obj) = 
    match v with
      | :? float32 as f -> FloatConst (fun _ -> f)
      | :? float32_4 as f -> Float4Const (fun _ -> f)
      | :? int as i -> IntConst (fun _ -> i)
      | _ -> failwith "const!";

  let makeBitmapConst (bmp:System.Drawing.Bitmap) = Float4MatrixValue ( let pa = new DF4PA(bmp) :> F4PA in fun _ -> pa )  
  let makeFloatMatrix fm = FloatMatrixValue (let pa = (fpa_of_fma fm) in fun _ -> pa )
  let makeFloat4Matrix fm = Float4MatrixValue (let pa = (f4pa_of_f4ma fm) in fun _ -> pa )
  let makeBoolMatrix bm = BoolMatrixValue (let pa = (bpa_of_bma bm) in fun _ -> pa )
    
  // "Destructing" :-)  
  let getFloatMatrixValue = TransformExec.getFloatMatrixValue
  let getIntMatrixValue = TransformExec.getIntMatrixValue
  let getBoolMatrixValue = TransformExec.getBoolMatrixValue
  let getFloat4MatrixValue = TransformExec.getFloat4MatrixValue
  let getBitmapValue = TransformExec.getBitmapValue
  let getIntValue = TransformExec.getIntValue
  let getFloatValue = TransformExec.getFloatValue
  
  //-----------------------------------------------------------------------------
  // Basic math, logical operations, comparison...
  
  let multiplyValues (a, b) = 
    match a,b with
      | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Multiply(fpa1 args, fpa2 args))
      | Float4MatrixValue f4pa1, Float4MatrixValue f4pa2 -> Float4MatrixValue ( fun args -> PA.Multiply(f4pa1 args, f4pa2 args))
      | _ -> failwith "mul!"
  let addValues (a, b) = 
    match a,b with
      | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Add(fpa1 args, fpa2 args))
      | Float4MatrixValue f4pa1, Float4MatrixValue f4pa2 -> Float4MatrixValue ( fun args -> PA.Add(f4pa1 args, f4pa2 args))
      | IntMatrixValue ipa1, IntMatrixValue ipa2 -> IntMatrixValue ( fun args -> PA.Add(ipa1 args, ipa2 args))
      | _ -> failwith "add!"      
  let subtractValues (a, b) = 
    match a,b with
      | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> FloatMatrixValue ( fun args -> PA.Subtract(fpa1 args, fpa2 args))
      | _ -> failwith "sub!"       
  let sqrtValue (a) = 
    match a with
      | FloatMatrixValue fpa -> FloatMatrixValue ( fun args -> PA.Sqrt(fpa args))
      | _ -> failwith "sqrt!"  
  let fractionValues (a) =             
    match a with
      | FloatMatrixValue fpa -> FloatMatrixValue ( fun args -> PA.Fraction(fpa args))
      | Float4MatrixValue f4pa -> Float4MatrixValue ( fun args -> PA.Fraction(f4pa args))
      | _ -> failwith "fract!"  
      
  let logicalAndValues (a, b) = 
    match a,b with
      | BoolMatrixValue bpa1, BoolMatrixValue bpa2 -> BoolMatrixValue ( fun args -> PA.And(bpa1 args, bpa2 args))
      | _ -> failwith "and!"
  let logicalOrValues (a, b) = 
    match a,b with
      | BoolMatrixValue bpa1, BoolMatrixValue bpa2 -> BoolMatrixValue ( fun args -> PA.Or(bpa1 args, bpa2 args))
      | _ -> failwith "or!"
  let compareValues (a, b) = 
    match a,b with
      | FloatMatrixValue fpa1, FloatMatrixValue fpa2 -> BoolMatrixValue ( fun args -> PA.CompareEqual(fpa1 args, fpa2 args))
      | IntMatrixValue ipa1, IntMatrixValue ipa2 -> BoolMatrixValue ( fun args -> PA.CompareEqual(ipa1 args, ipa2 args))
      | _ -> failwith "compare!"      
        
  //-----------------------------------------------------------------------------        
  // Reductions...
  
  let foldSumValues (a) = 
    match a with
      | FloatMatrixValue fpa -> FloatValue ( fun args -> PA.Sum(fpa args))
      | IntMatrixValue ipa -> IntValue ( fun args -> PA.Sum(ipa args))
      | _ -> failwith "sum!"  
  let foldProdValues (a) = 
    match a with
      | FloatMatrixValue fpa -> FloatValue ( fun args -> PA.Product(fpa args))
      | IntMatrixValue ipa -> IntValue ( fun args -> PA.Sum(ipa args))
      | _ -> failwith "prod!"  
  
  //-----------------------------------------------------------------------------        
  // Conversions...

  let intToFloatValues (a) = 
    match a with
      | IntMatrixValue ipa -> FloatMatrixValue ( fun args -> PA.ToFloatParallelArray(ipa args))
      | _ -> failwith "itf!"  
  let floatToIntValues (a) = 
    match a with
      | FloatMatrixValue fpa -> IntMatrixValue ( fun args -> PA.ToIntParallelArray(fpa args))
      | _ -> failwith "itf!"  
  let floatToFloat4Values (a) = 
    match a with
      | FloatMatrixValue fpa -> Float4MatrixValue ( fun args -> PA.ToFloat4ParallelArray(fpa args))
      | _ -> failwith "ftf4!"  
  let intToBoolValues (a) = 
    match a with
      | IntMatrixValue ipa -> BoolMatrixValue ( fun args -> let r = ipa args in PA.CompareNotEqual(r, new IPA(0, r.Shape) ))
      | _ -> failwith "itf!"  
  let boolToIntValues (a) = 
    match a with
      | BoolMatrixValue bpa -> IntMatrixValue ( fun args -> let r = bpa args in PA.Cond(r, new IPA(1, r.Shape), new IPA(0, r.Shape) ))
      | _ -> failwith "itf!"  

  //-----------------------------------------------------------------------------              
  // Generic Accelerator operations
  
  let selectValues (tst, v1, v2) =
    match tst, v1, v2 with
      | FloatMatrixValue fts, FloatMatrixValue fv1, FloatMatrixValue fv2 -> 
          FloatMatrixValue ( fun args -> PA.Select(fts args, fv1 args, fv2 args))
      | IntMatrixValue its, IntMatrixValue iv1, IntMatrixValue iv2 -> 
          IntMatrixValue ( fun args -> PA.Select(its args, iv1 args, iv2 args))
      | FloatMatrixValue fts, IntMatrixValue iv1, IntMatrixValue iv2 -> 
          IntMatrixValue ( fun args -> PA.ToIntParallelArray( PA.Select(fts args, PA.ToFloatParallelArray(iv1 args), PA.ToFloatParallelArray(iv2 args)) ))
      | _ -> failwith "sel!"

  let padValues (expr, bf, af, v) =
    match expr, v with
      | FloatMatrixValue fpa, FloatConst fv  -> FloatMatrixValue( fun args -> PA.Pad(fpa args, bf, af, fv args) )
      | Float4MatrixValue fpa, FloatConst fv  -> Float4MatrixValue( fun args -> PA.Pad(fpa args, bf, af, fv args) )
      | _ -> failwith "pad!"

  let gatherValues (src, yind, xind) =
    let pos = match yind, xind with | IntMatrixValue yi, IntMatrixValue xi -> ( fun args -> [|yi args; xi args|] ) | _ -> failwith "gather!";
    match src with
      | FloatMatrixValue fpa -> FloatMatrixValue( fun args -> PA.Gather(fpa args, pos args) )
      | Float4MatrixValue f4pa -> Float4MatrixValue( fun args -> PA.Gather(f4pa args, pos args) )
      | BoolMatrixValue bpa -> BoolMatrixValue( fun args -> PA.Gather(bpa args, pos args) )
      | IntMatrixValue ipa -> IntMatrixValue( fun args -> PA.Gather(ipa args, pos args) )
      | _ -> failwith "gather2!"

  let interpolateValues (a, b, c) =
    match a, b, c with
      | FloatMatrixValue fpa, FloatMatrixValue fpb, FloatMatrixValue fpc -> FloatMatrixValue( fun args -> PA.Interpolate(fpa args, fpb args, fpc args) )
      | Float4MatrixValue fpa, Float4MatrixValue fpb, Float4MatrixValue fpc -> Float4MatrixValue( fun args -> PA.Interpolate(fpa args, fpb args, fpc args) )
      | _ -> failwith "interpolate!"

  let fillPositionValues (hex, wex, dind) =
    match hex, wex, dind with
      | IntConst ih, IntConst iw, IntConst idim -> IntMatrixValue ( fun args -> PA.Positions([| ih args; iw args; |], idim args))
      | _ -> failwith "fill!"

  let shiftValues (exp, edy, edx) =
    let sz = match edx, edy with | IntConst x, IntConst y -> ( fun args -> [|y args; x args|] ) | _ -> failwith "shift!"
    match exp with
      | FloatMatrixValue fpa -> FloatMatrixValue( fun args -> PA.Shift(fpa args, sz args) );
      | Float4MatrixValue fpa -> Float4MatrixValue( fun args -> 
          PA.Shift(fpa args, sz args) );
      | IntMatrixValue ipa -> IntMatrixValue( fun args -> PA.Shift(ipa args, sz args) );
      | _ -> failwith "shift!";
      
  let rotateValues (exp, edy, edx) =
    let sz = match edx, edy with | IntConst x, IntConst y -> ( fun args -> [|y args; x args|] ) | _ -> failwith "shift!"
    match exp with
      | FloatMatrixValue fpa -> FloatMatrixValue ( fun args -> PA.Rotate(fpa args, sz args))
      | IntMatrixValue ipa -> IntMatrixValue ( fun args -> PA.ToIntParallelArray(PA.Rotate(PA.ToFloatParallelArray(ipa args), sz args)))
      | _ -> failwith "rot!"

  //-----------------------------------------------------------------------------              
  // Constant matrices
    
  let getConstMatrixKnownSize (shape:int []) value =
    match value with 
      | FloatConst f -> FloatMatrixValue(fun args -> new FPA(f args, shape))
      | IntConst i -> IntMatrixValue(fun args -> new IPA(i args, shape))
      | _ -> failwith "gcmks!"
   
  let getConstMatrixSameSize matrix value =
    let shape = 
      match matrix with 
        | FloatMatrixValue fpa -> ( fun args -> (fpa args).Shape )
        | Float4MatrixValue f4pa -> ( fun args -> (f4pa args).Shape )
        | IntMatrixValue ipa -> ( fun args -> (ipa args).Shape )
        | _ -> failwith "shape!"
    match value with 
      | FloatConst f -> FloatMatrixValue( fun args -> new FPA(f args, shape args))
      | IntConst i -> IntMatrixValue( fun args -> new IPA(i args, shape args))
      | Float4Const f -> Float4MatrixValue( fun args -> new F4PA((let f = f args in new Float4(f.f1,f.f2,f.f3,f.f4)), shape args))
      | _ -> failwith "gcmss!"
end
