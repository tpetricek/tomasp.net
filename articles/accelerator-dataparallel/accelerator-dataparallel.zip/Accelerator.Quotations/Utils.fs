﻿//---------------------------------------------------------------------------------------
// PERFORMANCE UTILS
//---------------------------------------------------------------------------------------
// To enable logging compile with: --define LOGGING 
//---------------------------------------------------------------------------------------

module FSharp.Utils

open System.Diagnostics
  
#if LOGGING

let printTime str f =
  let st = new Stopwatch()
  st.Start()
  let r = f()
  st.Stop()
  let t = st.Elapsed;
  printfn "%s: %dms" str (int t.TotalMilliseconds)
  r

#else

let inline printTime (str:string) f = f()

#endif 
