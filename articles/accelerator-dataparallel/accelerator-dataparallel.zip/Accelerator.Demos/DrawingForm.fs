namespace FSharp.Accelerator

open System
open System.Drawing
open System.Windows.Forms

//-----------------------------------------------------------------------------
/// A form that runs a loop - updating a state, drawing a new state...
// Parameters:
//   'initial' specifies the initial state, 'update' is a function that 
//   calculates new state from the previous one; 'draw' is a function that 
//   transforms the state to bitmap, so that it can be displayed. Finally,
//   'cleanup' that takes the state and cleans unmanaged resources
type DrawingForm<'TState>(initial:'TState, update, draw : 'TState -> Bitmap) as x = 
  inherit Form(Visible = true, ClientSize=Size(512, 512))
  let mutable closed = false
  
  // Loop that runs computation & redraws form
  let rec drawingLoop(state) = 
    // Calculate the next state - this also calls the click 
    // handler if the button was clicked since the last time
    let newstate = update(state)

    Application.DoEvents()
    if not closed then
      // Do the drawing & continue looping
      ( use gr = x.CreateGraphics()
        gr.InterpolationMode <- Drawing2D.InterpolationMode.NearestNeighbor
        gr.DrawImage(draw(newstate), x.ClientRectangle) )
      drawingLoop(newstate)

  member x.Run() = 
    // Run the computation
    x.Closing.Add(fun _ -> closed <- true)
    drawingLoop(initial)

type DrawingForm = 
  static member Run(init, update, draw) = 
    (new DrawingForm<_>(init, update, draw)).Run()
    
    