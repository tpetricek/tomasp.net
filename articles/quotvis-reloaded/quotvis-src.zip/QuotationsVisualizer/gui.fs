#light

open System
open System.Drawing
open System.Resources
open System.Reflection
open System.Collections.Generic
open System.Windows.Forms
open Microsoft.FSharp
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.MLLib
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw

open Visualizer
open Compiler

(*---------------------------------------------------------------------------*)
/// Dialog that is opened when user wants to add new F# 
/// (that will be compiled at runtime using FSC)
type EnterCodeDialog = class inherit Form as base

  val code : TextBox
  val title : TextBox
  val mutable expression : expr

  /// Build GUI...
  new ((parent:#Form)) as this = 
    { inherit Form() 
      code = new TextBox()
      title = new TextBox()
      expression = <@@ 1 @@>
    } then
    this.Owner <- parent
    this.Width <- 400
    this.Height <- 300
    this.StartPosition <- FormStartPosition.CenterParent
    this.Text <- "Enter quotation expression"
    this.ShowInTaskbar <- false
    this.MaximizeBox <- false
    this.MinimizeBox <- false
    this.FormBorderStyle <- FormBorderStyle.FixedDialog
    let lbl = new Label() in 
    lbl.Text <- "Title:"
    lbl.Left <- 4
    lbl.Width <- 50
    lbl.Top <- 4
    lbl.TextAlign <- ContentAlignment.MiddleLeft
    this.Controls.Add(lbl)
    this.title.Text <- "Generated"
    this.title.Left <- 54
    this.title.Width <- this.ClientSize.Width - 58
    this.title.Top <- 4
    this.title.Anchor <- MLLib.Enum.combine [AnchorStyles.Left; AnchorStyles.Right; AnchorStyles.Top]
    this.code.Text <- "let q = <@@ 1 @@>"
    this.code.SelectionLength <- 0
    this.code.Multiline <- true
    this.code.WordWrap <- false
    this.code.ScrollBars <- ScrollBars.Vertical
    this.code.Font <- new Font(FontFamily.GenericMonospace, Float.to_float32 9.0)
    this.code.Left <- 4
    this.code.Width <- this.ClientSize.Width - 8
    this.code.Top <- 28
    this.code.Height <- this.ClientSize.Height - 64
    this.code.Anchor <- MLLib.Enum.combine [AnchorStyles.Bottom; AnchorStyles.Left; AnchorStyles.Right; AnchorStyles.Top]
    this.Controls.Add(this.code)
    this.Controls.Add(this.title)
    let ok = new Button() in
    this.AcceptButton <- ok
    ok.FlatStyle <- FlatStyle.System
    ok.Text <- "OK"
    ok.Left <- this.ClientSize.Width - 64
    ok.Width <- 60
    ok.Top <- this.ClientSize.Height - 28
    ok.Height <- 22
    ok.Anchor <- MLLib.Enum.combine [AnchorStyles.Bottom; AnchorStyles.Right]
    ok.Click.Add( fun _ -> 
        match (compileExpr this.EnteredCode) with
          | Some(e) ->
            this.expression <- e
            this.DialogResult <- DialogResult.OK 
            this.Close() 
          | _ -> ignore(0)
      )
    this.Controls.Add(ok)

  /// F# source code entered by user
  member this.EnteredCode
    with get() = this.code.Text

  /// Title of entered expression 
  /// (will be used as title for tab page) 
  member this.EnteredTitle
    with get() = this.title.Text
  
  /// Compiled expression
  member this.CompiledExpression
    with get() = this.expression
end

(*---------------------------------------------------------------------------*)
/// Tab page that is used for displaying expression trees
/// It contains original object that represents the expression
type QuotationPanel = class inherit UserControl as base

  val expression : expr
  val tree : TreeView
  
  /// Build GUI...
  new ((s:string),(h:string),(e:expr),(imgs:ImageList)) as this = 
    { inherit UserControl()
      expression = e 
      tree = new TreeView()
    } then
    this.Padding <- new Padding(5)
    let pnl = new Panel() in
    let hdr = new TextBox() in
    hdr.Text <- (h.Replace("\t", "  ")).Replace("\n","\r\n")
    hdr.ReadOnly <- true
    hdr.Multiline <- true
    hdr.WordWrap <- false
    hdr.ScrollBars <- ScrollBars.Vertical
    hdr.Font <- new Font(FontFamily.GenericMonospace, Float.to_float32 9.0)
    pnl.Dock <- DockStyle.Bottom
    pnl.Height <- 140
    this.Text <- s
    this.Controls.Add(this.tree)
    this.Controls.Add(pnl)
    pnl.Controls.Add(hdr)
    hdr.Left <- 0
    hdr.Top <-10
    hdr.Width <- pnl.Width 
    hdr.Height <- pnl.Height - 10
    hdr.Anchor <- MLLib.Enum.combine [AnchorStyles.Bottom; AnchorStyles.Left; AnchorStyles.Right; AnchorStyles.Top]
    this.tree.ImageList <- imgs
    this.tree.Dock <- DockStyle.Fill

  /// Returns TreeView
  member this.QuotationTree
    with get() = this.tree
    
  // Returns expression at this tab 
  member this.Expression 
    with get() = this.expression    
    
end

(*---------------------------------------------------------------------------*)
type Main = class inherit Form as base

  val mutable exprTree : TreeView
  val mutable checkApps : CheckBox
  val mutable checkExpand : CheckBox
  val mutable treeIcons : ImageList
  val mutable menuPnl : Panel

  val mutable quotPanels : List<QuotationPanel>
  
  new () as this = 
    { inherit Form() 
      quotPanels = new List<QuotationPanel>();
      menuPnl = null
      exprTree = null 
      checkApps = null
      checkExpand = null
      treeIcons = null
    } then
    this.InitializeComponent()
  
  /// Build GUI...
  member this.InitializeComponent() =
    this.exprTree <- new TreeView()
    this.checkApps <- new CheckBox()
    this.checkExpand <- new CheckBox()
    let pnl = new Panel() in 
    let lbl1 = new Label() in
    let lbl2 = new Label() in
    let lbl3 = new Label() in
    let lnkExpand = new LinkLabel() in
    let lnkCollapse = new LinkLabel() in
    let lnkAddQuot = new LinkLabel() in
    let lnkOpenAssembly = new LinkLabel() in
    let lnkCloseCurrent = new LinkLabel() in
    this.menuPnl <- pnl
        
    // settings
    pnl.Dock <- DockStyle.Right
    pnl.Width <- 250 
    this.checkExpand.Text <- "Call deepMacroExpand on quotation"
    this.checkExpand.Left <- 16
    this.checkExpand.Width <- 220
    this.checkExpand.Top <- 72
    this.checkApps.Text <- "Group series together - matching prefers efApps and efLambdas"
    this.checkApps.FlatStyle <- FlatStyle.System
    this.checkExpand.FlatStyle <- FlatStyle.System
    this.checkApps.Left <- 16
    this.checkApps.Width <- 220
    this.checkApps.Top <- 32
    this.checkApps.Height <- 40
    this.checkApps.CheckedChanged.Add(fun _ -> this.RegenerateQuotations() )
    this.checkExpand.CheckedChanged.Add(fun _ -> this.RegenerateQuotations() )
    lbl1.Font <- new Font(lbl1.Font.Name, Float.to_float32 10.0, FontStyle.Bold)
    lbl1.Text <- "Settings"
    lbl1.Left <- 4
    lbl1.Top <- 8
    
    // tools
    lbl2.Font <- new Font(lbl1.Font.Name, Float.to_float32 10.0, FontStyle.Bold)
    lbl2.Text <- "Tools"
    lbl2.Left <- 4
    lbl2.Top <- 112    
    lnkExpand.Text <- "Expand current tree"
    lnkExpand.Left <- 32
    lnkExpand.Width <- 200
    lnkExpand.Top <- 136
    lnkExpand.Click.Add(fun _ -> this.CollapseOrExpandTree(true))
    lnkCollapse.Text <- "Collapse current tree"
    lnkCollapse.Left <- 32
    lnkCollapse.Width <- 200
    lnkCollapse.Top <- 160    
    lnkCollapse.Click.Add(fun _ -> this.CollapseOrExpandTree(false))
    lnkCloseCurrent.Text <- "Close current page"
    lnkCloseCurrent.Left <- 32
    lnkCloseCurrent.Width <- 200
    lnkCloseCurrent.Top <- 184    
    lnkCloseCurrent.Click.Add(fun _ -> this.CloseCurrentTab() )    
    lnkAddQuot.Text <- "Add new quotation"
    lnkAddQuot.Left <- 32
    lnkAddQuot.Width <- 200
    lnkAddQuot.Top <- 208    
    lnkAddQuot.Click.Add(fun _ -> this.AddQuotation() )        
    lnkOpenAssembly.Text <- "Open F# assembly"
    lnkOpenAssembly.Left <- 32
    lnkOpenAssembly.Width <- 200
    lnkOpenAssembly.Top <- 232    
    lnkOpenAssembly.Click.Add(fun _ -> this.OpenFsAssembly() )        
    
    // tabs & form
    this.Text <- "Quotations Visualizer"
    this.Width <- 800
    this.Height <- 600

    lbl3.Font <- new Font(lbl1.Font.Name, Float.to_float32 10.0, FontStyle.Bold)
    lbl3.Text <- "Quotations"
    lbl3.Left <- 4
    lbl3.Top <- 264
    this.exprTree.Left <- 32
    this.exprTree.Width <- 200
    this.exprTree.Height <- 268
    this.exprTree.Top <- 288
    this.exprTree.HideSelection <- false
    this.exprTree.AfterSelect.Add(fun e -> 
      if (e.Node.Tag <> null) then 
        this.SelectPanel(e.Node.Tag :?> QuotationPanel))

    pnl.Controls.Add(this.exprTree)    
    pnl.Controls.Add(lbl1)
    pnl.Controls.Add(lbl2)
    pnl.Controls.Add(lbl3)
    pnl.Controls.Add(lnkExpand)
    pnl.Controls.Add(lnkCollapse)
    pnl.Controls.Add(lnkCloseCurrent)
    pnl.Controls.Add(lnkAddQuot)
    pnl.Controls.Add(lnkOpenAssembly)
    pnl.Controls.Add(this.checkApps)
    pnl.Controls.Add(this.checkExpand)

    this.Controls.Add(pnl)
    this.exprTree.Anchor <- MLLib.Enum.combine [AnchorStyles.Top; AnchorStyles.Bottom]
        
    // load icons
    this.treeIcons <- new ImageList()
    this.treeIcons.TransparentColor <- Color.Fuchsia
    let mgr = new ResourceManager("Resources.Quotations", Assembly.GetExecutingAssembly()) in    
    ["root"; "app"; "apps"; "action"; "param"; "topdef"; "constant"; "var"; "hole"; 
     "let"; "letin"; "letwhat"; "call"; "ctorcall"; "seq"; "lambda"; "tuple"; "error"; "oper"; "statement";
     "quoted"; "lifted"] |> List.iter (fun n -> 
      this.treeIcons.Images.Add(mgr.GetObject(n) :?> Bitmap))
    
    let appIcons = new ImageList()
    appIcons.TransparentColor <- Color.Fuchsia
    let mgr = new ResourceManager("Resources.App", Assembly.GetExecutingAssembly()) in
    ["obj"; "asm"] |> List.iter (fun n -> appIcons.Images.Add(mgr.GetObject(n) :?> Bitmap))
    this.exprTree.ImageList <- appIcons
    

  member this.AddQuotationNode (t:string) (h:string) (e:expr) = 
    let pnl = new QuotationPanel(t,h,e,this.treeIcons) in
    pnl.Dock <- DockStyle.Fill
    this.Controls.Add(pnl)
    this.menuPnl.SendToBack()
    this.GenerateQuotation pnl
    this.quotPanels.Add(pnl)
    let nd = new TreeNode(t, 0, 0) in 
    nd.Tag <- (pnl :> obj)
    nd
  
  /// Adds new quotation to Tab control
  member this.AddQuotation (t:string) (h:string) (e:expr) = 
    let nd = this.AddQuotationNode t h e in
    ignore(this.exprTree.Nodes.Add(nd))
    
  /// Select panel with quotations
  member this.SelectPanel (p:QuotationPanel) =
    p.BringToFront()
    
  /// Close current tab 
  member this.CloseCurrentTab () = 
    if (this.exprTree.SelectedNode = null) then
      ignore(MessageBox.Show("No quotation is opened!", this.Text))
    else if (this.exprTree.SelectedNode.Tag <> null) then
      let pnl = (this.exprTree.SelectedNode.Tag) :?> QuotationPanel in
      ignore(this.quotPanels.Remove(pnl))
      this.Controls.Remove(pnl)
      this.exprTree.SelectedNode.Remove()
    else 
      this.exprTree.SelectedNode.Nodes |> IEnumerable.untyped_iter ( fun (nd:TreeNode) -> 
        let pnl = (nd.Tag) :?> QuotationPanel in
        ignore(this.quotPanels.Remove(pnl))
        this.Controls.Remove(pnl) )
      this.exprTree.SelectedNode.Remove()
    
  /// Generates trees for all expressions
  /// (this is called when settings are changed)
  member this.RegenerateQuotations () =
    foreach this.quotPanels (fun (pnl:QuotationPanel) ->
      this.GenerateQuotation pnl)
    
  /// Generates quotation tree on one tab page
  member this.GenerateQuotation (tab:QuotationPanel) =
    let exp = if (this.checkExpand.Checked) then deepMacroExpandUntil (fun _ -> false) tab.Expression else tab.Expression in
    let node = getExpressionTree exp (this.checkApps.Checked) in
    tab.QuotationTree.Nodes.Clear()
    ignore(tab.QuotationTree.Nodes.Add(node))
    tab.QuotationTree.ExpandAll()
        
  /// Collapses or expands tree on current tab page
  member this.CollapseOrExpandTree (expand:bool) = 
    if (this.exprTree.SelectedNode = null) then
      ignore(MessageBox.Show("No quotation is opened!", this.Text))
    else if (this.exprTree.SelectedNode.Tag <> null) then
      let tr = (this.exprTree.SelectedNode.Tag :?> QuotationPanel).QuotationTree in
      if (expand) then tr.ExpandAll() else tr.CollapseAll()
    
  /// Add quotation entered by user
  member this.AddQuotation () =
    let dlg = new EnterCodeDialog(this) in
    if (dlg.ShowDialog() = DialogResult.OK) then
      this.AddQuotation dlg.EnteredTitle dlg.EnteredCode dlg.CompiledExpression           
      
  member this.OpenFsAssembly () =
    let opf = new OpenFileDialog() in
    opf.Filter <- "F# assemblies|*.dll;*.exe";
    match opf.ShowDialog(this) with
      | DialogResult.OK ->
          resolveAssemblyTopDefs opf.FileName 
            ( fun t -> 
              let nd = new TreeNode(t.Name, 1, 1) in
              ignore(this.exprTree.Nodes.Add(nd))
              nd )
            ( fun ndType mi exp -> 
              let fn = new Text.StringBuilder() 
              ignore(fn.AppendFormat("Loaded from assembly: {0}\r\n", mi.DeclaringType.Assembly.FullName));
              ignore(fn.Append("Declared in type: "));
              if (mi.DeclaringType.Namespace <> null) then ignore(fn.AppendFormat("{0}.", mi.DeclaringType.Namespace))
              ignore(fn.Append(mi.DeclaringType.Name));
              let nd = this.AddQuotationNode mi.Name (fn.ToString()) exp 
              ignore(ndType.Nodes.Add(nd))
              )          
      | _ -> ()
end  