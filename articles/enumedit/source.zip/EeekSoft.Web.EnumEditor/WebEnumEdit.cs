using System;
using System.Web.UI;
using System.Reflection;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace EeekSoft.Web.Controls
{
	/// <summary>
	/// Type of enumeration editor
	/// </summary>
	public enum EnumEditorType
	{
		#region Members

		/// <summary>Automaticly detect type of control (using FlagsAttribute)</summary>
		Auto,
		/// <summary>Allow combination of more flags (uses checkbox)</summary>
		Flags,
		/// <summary>Allow only one selected item (radiobutton)</summary>
		Options

		#endregion
	}

	/// <summary>
	/// Enumeration editor control for Asp.Net
	/// </summary>
	[DefaultProperty("EnumValue"),
		ToolboxData("<{0}:EnumEditor runat=\"server\"></{0}:EnumEditor>")]
	public class EnumEditor : System.Web.UI.WebControls.WebControl
	{
		#region Local variables
		
		private string _lblFormat="{0}",_lblSeparator="<br />";
		private EnumEditorType _edType;
		private bool _autoPostback=false,_eventHandled=false;

		#endregion

		#region Public properties

		/// <summary>
		/// Type of enumeration to edit
		/// </summary>
		/// <example>
		/// <code>enumEditor1.EnumType=typeof(MyEnum);</code>
		/// </example>
		[Description("Type of enumeration to edit - cannot be set in design mode!"),
			Category("Enum editor")]
		public System.Type EnumType
		{
			get 
			{
				if (ViewState["type"]==null) return null;
				else return (System.Type)ViewState["type"];
			}
			set
			{
				ViewState["type"]=value;
				if (value!=null)
					AddEnumControls();
			}
		}


		/// <summary>
		/// Value of enumeration converted to integer
		/// </summary>
		/// <example>
		/// <code>
		/// MyEnum me=MyEnum.First;
		/// 
		/// // Set value
		/// enumEditor1.EnumValue=(long)me;
		/// 
		/// // Get value
		/// me=(MyEnum)enumEditor.EnumValue;
		/// </code>
		/// </example>
		[Description("Value of enumeration converted to integer"),
			DefaultValue(0),Category("Enum editor")]
		public long EnumValue
		{
			get 
			{
				if (ViewState["val"]==null) return 0;
				return (long)ViewState["val"];
			}
			set
			{
				ViewState["val"]=value;
				foreach(Control ctrl in Controls)
				{
					CheckBox btn=ctrl as CheckBox;
					if (btn==null) continue;

					int pos=btn.ID.LastIndexOf('_')+1;
					long val=Int64.Parse(btn.ID.Substring(pos,btn.ID.Length-pos));
					if (FlagsEditor)
						btn.Checked=(value&val)!=0;
					else
						btn.Checked=value==val;
				}
			}
		}


		/// <summary>
		/// Gets value specifiing whether editor mode is set to Flags
		/// </summary>
		[Browsable(false)]
		public bool FlagsEditor
		{
			get
			{
				bool bChecks=(EnumEditorType.Flags==_edType);
				if (_edType==EnumEditorType.Auto)
				{
					bChecks=(EnumType.GetCustomAttributes(typeof(FlagsAttribute),false).Length>0);
				}
				return bChecks;
			}
		}


		/// <summary>
		/// Format of checkbox or radiobutton label. Use {0} for name of field 
		/// and {1} for its description (added by DescriptionAttribute)
		/// </summary>
		/// <remarks>Default value is {0}</remarks>
		[DefaultValue("{0}{1}"),Description("Format of checkbox or radiobutton label. "+
			"Use {0} for name of field and {1} for its description (added by DescriptionAttribute)")]
		public string LableFormat
		{
			get { return _lblFormat; }
			set { _lblFormat=value; }
		}


		/// <summary>
		/// Separator between each two radiobuttons/checkboxes. Default value is &lt;br /&gt;
		/// </summary>
		[DefaultValue("<br />"),Category("Enum editor"),
			Description("Separator between each two radiobuttons/checkboxes.")]
		public string ControlSeparator
		{
			get { return _lblSeparator; }
			set { _lblSeparator=value; }
		}


		/// <summary>
		/// Type of editor (Flags editor/Options editor)
		/// <seealso cref="EnumEditorType"/>
		/// </summary>
		[DefaultValue(EnumEditorType.Auto),Category("Enum editor"),
			Description("Type of editor (Flags editor/Options editor)")]
		public EnumEditorType EditorType
		{
			get { return _edType; }
			set { _edType=value; }
		}


		/// <summary>
		/// Should control automaticly raise postback when user changes its value?
		/// </summary>
		[DefaultValue(false),Category("Enum editor"),
			Description("Should control automaticly raise postback when user changes its value?")]
		public bool AutoPostBack
		{
			get { return _autoPostback; }
			set { _autoPostback=value; }
		}


		#endregion
		#region Events

		/// <summary>
		/// Is raised after postback when user changed enumeration value
		/// </summary>
		[Category("Action"),
			Description("Is raised after postback when user changed enumeration value")]
		public event EventHandler Change;

		#endregion
		
		#region Implementation


		/// <summary>
		/// Load ViewState after postback
		/// </summary>
		/// <param name="savedState">ViewState</param>
		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState(savedState);
			if (ViewState["type"]!=null)
				AddEnumControls();
		}


		/// <summary>
		/// Helper: Get long value from object of unknown integer data type
		/// </summary>
		/// <param name="val">Any integer: int/long/byte.. etc..</param>
		/// <returns>Value converted to long</returns>
		private long GetLong(object val)
		{
			try { return (int)val;	} catch {}
			try { return (long)val;	} catch {}
			try { return (byte)val;	} catch {}
			try { return (short)val;	} catch {}
			try { return (int)val;	} catch {}
			try { return (long)((ulong)val);	} catch {}
			try { return (byte)val;	} catch {}
			try { return (short)val;	} catch {}
			throw new Exception("Invalid value.");
		}


		/// <summary>
		/// Generate web controls for editing
		/// </summary>
		private void AddEnumControls()
		{
			// Get fields
			FieldInfo[] fields=EnumType.GetFields();
			bool bFirst=true;
			foreach(FieldInfo field in fields)
			{
				if (field.IsSpecialName) continue;

				// skip this field ?
				object[] attrs;
				attrs=field.GetCustomAttributes(typeof(BrowsableAttribute),false);
				if (attrs.Length>0&&((BrowsableAttribute)attrs[0]).Browsable==false) continue;

				if (!bFirst)
				{
					Literal ltr=new Literal();
					ltr.Text=_lblSeparator;
					Controls.Add(ltr);
				}
				else bFirst=false;

				// Get description
				string description="";
				attrs=field.GetCustomAttributes(typeof(DescriptionAttribute),false);
				if (attrs.Length>0) description=((DescriptionAttribute)attrs[0]).Description;

				long val=GetLong(field.GetValue(EnumValue));

				// Generate checkbox or radio button
				CheckBox ctrl;
				if (FlagsEditor)
				{
					ctrl=new CheckBox();
					if ((val&EnumValue)>0) ctrl.Checked=true;				
					ctrl.CheckedChanged+=new EventHandler(ctrlCheck_CheckedChanged);
				}
				else
				{
					ctrl=new RadioButton();
					((RadioButton)ctrl).GroupName=ID;
					if (val==EnumValue) ctrl.Checked=true;
					ctrl.CheckedChanged+=new EventHandler(ctrlRadio_CheckedChanged);
				}
				ctrl.AutoPostBack=AutoPostBack;

				// set control properties and add it to collection
				ctrl.ID=ID+"_"+val.ToString();
				ctrl.Text=string.Format(_lblFormat,field.Name,description);
				Controls.Add(ctrl);
			}
		}


		/// <summary>
		/// Render control
		/// </summary>
		/// <param name="writer">Output</param>
		protected override void Render(HtmlTextWriter writer)
		{
			RenderChildren(writer);
		}


		/// <summary>
		/// Value of checkbox changed - update enum value
		/// </summary>
		private void ctrlCheck_CheckedChanged(object sender, EventArgs e)
		{
			if (_eventHandled) return;

			long old=EnumValue,nval=0;
			foreach(Control ctrl in Controls)
			{
				CheckBox btn=ctrl as CheckBox;
				if (btn==null) continue;

				int pos=btn.ID.LastIndexOf('_')+1;
				long val=Int64.Parse(btn.ID.Substring(pos,btn.ID.Length-pos));
				if (btn.Checked) nval|=val;
			}
			_eventHandled=true;
			EnumValue=nval;			
			if (EnumValue!=old) OnChange();
		}


		/// <summary>
		/// Value of radiobutton changed - update enum value
		/// </summary>
		private void ctrlRadio_CheckedChanged(object sender, EventArgs e)
		{
			long old=EnumValue;

			CheckBox btn=(CheckBox)sender;
			if (!btn.Checked) return;

			int pos=btn.ID.LastIndexOf('_')+1;
			EnumValue=Int64.Parse(btn.ID.Substring(pos,btn.ID.Length-pos));
			if (EnumValue!=old) OnChange();
		}


		/// <summary>
		/// Raise change event
		/// </summary>
		protected virtual void OnChange()
		{
			if (Change!=null)
				Change(this,EventArgs.Empty);
		}

		#endregion
	}
}
