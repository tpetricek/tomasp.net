using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using EeekSoft.WinForms.Controls;

namespace WinFormsDemo
{
	[Flags]
	enum MyFruitEnum : byte
	{
		[Browsable(false)]
		None=0,

		[Browsable(false)]
		AllFruits=31,

		Apple=1,
		Banana=2,
		[Description(" (red)")]
		Melon=4,
		Pear=8,
		Plum=16
	}

	enum MyColorEnum 
	{
		[Description("000000")]
		Black,
		[Description("FFFFFF")]
		White,
		[Description("FF0000")]
		Red,
		[Description("00FF00")]
		Green,
		[Description("0000FF")]
		Bule,
		[Description("FF00FF")]
		Violet,
		[Description("FFFF00")]
		Yellow,
		[Description("00FFFF")]
		Aqua,
	}

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region Standard template code

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnBanana;
		private System.Windows.Forms.Label lblFruit;
		private EeekSoft.WinForms.Controls.EnumEditor fruitEnumEditor;
		private System.Windows.Forms.Button btnNone;
		private System.Windows.Forms.GroupBox groupBox2;
		private EeekSoft.WinForms.Controls.EnumEditor colorEnumEditor;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblSelColor;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.fruitEnumEditor = new EeekSoft.WinForms.Controls.EnumEditor();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.lblFruit = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBanana = new System.Windows.Forms.Button();
			this.btnNone = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lblSelColor = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.colorEnumEditor = new EeekSoft.WinForms.Controls.EnumEditor();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// fruitEnumEditor
			// 
			this.fruitEnumEditor.ControlSpacing = 20;
			this.fruitEnumEditor.EnumType = null;
			this.fruitEnumEditor.EnumValue = ((long)(0));
			this.fruitEnumEditor.LableFormat = "{0}{1}";
			this.fruitEnumEditor.Location = new System.Drawing.Point(16, 16);
			this.fruitEnumEditor.Name = "fruitEnumEditor";
			this.fruitEnumEditor.Size = new System.Drawing.Size(96, 104);
			this.fruitEnumEditor.TabIndex = 0;
			this.fruitEnumEditor.Change += new System.EventHandler(this.fruitEnumEditor_Change);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.lblFruit);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.fruitEnumEditor);
			this.groupBox1.Controls.Add(this.btnBanana);
			this.groupBox1.Controls.Add(this.btnNone);
			this.groupBox1.Location = new System.Drawing.Point(240, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(224, 240);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Select fruits:";
			// 
			// lblFruit
			// 
			this.lblFruit.Location = new System.Drawing.Point(80, 144);
			this.lblFruit.Name = "lblFruit";
			this.lblFruit.Size = new System.Drawing.Size(136, 32);
			this.lblFruit.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label1.Location = new System.Drawing.Point(16, 144);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 5;
			this.label1.Text = "Selected:";
			// 
			// btnBanana
			// 
			this.btnBanana.Location = new System.Drawing.Point(120, 192);
			this.btnBanana.Name = "btnBanana";
			this.btnBanana.Size = new System.Drawing.Size(96, 23);
			this.btnBanana.TabIndex = 2;
			this.btnBanana.Text = "Banana !";
			this.btnBanana.Click += new System.EventHandler(this.btnBanana_Click);
			// 
			// btnNone
			// 
			this.btnNone.Location = new System.Drawing.Point(16, 192);
			this.btnNone.Name = "btnNone";
			this.btnNone.Size = new System.Drawing.Size(96, 23);
			this.btnNone.TabIndex = 4;
			this.btnNone.Text = "None !";
			this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.lblSelColor);
			this.groupBox2.Controls.Add(this.label2);
			this.groupBox2.Controls.Add(this.colorEnumEditor);
			this.groupBox2.Location = new System.Drawing.Point(8, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(224, 240);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Select fruits:";
			// 
			// lblSelColor
			// 
			this.lblSelColor.Location = new System.Drawing.Point(72, 216);
			this.lblSelColor.Name = "lblSelColor";
			this.lblSelColor.Size = new System.Drawing.Size(96, 16);
			this.lblSelColor.TabIndex = 6;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label2.Location = new System.Drawing.Point(16, 216);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.TabIndex = 7;
			this.label2.Text = "Selected:";
			// 
			// colorEnumEditor
			// 
			this.colorEnumEditor.EnumType = null;
			this.colorEnumEditor.EnumValue = ((long)(16));
			this.colorEnumEditor.LableFormat = "{0} (hex value = {1})";
			this.colorEnumEditor.Location = new System.Drawing.Point(16, 16);
			this.colorEnumEditor.Name = "colorEnumEditor";
			this.colorEnumEditor.Size = new System.Drawing.Size(168, 192);
			this.colorEnumEditor.TabIndex = 0;
			this.colorEnumEditor.Change += new System.EventHandler(this.colorEnumEditor_Change);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 253);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "Enum editor test form";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		#endregion

		private void Form1_Load(object sender, System.EventArgs e)
		{
			fruitEnumEditor.EnumType=typeof(MyFruitEnum);
			fruitEnumEditor.EnumValue=(long)MyFruitEnum.Apple;
			fruitEnumEditor_Change(null,EventArgs.Empty);

			colorEnumEditor.EnumType=typeof(MyColorEnum);
			colorEnumEditor.EnumValue=(long)MyColorEnum.Aqua;
			colorEnumEditor_Change(null,EventArgs.Empty);
		}

		private void btnBanana_Click(object sender, System.EventArgs e)
		{
			fruitEnumEditor.EnumValue=(long)MyFruitEnum.Banana;
			fruitEnumEditor_Change(null,EventArgs.Empty);
		}

		private void btnNone_Click(object sender, System.EventArgs e)
		{
			fruitEnumEditor.EnumValue=(long)MyFruitEnum.None;
			fruitEnumEditor_Change(null,EventArgs.Empty);
		}

		private void fruitEnumEditor_Change(object sender, System.EventArgs e)
		{
			lblFruit.Text=((MyFruitEnum)fruitEnumEditor.EnumValue).ToString();
		}

		private void colorEnumEditor_Change(object sender, System.EventArgs e)
		{
			lblSelColor.Text=((MyColorEnum)colorEnumEditor.EnumValue).ToString();
		}
	}
}
