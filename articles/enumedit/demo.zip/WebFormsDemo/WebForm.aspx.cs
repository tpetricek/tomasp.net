using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebFormsDemo
{
	[Flags]
	enum MyFruitEnum : byte
	{
		[Browsable(false)]
		None=0,

		[Browsable(false)]
		AllFruits=31,

		Apple=1,
		Banana=2,
		[Description(" (red)")]
		Melon=4,
		Pear=8,
		Plum=16
	}

	enum MyColorEnum 
	{
		[Description("<span style=\"color:#000000\">[color sample]</span>")]
		Black,
		[Description("<span style=\"color:#d0d0d0\">[color sample]</span>")]
		White,
		[Description("<span style=\"color:#ff0000\">[color sample]</span>")]
		Red,
		[Description("<span style=\"color:#00ff00\">[color sample]</span>")]
		Green,
		[Description("<span style=\"color:#0000ff\">[color sample]</span>")]
		Bule,
		[Description("<span style=\"color:#ff00ff\">[color sample]</span>")]
		Violet,
		[Description("<span style=\"color:#d0d000\">[color sample]</span>")]
		Yellow,
		[Description("<span style=\"color:#00d0d0\">[color sample]</span>")]
		Aqua,
	}

	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected EeekSoft.Web.Controls.EnumEditor colorEnumEditor;
		protected System.Web.UI.WebControls.Label fruitLabel;
		protected System.Web.UI.WebControls.Label colorLabel;
		protected System.Web.UI.WebControls.Button btnPostback;
		protected System.Web.UI.WebControls.Button btnNoFruit;
		protected EeekSoft.Web.Controls.EnumEditor fruitEnumEditor;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				fruitEnumEditor.EnumType=typeof(MyFruitEnum);
				fruitEnumEditor.EnumValue=(long)MyFruitEnum.Apple;
				fruitEnumEditor_Change(null,EventArgs.Empty);

				colorEnumEditor.EnumType=typeof(MyColorEnum);
				colorEnumEditor.EnumValue=(long)MyColorEnum.Black;
				colorEnumEditor_Change(null,EventArgs.Empty);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.fruitEnumEditor.Change += new System.EventHandler(this.fruitEnumEditor_Change);
			this.btnNoFruit.Click += new System.EventHandler(this.btnNoFruit_Click);
			this.colorEnumEditor.Change += new System.EventHandler(this.colorEnumEditor_Change);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void fruitEnumEditor_Change(object sender, System.EventArgs e)
		{
			fruitLabel.Text=((MyFruitEnum)fruitEnumEditor.EnumValue).ToString();
		}

		private void colorEnumEditor_Change(object sender, System.EventArgs e)
		{
			colorLabel.Text=((MyColorEnum)colorEnumEditor.EnumValue).ToString();
		}

		private void btnNoFruit_Click(object sender, System.EventArgs e)
		{
			fruitEnumEditor.EnumValue=(long)MyFruitEnum.None;
			fruitEnumEditor_Change(null,EventArgs.Empty);
		}
	}
}
