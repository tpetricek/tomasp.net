using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Threading;
using System.Globalization;

namespace GlobalizationDemo
{
	/// <summary>
	/// Hlavni okno ukazkove aplikace pro praci s Globalization
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region Windows Form Designer generated code

		private System.Windows.Forms.ComboBox comboCultures;
		private System.Windows.Forms.Label lblDateTime;
		private System.Windows.Forms.Label lblFloatNumber;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Timer tmrRefresh;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lblDayNames;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label lblMonthNames;
		private System.ComponentModel.IContainer components;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.comboCultures = new System.Windows.Forms.ComboBox();
			this.lblDateTime = new System.Windows.Forms.Label();
			this.lblFloatNumber = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.tmrRefresh = new System.Windows.Forms.Timer(this.components);
			this.label3 = new System.Windows.Forms.Label();
			this.lblDayNames = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.lblMonthNames = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// comboCultures
			// 
			this.comboCultures.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboCultures.Location = new System.Drawing.Point(8, 8);
			this.comboCultures.Name = "comboCultures";
			this.comboCultures.Size = new System.Drawing.Size(232, 21);
			this.comboCultures.TabIndex = 0;
			this.comboCultures.SelectedIndexChanged += new System.EventHandler(this.comboCultures_SelectedIndexChanged);
			// 
			// lblDateTime
			// 
			this.lblDateTime.Location = new System.Drawing.Point(24, 56);
			this.lblDateTime.Name = "lblDateTime";
			this.lblDateTime.Size = new System.Drawing.Size(184, 23);
			this.lblDateTime.TabIndex = 1;
			this.lblDateTime.Text = "label1";
			// 
			// lblFloatNumber
			// 
			this.lblFloatNumber.Location = new System.Drawing.Point(24, 96);
			this.lblFloatNumber.Name = "lblFloatNumber";
			this.lblFloatNumber.Size = new System.Drawing.Size(184, 23);
			this.lblFloatNumber.TabIndex = 2;
			this.lblFloatNumber.Text = "label1";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 16);
			this.label1.TabIndex = 3;
			this.label1.Text = "Date & time:";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label2.Location = new System.Drawing.Point(8, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Numbers:";
			// 
			// tmrRefresh
			// 
			this.tmrRefresh.Enabled = true;
			this.tmrRefresh.Interval = 1000;
			this.tmrRefresh.Tick += new System.EventHandler(this.tmrRefresh_Tick);
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label3.Location = new System.Drawing.Point(8, 120);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Days names:";
			// 
			// lblDayNames
			// 
			this.lblDayNames.Location = new System.Drawing.Point(24, 136);
			this.lblDayNames.Name = "lblDayNames";
			this.lblDayNames.Size = new System.Drawing.Size(184, 40);
			this.lblDayNames.TabIndex = 5;
			this.lblDayNames.Text = "label1";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label4.Location = new System.Drawing.Point(8, 176);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 16);
			this.label4.TabIndex = 8;
			this.label4.Text = "Month names:";
			// 
			// lblMonthNames
			// 
			this.lblMonthNames.Location = new System.Drawing.Point(24, 192);
			this.lblMonthNames.Name = "lblMonthNames";
			this.lblMonthNames.Size = new System.Drawing.Size(184, 72);
			this.lblMonthNames.TabIndex = 7;
			this.lblMonthNames.Text = "label1";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(248, 266);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lblMonthNames);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.lblDayNames);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lblFloatNumber);
			this.Controls.Add(this.lblDateTime);
			this.Controls.Add(this.comboCultures);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "Globalization Demo";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Vstupni bod aplikace
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}


		/// <summary>
		/// Pomocna trida, ktera obsahuje informace o
		/// culture a v metode ToString() vraci cele jmeno
		///  - pouziva se v DropDownListu
		/// </summary>
		class MyClutureInfo 
		{
			public CultureInfo Culture;
			public MyClutureInfo(CultureInfo cult)
			{
				Culture=cult;
			}
			public override string ToString()
			{
				return Culture.DisplayName;
			}
		}


		/// <summary>
		/// Nacita cultures do DropDownListu
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void MainForm_Load(object sender, System.EventArgs e)
		{
			// zjisti vsechny cultures
			CultureInfo[] cultures=
				CultureInfo.GetCultures(CultureTypes.AllCultures);
			
			// naplni dropdownlist a zapamatuje si index aktualni culture
			int selIdnex=0;
			foreach(CultureInfo culture in cultures)
			{
				comboCultures.Items.Add(new MyClutureInfo(culture));
				if (culture.Name==Thread.CurrentThread.CurrentCulture.Name)
					selIdnex=comboCultures.Items.Count-1;
			}
			comboCultures.SelectedIndex=selIdnex;
		}


		/// <summary>
		/// Zmena vyberu v dropdownlistu - nastavit culture a obnovit data
		/// </summary>
		private void comboCultures_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Zjisti vybranou culture
			CultureInfo selected=((MyClutureInfo)comboCultures.SelectedItem).Culture;
			
			try
			{
				// nastavi hlavnimu threadu danou culture
				Thread.CurrentThread.CurrentCulture=
					CultureInfo.CreateSpecificCulture(selected.Name);
			}
			catch
			{
				// doslo k chybe - nektere cultures nelze pouzit,
				// protoze .NET ma vetsi seznam nez WinAPI, ktere se zde
				// interne pouzivaji
				// 
				// ..napriklad zh-CHT (Chinese Traditional)
				MessageBox.Show(string.Format(
					"Culture {0} isn't supported!\nPlease select another.",selected.Name),
					selected.DisplayName);
			}
			// Zobrazit znovu data
			DisplayGlobalizedData();
		}


		/// <summary>
		/// Zobrazuje ukazkova data
		/// </summary>
		private void DisplayGlobalizedData()
		{
			// zobrazit cislo
			lblFloatNumber.Text=Math.PI.ToString();

			// zobrazit jmena dnu v tydnu
			string tmp="";
			foreach(string dayName in Thread.CurrentThread.
				CurrentCulture.DateTimeFormat.DayNames)
			{
				tmp+=", "+dayName;
			}
			lblDayNames.Text=tmp.Substring(2);

			// zobrazit jmena mesicu
			tmp="";
			for(int i=0; i<12; i++)
			{
				string monthName=Thread.CurrentThread.
					CurrentCulture.DateTimeFormat.MonthNames[i];			
				tmp+=", "+monthName;
			}
			lblMonthNames.Text=tmp.Substring(2);

			// aktualizovat cas
			tmrRefresh_Tick(null,EventArgs.Empty);
		}


		/// <summary>
		/// Nastavuje labelu aktualni cas
		/// </summary>
		private void tmrRefresh_Tick(object sender, System.EventArgs e)
		{
			lblDateTime.Text=DateTime.Now.ToString();
		}
	}
}
