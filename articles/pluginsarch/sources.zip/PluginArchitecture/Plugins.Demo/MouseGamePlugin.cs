using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Plugins.Demo
{
	/// <summary>
	/// Implementace ukazkoveho pluginu
	/// </summary>
	public class MouseGamePlugin : Plugins.Base.BaseControl
	{
		#region Standardni generovany kod

		private System.Windows.Forms.Button btnClickMe;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}


		#endregion
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClickMe = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnClickMe
			// 
			this.btnClickMe.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnClickMe.Location = new System.Drawing.Point(32, 32);
			this.btnClickMe.Name = "btnClickMe";
			this.btnClickMe.TabIndex = 0;
			this.btnClickMe.Text = "Klikni sem!";
			this.btnClickMe.Visible = false;
			this.btnClickMe.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnClickMe_MouseUp);
			// 
			// DemoPlugin
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.btnClickMe);
			this.Name = "DemoPlugin";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Vytvori objekt pro hru a inicializuje nahodna cisla
		/// </summary>
		public MouseGamePlugin()
		{
			InitializeComponent();
			rnd=new Random();
		}

		/// <summary> Pocet kliknuti </summary>
		int clickCount;
		/// <summary> Generator nahodnych cisel </summary>
		Random rnd;


		/// <summary>
		/// Vraci jmeno hry
		/// </summary>
		public override string ToString()
		{
			return "Klikaci hra";
		}

		/// <summary>
		/// Vraci popisku hry
		/// </summary>
		public override string Description
		{
			get { return "V teto hre se pocita, kolikrat kliknete "+
				"na tlacitko.\n(musite ale opravdu klikat mysi!)"; }
		}


		/// <summary>
		/// Spusti hru - zobrazi tlacitko a zresetuje pocet kliknuti
		/// </summary>
		public override void Start()
		{
			clickCount=0;
			btnClickMe.Visible=true;
			btnClickMe_MouseUp(null,new MouseEventArgs(MouseButtons.None,0,0,0,0));
		}


		/// <summary>
		/// Zastavi hru - zkryje tlacitko a vrati vysledek (pocet kliknuti)
		/// </summary>
		public override string Stop()
		{
			btnClickMe.Visible=false;
			return "Vase skore je: "+clickCount.ToString();
		}


		/// <summary>
		/// Zpracovava kliknuti na tlacitko - zvysi pocet kliknuti 
		/// a posune tlacitko na jine nahodne misto
		/// </summary>
		private void btnClickMe_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (btnClickMe.Width>Width||btnClickMe.Height>Height) return;
			btnClickMe.Left=rnd.Next(Width-btnClickMe.Width);
			btnClickMe.Top=rnd.Next(Height-btnClickMe.Height);
			clickCount++;
		}
	}
}
