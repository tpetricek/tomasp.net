using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Plugins.Base
{
	/// <summary>
	/// Zakladni trida od ktere budou odvozene vsechny pluginy
	/// Tato trida sama o sobe nic nedela, proto je 'abstract'
	/// </summary>
	public class BaseControl : UserControl
	{
		/// <summary>
		/// Spousti nejakou aktivitu, kterou plugin dela
		/// </summary>
		public virtual void Start() {}

		/// <summary>
		/// Zastavuje aktivitu pluginu
		/// </summary>
		/// <returns>Vraci vysledek akce (jako textovy retezec)..</returns>
		public virtual string Stop() { return ""; }

		/// <summary>
		/// Vraci popis o cem v pluginu jde, ktery se zobrazuje pred spustenim
		/// </summary>
		public virtual string Description 
		{ 
			get { return ""; }
		}
	}
}
