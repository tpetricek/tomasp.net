using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Plugins.Base;

namespace Plugins.Main
{
	/// <summary>
	/// Hlavni formular aplikace - nacita pluginy a spousti hru
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region Vygenerovany kod

		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem itemPlugins;
		private System.Windows.Forms.GroupBox pluginPanel;
		private System.Windows.Forms.MenuItem miHideAll;
		private System.Windows.Forms.MenuItem miN1;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.Timer tmrWait;
		private System.ComponentModel.IContainer components;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.itemPlugins = new System.Windows.Forms.MenuItem();
			this.miHideAll = new System.Windows.Forms.MenuItem();
			this.miN1 = new System.Windows.Forms.MenuItem();
			this.pluginPanel = new System.Windows.Forms.GroupBox();
			this.btnStart = new System.Windows.Forms.Button();
			this.lblStatus = new System.Windows.Forms.Label();
			this.tmrWait = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																																						 this.itemPlugins});
			// 
			// itemPlugins
			// 
			this.itemPlugins.Index = 0;
			this.itemPlugins.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																																								this.miHideAll,
																																								this.miN1});
			this.itemPlugins.Text = "Pluginy";
			// 
			// miHideAll
			// 
			this.miHideAll.Checked = true;
			this.miHideAll.Index = 0;
			this.miHideAll.Text = "Skryt vsechny";
			this.miHideAll.Click += new System.EventHandler(this.miHideAll_Click);
			// 
			// miN1
			// 
			this.miN1.Index = 1;
			this.miN1.Text = "-";
			// 
			// pluginPanel
			// 
			this.pluginPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pluginPanel.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.pluginPanel.Location = new System.Drawing.Point(8, 8);
			this.pluginPanel.Name = "pluginPanel";
			this.pluginPanel.Size = new System.Drawing.Size(376, 175);
			this.pluginPanel.TabIndex = 0;
			this.pluginPanel.TabStop = false;
			this.pluginPanel.Text = "Aktualni plugin";
			// 
			// btnStart
			// 
			this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnStart.Enabled = false;
			this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnStart.Location = new System.Drawing.Point(8, 196);
			this.btnStart.Name = "btnStart";
			this.btnStart.TabIndex = 1;
			this.btnStart.Text = "Start";
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// lblStatus
			// 
			this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblStatus.Location = new System.Drawing.Point(96, 200);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(168, 23);
			this.lblStatus.TabIndex = 2;
			this.lblStatus.Text = "Nejprve otevrte plugin...";
			// 
			// tmrWait
			// 
			this.tmrWait.Interval = 1000;
			this.tmrWait.Tick += new System.EventHandler(this.tmrWait_Tick);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(392, 227);
			this.Controls.Add(this.lblStatus);
			this.Controls.Add(this.btnStart);
			this.Controls.Add(this.pluginPanel);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "MainForm";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Vstupni bod aplikace - spusti program
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.Run(new MainForm());
		}


		/// <summary>
		/// Polozka v menu, ktera krom textu v menu obsahuje
		/// i informace o pluginu, ktery se ma vytvorit pokud
		/// uzivatel na tuto polozku klikne..
		/// </summary>
		private class PluginMenuItem : MenuItem
		{
			#region Members
			
			PluginInfo info;

			/// <summary>
			/// Vytvari polozku v menu a zjistuje text 
			/// </summary>
			/// <param name="i">Informace o zadanem pluginu</param>
			public PluginMenuItem(PluginInfo i)
			{
				info=i;
				Text=i.Create().ToString();
			}


			/// <summary>
			/// Vraci informace o pluginu - pro jeho vytvoreni
			/// </summary>
			public PluginInfo Plugin
			{
				get { return info; }
			}

			#endregion
		}


		/// <summary>
		/// Prave nacteny plugin
		/// </summary>
		BaseControl currentPlugin=null;

		/// <summary>
		/// Cas do konce hry
		/// </summary>
		int currentTime=20;


		/// <summary>
		/// Nacita pluginy pomoci objektu PluginsConfig a 
		/// vytvari menu, ktere obsahuje seznam pluginu
		/// </summary>
		private void MainForm_Load(object sender, System.EventArgs e)
		{
			PluginsConfig plugins=PluginsConfig.Create();
			foreach(PluginInfo plugin in plugins)
			{
				// vytvori polozku v menu ktera obsahuje navic informace o pluginu
				MenuItem mi=new PluginMenuItem(plugin);
				itemPlugins.MenuItems.Add(mi);
				mi.Click+=new EventHandler(menuPlugin_Click);
			}
		}


		/// <summary>
		/// Pomocna metoda, ktera prida zaskrtavatko k dane polozce v menu
		/// </summary>
		/// <param name="check">Polozka ktera ma byt zaskrtnuta</param>
		private void CheckMenuItem(MenuItem check)
		{
			foreach(MenuItem item in itemPlugins.MenuItems)
				item.Checked=(check==item);
		}


		/// <summary>
		/// Uzivatel kliknul na polozku v menu s pluginem -
		/// zaskrtne polozku, zkryje minulou hru a nacte novou
		/// </summary>
		private void menuPlugin_Click(object sender, EventArgs e)
		{
			// zjisti polozku v menu a vytvori novy plugin
			PluginMenuItem mi=(PluginMenuItem)sender;
			BaseControl ctrl=(BaseControl)mi.Plugin.Create();

			// prida plugin do panelu, kde se zobrazuji pluginy
			pluginPanel.Controls.Clear();
			pluginPanel.Controls.Add(ctrl);
			ctrl.Left=4; ctrl.Top=16;
			ctrl.Width=pluginPanel.Width-8; 
			ctrl.Height=pluginPanel.Height-24;
			ctrl.Anchor=AnchorStyles.Left|AnchorStyles.Right|
				AnchorStyles.Bottom|AnchorStyles.Top;

			// zobrazi jmeno pluginu
			lblStatus.Text=string.Format("Plugin '{0}' nacten!",ctrl.ToString());
			currentPlugin=ctrl;
			btnStart.Enabled=true;
			CheckMenuItem(mi);
		}


		/// <summary>
		/// Zkryje vsechny pluginy
		/// </summary>
		private void miHideAll_Click(object sender, System.EventArgs e)
		{
			pluginPanel.Controls.Clear();
			CheckMenuItem(miHideAll);
			currentPlugin=null;
			btnStart.Enabled=false;
			lblStatus.Text="Nejprve otevrte plugin...";
		}


		/// <summary>
		/// Spusti aktualne nacteny plugin
		/// </summary>
		private void btnStart_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show(currentPlugin.Description,Text,
				MessageBoxButtons.OK,MessageBoxIcon.Information);
			currentPlugin.Start();
			currentTime=21;
			btnStart.Enabled=false;
			tmrWait.Enabled=true;
			itemPlugins.Enabled=false;
			tmrWait_Tick(sender,e);
		}


		/// <summary>
		/// Jiz vyprsela doba pro hru - ukonci hru a zobrazi vysledek
		/// </summary>
		private void tmrWait_Tick(object sender, System.EventArgs e)
		{
			currentTime--;
			lblStatus.Text=string.Format("Mate jeste {0} sekund",currentTime);
			if (currentTime==0)
			{
				tmrWait.Enabled=false;
				itemPlugins.Enabled=true;
				btnStart.Enabled=true;
        string msg=currentPlugin.Stop();
				lblStatus.Text=msg;
			}
		}
	}
}
