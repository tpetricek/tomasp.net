using System;
using System.IO;
using System.Xml;
using System.Reflection;
using System.Collections;
using System.Configuration;

namespace Plugins.Main
{
	/// <summary>
	/// Vyjimka, ktera je vyhozena pokud dojde k chybe 
	/// </summary>
	public class PluginException : Exception
	{
		#region Members

		/// <summary>
		/// Vytvori vyjimku
		/// </summary>
		/// <param name="msg">Chybova zprava</param>
		public PluginException(string msg) : base(msg) {}

		#endregion
	}


	/// <summary>
	/// Struktura obsahuje informace o pluginu a umi 
	/// vytvorit novou instanci 
	/// </summary>
	public struct PluginInfo
	{
		#region Private

		private Assembly _asm;
		private string _cls;

		#endregion
		#region Constructor

		/// <summary>
		/// Vytvari objekt pro ukladani informaci o pluginu
		/// </summary>
		/// <param name="asm">Jmeno assembly, ze ktere se nacita</param>
		/// <param name="cls">Jmeno tridy pluginu</param>
		public PluginInfo(string asm,string cls)
		{
			try
			{
				asm=Path.GetFullPath(asm);
				_asm=System.Reflection.Assembly.LoadFile(asm);
				_asm.CreateInstance(cls);
				_cls=cls;
			}
			catch 
			{
				throw new PluginException("Error while loading plugin. Assembly or class doesn't exist!");
			}
		}

		#endregion
		#region Methods

		/// <summary>
		/// Vytvori novou instanci daneho pluginu
		/// </summary>
		/// <returns>Vraci vytvoreny plugin</returns>
		public object Create()
		{
			return _asm.CreateInstance(_cls);
		}

		#endregion
	}


	/// <summary>
	/// Objekt pro nacitani pluginu z konfiguracniho souboru
	/// </summary>
	public class PluginsConfig : IConfigurationSectionHandler,IEnumerable
	{
		#region Private

		ArrayList plugins;

		#endregion
		#region Public

		/// <summary>
		/// Vytvori objekt PluginsConfig pro aktualni aplikaci
		/// </summary>
		/// <returns>Objekt s informacemi o pluginech</returns>
		public static PluginsConfig Create()
		{
			return (PluginsConfig)ConfigurationSettings.GetConfig("pluginsSection");
		}

		
		/// <summary>
		/// Vytvari objekt a private seznam pluginu
		/// </summary>
		private PluginsConfig()
		{
			plugins=new ArrayList();
		}


		/// <summary>
		/// Tato metoda je volana .net frameworkem pri volani
		/// (PluginsConfig)ConfigurationSettings.GetConfig("pluginsSection")
		/// </summary>
		/// <param name="section">Sekce obsahujici Xml nastaveni</param>
		/// <returns>Objekt s informacemi o pluginech</returns>
		public object Create(object parent, object configContext, XmlNode section)
		{
			PluginsConfig ret=new PluginsConfig();
			foreach(XmlNode nd in section.SelectNodes("plugin"))
			{
				if (nd.Attributes["assembly"]==null||nd.Attributes["class"]==null)
					throw new PluginException("Invalid configuration file! "+
						"Assembly or class attribute is missing.");
				PluginInfo pi=new PluginInfo(nd.Attributes["assembly"].Value,
					nd.Attributes["class"].Value);
				ret.plugins.Add(pi);
			}
			return ret;
		}
		

		/// <summary>
		/// Umoznuje prochazet vsechny pluginy pomoci foreach
		/// </summary>
		/// <returns>Enumerator ArrayListu s informacemi o pluginech</returns>
		public IEnumerator GetEnumerator()
		{
			return plugins.GetEnumerator();
		}


		/// <summary>
		/// Vraci plugin na danem indexu
		/// </summary>
		public PluginInfo this[int i]
		{
			get { return (PluginInfo)plugins[i]; }
		}

		#endregion
	}
}
