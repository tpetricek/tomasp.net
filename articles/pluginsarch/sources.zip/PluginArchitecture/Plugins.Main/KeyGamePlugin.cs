using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Plugins.Main
{
	/// <summary>
	/// Implementace ukazkoveho pluginu
	/// </summary>
	public class KeyGamePlugin : Plugins.Base.BaseControl
	{
		#region Standardni generovany kod

		private System.Windows.Forms.Label lblText;
		private System.Windows.Forms.TextBox txtTypeHere;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblText = new System.Windows.Forms.Label();
			this.txtTypeHere = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lblText
			// 
			this.lblText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblText.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.lblText.Location = new System.Drawing.Point(16, 16);
			this.lblText.Name = "lblText";
			this.lblText.Size = new System.Drawing.Size(288, 40);
			this.lblText.TabIndex = 0;
			this.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// txtTypeHere
			// 
			this.txtTypeHere.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtTypeHere.Location = new System.Drawing.Point(8, 152);
			this.txtTypeHere.Name = "txtTypeHere";
			this.txtTypeHere.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.txtTypeHere.Size = new System.Drawing.Size(296, 20);
			this.txtTypeHere.TabIndex = 1;
			this.txtTypeHere.Text = "";
			this.txtTypeHere.Visible = false;
			this.txtTypeHere.TextChanged += new System.EventHandler(this.txtTypeHere_TextChanged);
			// 
			// CorePlugin
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.txtTypeHere);
			this.Controls.Add(this.lblText);
			this.Name = "CorePlugin";
			this.Size = new System.Drawing.Size(320, 184);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Vytvori objekt pro hru a inicializuje nahodna cisla
		/// </summary>
		public KeyGamePlugin()
		{
			InitializeComponent();
			rnd=new Random();
		}

		/// <summary> Generator nahodnych cisel </summary>
		Random rnd;
		/// <summary> Pocet opsanych znaku </summary>
		int charsCount=0;
		
		
		/// <summary>
		/// Vraci jmeno hry
		/// </summary>
		public override string ToString()
		{
			return "Psaci hra";
		}

		/// <summary>
		/// Vraci popisku hry
		/// </summary>
		public override string Description
		{
			get { return "Rychle opisujte text, ktery se zobrazuje "+
				"v horni casti.\n(hlavne pozor na maly a velky pismena!)"; }
		}


		/// <summary>
		/// Pomocna funkce, ktera doplnuje pocet zobrazenych znaku na 10
		/// </summary>
		private void AddChars()
		{
			while(lblText.Text.Length<10)
			{
				if (rnd.Next(6)==0)
					lblText.Text+=(char)('A'+rnd.Next('z'-'a'+1));
				else
					lblText.Text+=(char)('a'+rnd.Next('z'-'a'+1));
			}
		}

		
		/// <summary>
		/// Spusti hru - zobrazi textbox na opisovani a prida znaky k opsani
		/// </summary>
		public override void Start()
		{
			charsCount=0;
			txtTypeHere.Visible=true;
			txtTypeHere.Focus();
			AddChars();
		}


		/// <summary>
		/// Zastavi hru - zkryje textbox a vrati pocet opsanych znaku
		/// </summary>
		/// <returns></returns>
		public override string Stop()
		{
			lblText.Text="";
			txtTypeHere.Visible=false;
			return "Vase skore je: "+charsCount.ToString();
		}


		/// <summary>
		/// Uzivatel napsal znak - pokud znak odpovida tak zvysi skore,
		/// posune znaky k opsani a prida znak na konec
		/// </summary>
		private void txtTypeHere_TextChanged(object sender, System.EventArgs e)
		{
			// kontrola jestli je neco napsano a jestli je znak spravny
			if (txtTypeHere.Text.Length>0&&lblText.Text.Length>0&&
				txtTypeHere.Text[0]==lblText.Text[0])
			{
				// posune text
				lblText.Text=lblText.Text.Substring(1,lblText.Text.Length-1);
				AddChars();

				// zvysi pocet opsanych znaku
				charsCount++;
			}
			txtTypeHere.Text="";
		}
	}
}
