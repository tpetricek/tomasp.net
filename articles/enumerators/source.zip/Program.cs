using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace EnumeratorDemos
{
	partial class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Ukazka prace s enumeratory");
			EnumeratorsUsage();

			Console.WriteLine("Ukazka psani vlastnich enumeratoru ");
			CustomEnumerators1();

			Console.WriteLine("Enumeratory pomoci yield return v .NET 2.0");
			CustomEnumerators2();
		}
	}
}
