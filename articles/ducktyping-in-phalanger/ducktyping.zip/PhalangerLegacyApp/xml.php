<?

function foo()
{
	$xml = simplexml_load_file("http://www.nytimes.com/services/xml/rss/nyt/HomePage.xml");
	echo $xml->rss->channel->title."\n";

	echo "Latest posts:\n";
	foreach($xml->rss->channel->item as $item) 
	{
		echo "  - ".$item->title."\n";
	}
}

//foo();
?>