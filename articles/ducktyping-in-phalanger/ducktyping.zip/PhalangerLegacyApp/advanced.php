<?

class Advanced
{
	function hello_or_pi($b) 
	{
		if ($b) return "Hello world!"; else return 3.141592;
	}

	function get_array()
	{
		return array("one", "two", "three", "four");
	}
	
	function get_keyed_array()
	{
		return array("cs" => "Ahoj svete!", "en" => "Hello world");
	}
}


?>