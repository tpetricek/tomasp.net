<?

include("objects.php");
include("advanced.php");
include("xml.php");

?>