<?

class SecondSample
{
	function __call($name, $args) 
	{
		echo "Calling unknown function '$name' with ".count($args)." arguments.\n";
	}
	
	function __get($name)
	{
		return "Reading unknown '$name' value.";
	}
}

class SampleObj
{
	public $Message = "Hello world!";
		
	function Write($arg)
	{
		echo $arg."\n";
	}
	
	function Add($a, $b)
	{
		return $a + $b;
	}
	
	function NewRandom()
	{
		return new System:::Random();
	}
	
	function NewSecond()
	{
		return new SecondSample;
	}
}

?>