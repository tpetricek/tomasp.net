using System;
using System.Collections.Generic;
using System.Text;

using PHP.Core;
using System.Collections;

namespace CSharpConsole
{
	#region ObjectsDemo

	[DuckType]
	public interface ISampleObj
	{
		void Write(string p);
		int Add(int p, int p_2);
		double Add(double p, double p_2);
		Random NewRandom();
		string Message { get; set; }
		ISecondSample NewSecond();
	}

	[DuckType]
	public interface ISecondSample
	{
		void SomeMethod(int p, int p_2, int p_3);
		string SomeProp { get; }
	}

	#endregion

	#region AdvancedDemo

	[DuckType]
	public interface IAdvanced
	{
		[DuckName("hello_or_pi")]
		string HelloOrPiString(bool b);
		[DuckName("hello_or_pi")]
		double HelloOrPiDouble(bool b);

		[DuckName("get_array")]
		IDuckEnumerable<string> GetArray();

		[DuckName("get_keyed_array")]
		IDuckKeyedEnumerable<string, string> GetKeyedArray();
	}

	#endregion

	#region XmlDemo

	[DuckType]
	public interface IRssXml
	{
		IRssRssNode rss { get; }
	}

	[DuckType]
	public interface IRssRssNode
	{
		IRssChannelNode channel { get; }
	}

	[DuckType]
	public interface IRssItemNode
	{
		string title { get; }
	}

	[DuckType]
	public interface IRssChannelNode
	{
		string title { get; }
		string link { get; }
		string description { get; }

		[DuckName("item")]
		IDuckEnumerable<IRssItemNode> items { get; }
	}

	#endregion

	class Program
	{
		static void Main(string[] args)
		{
			ScriptContext ctx = ScriptContext.CurrentContext;
			ctx.Output = Console.Out;

			Type library_representative = typeof(PhalangerLegacyApp);
			ctx.IncludeScript("main.php", library_representative);
			
			ObjectsDemo(ctx);
			AdvancedDemo(ctx);
			XmlDemo(ctx);

			Console.ReadLine();
		}

		private static void ObjectsDemo(ScriptContext ctx)
		{
			// Create instance of object 'SampleObj' declared in PHP
			ISampleObj so = ctx.NewObject<ISampleObj>("SampleObj");

			// Call write method and read property
			so.Message = "Hello from C# (via PHP)!";
			so.Write(so.Message);

			// Type conversions are provided automatically
			int r1 = so.Add(24, 18);
			Console.WriteLine("Math: 24 + 18 = {0}", r1);

			// .. calling same method with parameters of different type
			double r2 = so.Add(24.5, 17.9);
			Console.WriteLine("Math: 24.5 + 17.9 = {0}", r2);

			// Returning .NET objects from PHP
			Random rnd = so.NewRandom();
			Console.WriteLine("Random: {0}", rnd.Next(10));

			// Returning PHP objects from PHP
			// (object is wrapped using duck typing again)
			ISecondSample ss = so.NewSecond();

			// Call unknown method
			ss.SomeMethod(1, 2, 3);

			// Read unknown field
			Console.WriteLine(ss.SomeProp);
		}

		private static void AdvancedDemo(ScriptContext ctx)
		{
			// Create instance of object 'Advanced' declared in PHP
			IAdvanced adv = ctx.NewObject<IAdvanced>("Advanced");
			string s = adv.HelloOrPiString(true);
			double d = adv.HelloOrPiDouble(false);

			Console.WriteLine("Hello = '{0}', Pi = {1}", s, d);

			foreach (string val in adv.GetArray())
				Console.WriteLine(" - '{0}'", val);

			foreach (IDuckKeyValue<string, string> kv in adv.GetKeyedArray())
				Console.WriteLine(" - '{0}' => '{1}'", kv.Key, kv.Value);
		}

		private static void XmlDemo(ScriptContext ctx)
		{
			IRssXml xml = ctx.Call<IRssXml>("simplexml_load_file", "http://www.nytimes.com/services/xml/rss/nyt/HomePage.xml");
			Console.WriteLine("Title: {0}", xml.rss.channel.title);
			Console.WriteLine("Link: {0}", xml.rss.channel.link);
			Console.WriteLine("Description: {0}", xml.rss.channel.description);
			foreach (IRssItemNode item in xml.rss.channel.items)
			{
				Console.WriteLine(" - {0}", item.title);
			}
		}
	}
}
