using System;
using System.Text;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Runtime.InteropServices;

namespace WinApiInterop
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form : System.Windows.Forms.Form
	{
		#region Standard generated code

		private System.Windows.Forms.Timer tmrCheckWindow;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblTitle;
		private System.Windows.Forms.Button btnMin;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Timer tmrMinimize;
		private System.ComponentModel.IContainer components;

		public Form()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form());
		}


		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.tmrCheckWindow = new System.Windows.Forms.Timer(this.components);
			this.label1 = new System.Windows.Forms.Label();
			this.lblTitle = new System.Windows.Forms.Label();
			this.btnMin = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.tmrMinimize = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// tmrCheckWindow
			// 
			this.tmrCheckWindow.Enabled = true;
			this.tmrCheckWindow.Tick += new System.EventHandler(this.tmrCheckWindow_Tick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(168, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Titulek aktivn�ho okna je:";
			// 
			// lblTitle
			// 
			this.lblTitle.Location = new System.Drawing.Point(32, 48);
			this.lblTitle.Name = "lblTitle";
			this.lblTitle.Size = new System.Drawing.Size(248, 32);
			this.lblTitle.TabIndex = 1;
			this.lblTitle.Text = "...";
			// 
			// btnMin
			// 
			this.btnMin.Location = new System.Drawing.Point(16, 104);
			this.btnMin.Name = "btnMin";
			this.btnMin.Size = new System.Drawing.Size(96, 23);
			this.btnMin.TabIndex = 2;
			this.btnMin.Text = "Minimalizovat";
			this.btnMin.Click += new System.EventHandler(this.btnMin_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(128, 104);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(152, 32);
			this.label2.TabIndex = 3;
			this.label2.Text = "Minimalizuje okno, ktere bude za 5 sekund aktivni.";
			// 
			// tmrMinimize
			// 
			this.tmrMinimize.Interval = 5000;
			this.tmrMinimize.Tick += new System.EventHandler(this.tmrMinimize_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 142);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnMin);
			this.Controls.Add(this.lblTitle);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "WinApiInterop";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Zjistuje Handle prave aktivniho okna
		/// </summary>
		[DllImport("user32.dll")]
		static extern IntPtr GetForegroundWindow();

		/// <summary>
		/// Zobrazuje/skyrva/maximalizuje/minimalizuje okno
		/// </summary>
		/// <param name="hWnd">Handle okna</param>
		/// <param name="nShow">Co se ma s oknem udelat?</param>
		[DllImport("user32.dll")]
		static extern IntPtr ShowWindow(IntPtr hWnd,int nShow);

		/// <summary>
		/// Zjistuje text okna (Titulek)
		/// </summary>
		/// <param name="hWnd">Handle okna</param>
		/// <param name="lpString">Kam se ma titulek ulozit?</param>
		/// <param name="nMaxCount">Maximalni delka, ktera se smi ulozit do lpString</param>
		[DllImport("user32.dll")]
		static extern int GetWindowText
			(IntPtr hWnd,[Out]StringBuilder lpString,int nMaxCount);

		/// <summary> Minimalizovat okno </summary>
		private const int SW_MINIMIZE=6;
		/// <summary> Maximalizovat okno </summary>
		private const int SW_MAXIMIZE=3;

		/// <summary>
		/// Zjistuje jake okno je aktivni (a jeho titulek)
		/// </summary>
		private void tmrCheckWindow_Tick(object sender, System.EventArgs e)
		{
			IntPtr handle=GetForegroundWindow();

			StringBuilder sb=new StringBuilder(256);
			GetWindowText(handle,sb,sb.Capacity);
			lblTitle.Text=sb.ToString();
		}


		/// <summary>
		/// Spusti timer, ktery za 5 sec. minimalizuje aktivni okno
		/// </summary>
		private void btnMin_Click(object sender, System.EventArgs e)
		{
			tmrMinimize.Enabled=true;
			btnMin.Enabled=false;
		}


		/// <summary>
		/// Minimalizuje aktivni okno
		/// </summary>
		private void tmrMinimize_Tick(object sender, System.EventArgs e)
		{
			ShowWindow(GetForegroundWindow(),6);
			btnMin.Enabled=true;
			tmrMinimize.Enabled=false;
		}
	}
}
