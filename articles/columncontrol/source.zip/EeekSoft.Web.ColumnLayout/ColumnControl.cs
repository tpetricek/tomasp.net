using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

namespace EeekSoft.Web.Controls
{
	/// <summary>
	/// Specifies rendering mode, that will be used to generate code by ColumnControl
	/// <seealso cref="ColumnControl"/>
	/// </summary>
	public enum RenderMode
	{
		#region	Members

		/// <summary> This mode will generate table with fixed column width </summary>
		TableFixed,
		/// <summary> This mode will generate table with variable column width </summary>
		TableVariable,
		/// <summary> This mode will generate DIV elements with fixed column width </summary>
		DivFixed,

		#endregion
	}

	
	/// <summary>
	/// Control that automatically divides content to specified number of columns.
	/// </summary>
	[DefaultProperty("ColumnCount"),ParseChildren(false),
	 ToolboxData("<{0}:ColumnControl runat=\"server\"></{0}:ColumnControl>")]
	public class ColumnControl : System.Web.UI.WebControls.WebControl
	{
		#region Constructors

		/// <summary>
		/// Create control with default values
		/// </summary>
		public ColumnControl()
		{
			HeaderTags="h1,h2,h3,h4,h5,h6";
			PairTags="a,b,u,i,p,pre,div,span,em,strong,dfn,code,samp,kbd,var,cite,abbr,"
				+"acronym,blockquote,q,sub,sup,ins,del,s,small,tt,h1,h2,h3,h4,h5,h6";
			ParagraphTags="p,div,pre";
			ListTags="ul,ol,dl";
			ListItemTags="li,dt,dd";
			TagConstants="h1=2,h2=1.8,h3=1.5,pre=5,small=0.8";
			ElementsSizes="img=40,hr=10,br=10";
		}
		

		/// <summary>
		/// Create regular expressions
		/// </summary>
		static ColumnControl()
		{
			regComment=new Regex(@"^<!--.*?-->",RegexOptions.Singleline);
			regSect=new Regex(@"\[cc:section\s?([^\]]*)\]");
			regSpace=new Regex(@"\[cc:space\s?([^\]]*)\]");
		}

		#endregion
		#region Private fields

		// properties..
		private bool _enableFormatTags=false;
		private int _colCount=3,_minColumnsWidth=0;
		private string _headerTags,_paragraphTags,_listTags,_listItemTags,_pairTags;
		private string[] _headerTagsAr,_paragraphTagsAr,_listTagsAr,_listItemTagsAr,_pairTagsAr;
		private string _spaceChars=".?!,";
		private RenderMode _renderMode=RenderMode.DivFixed;

		// global
		private int _renderedSecs=0;
		private string  _tagConstants,_elementsSizes;
		private Hashtable _tagConstTab,_elementsSizesTab;

		// static
		private static Regex regComment,regSect,regSpace;
		
		#endregion
		#region Public properties
		

		/// <summary>
		/// If width of control is less than 'MinColumnsWidth' text will be displayed in
		/// one column.
		/// </summary>
		/// <remarks> 
		/// Set this property to 0 to disable this behavior.
		/// This feature works only when RenderMode is set to DivFixed!
		/// </remarks>
		[DefaultValue(0),Category("Column Layout"),
		 Description("Minimal allowed size of column.")]
		public int MinColumnsWidth
		{
			get { return _minColumnsWidth; }
			set { _minColumnsWidth=value; }
		}


		/// <summary>
		/// Characters that can be used to split paragraph. Default value allows paragraph
		/// to be divided only at the end of sentence.
		/// </summary>
		[DefaultValue(".?!,"),Category("Content Division"),
		 Description("Characters that can be used to divide paragraph.")]
		public string SpaceChars
		{
			get { return _spaceChars; }
			set { _spaceChars=value; }
		}


		/// <summary>
		/// This property specifies mode that will be used for generating columns.
		/// You can choose either div or table (fixed/variable width) mode.
		/// <seealso cref="RenderMode"/>
		/// </summary>
		[DefaultValue(RenderMode.DivFixed),Category("Column Layout"),
		 Description("Specifies mode that will be used for generating columns.")]
		public RenderMode RenderMode 
		{
			get {  return _renderMode; }
			set { _renderMode=value; }
		}


		/// <summary>
		/// If this property is true, text is divided into columns using special
		/// html comments that determine formating.
		/// </summary>
		/// <example>
		/// If formating tags are enabled, you can use section tag to change 
		/// column count and to define sections to be divided into columns like this:
		/// <code>
		/// this text will not be divided
		/// &lt;!--[cc:section cols=2]--&gt;
		/// .. this text will be divided into two columns
		/// &lt;!--[/cc:section]--&gt;
		/// </code>
		/// </example>
		[DefaultValue(false),Category("Content Division"),
		 Description("Are formating tags enabled?")]
		public bool EnableFormatTags
		{
			get { return _enableFormatTags; }
			set { _enableFormatTags=value; }
		}


		/// <summary>
		/// This property can be used to specify which elements contains
		/// large or small text.
		/// </summary>
		/// <remarks>
		/// If you expect that text contains pre elements and content of this
		/// elements will take more space than content of other elements,
		/// you can set TagConstants to "pre=2" and control will calculate one
		/// character inside pre tag as 2 characters.
		/// </remarks>
		/// <example><code>
		/// TagConstants="pre=1.5,h1=4.1,small=0.8";
		/// </code></example>
		[DefaultValue("h1=2,h2=1.8,h3=1.5,pre=5,small=0.8"),Category("Content Division"),
		 Description("Expected size of text in elements")]
		public string TagConstants
		{
			get { return _tagConstants; }
			set {
				_tagConstants=value; 
				if (_tagConstants==null) _tagConstants="";
			}
		}


		/// <summary>
		/// This property can be used to define additional size of elements.
		/// </summary>
		/// <remarks>
		/// If you expect that images size is equal to size of paragraph with 40 
		/// characters, you can set this property to "img=40"
		/// </remarks>
		[DefaultValue("img=40,hr=10,br=10"),Category("Content Division"),
		Description("Expected size of elements")]
		public string ElementsSizes
		{
			get { return _elementsSizes; }
			set 
			{
				_elementsSizes=value; 
				if (_elementsSizes==null) _elementsSizes="";

				_elementsSizesTab=new Hashtable();
				string[] parts=_elementsSizes.Split(';',' ',',','\t');
				foreach(string part in parts)
				{
					string[] keyval=part.Split('=');
					if (keyval[0]==""||keyval[0]==null) continue;
					try
					{
						_elementsSizesTab.Add(keyval[0],Single.Parse(keyval[1],
							System.Globalization.CultureInfo.InvariantCulture));
					} 
					catch {}
				}
			}
		}


		/// <summary>
		/// Tags that are handled as headers - This means that control will 
		/// never split content of this tag into multiple columns (and tag 
		/// will be moved to beginning of next column)
		/// </summary>
		[DefaultValue("h1,h2,h3,h4,h5,h6"),Category("Content Division"),
		 Description("Tags that are handled as headers")]
		public string HeaderTags
		{
			get { return _headerTags; }
			set { 
				_headerTags=value; 
				if (_headerTags==null) _headerTags="";
				_headerTagsAr=_headerTags.Split(',',';',' ','\t');
			}
		}


		/// <summary>
		/// Tags that are handled as paragraphs - This means that if content of this tag
		/// is to long it can be split to multiple columns. Copy of starting tag will be 
		/// added to the beginning of next column.
		/// </summary>
		[DefaultValue("p,div,pre"),Category("Content Division"),
		 Description("Tags that are handled as paragraphs")]
		public string ParagraphTags
		{
			get { return _paragraphTags; }
			set { 
				_paragraphTags=value; 
				if (_paragraphTags==null) _paragraphTags="";
				_paragraphTagsAr=_paragraphTags.Split(',',';',' ','\t');
			}
		}


		/// <summary>
		/// Tags that are handled as lists - if this control contains list items
		/// it can be split, but only whole list items can be moved to another column. 
		/// <seealso cref="ListItemTags"/>
		/// </summary>
		[DefaultValue("ol,ul,dl"),Category("Content Division"),
		Description("Tags that are handled as lists")]		
		public string ListTags
		{
			get { return _listTags; }
			set { 
				_listTags=value; 
				if (_listTags==null) _listTags="";
				_listTagsAr=_listTags.Split(',',';',' ','\t');
			}
		}


		/// <summary>
		/// Tags that are handled as list items - this elements can't be split, but
		/// can be moved to another column when contained in list tag. 
		/// <seealso cref="ListTags"/>
		/// </summary>
		[DefaultValue("li,dt,dd"),Category("Content Division"),
		Description("Tags that are handled as lists")]		
		public string ListItemTags
		{
			get { return _listItemTags; }
			set { 
				_listItemTags=value; 
				if (_listItemTags==null) _listItemTags="";
				_listItemTagsAr=_listItemTags.Split(',',';',' ','\t');
			}
		}

		
		/// <summary>
		/// Pair tags - list of all supported pair tags that can appear in text
		/// </summary>
		[DefaultValue("a,b,u,i,p,pre,div,span,em,strong,dfn,code,samp,kbd,var,cite,abbr,"
			 +"acronym,blockquote,q,sub,sup,ins,del,s,small,tt,h1,h2,h3,h4,h5,h6"),
		 Category("Content Division"),
		 Description("List of all pair tags that can appear in text")]		
		public string PairTags
		{
			get { return _pairTags; }
			set 
			{ 
				_pairTags=value; 
				if (_pairTags==null) _pairTags="";
				_pairTagsAr=_pairTags.Split(',',';',' ','\t');
			}
		}


		/// <summary>
		/// Tags that are handled as list items - this elements can't be split, but
		/// can be moved to another column when contained in list tag. 
		/// <seealso cref="ListTags"/>
		/// </summary>
		[DefaultValue(3),Category("Column Layout"),
		Description("Number of columns where the text will be divided.")]
		public int ColumnCount
		{
			get { return _colCount; }
			set { _colCount=value; }
		}


		#endregion
		
		#region Private - Classes
		
		/// <summary>
		/// Class for storing tag information in stack (during processing)
		/// </summary>
		class Tag
		{
			#region Members

			/// <summary>
			/// Create info about tag
			/// </summary>
			/// <param name="cc">Control</param>
			/// <param name="tagHtml">Tags html code</param>
			public Tag(ColumnControl cc,string tagHtml)
			{
				FullTag=tagHtml;
				IsEnd=tagHtml.StartsWith("/");
				if (IsEnd) tagHtml=tagHtml.Substring(1);
				
				int i=0; 
				StringBuilder tmp=new StringBuilder(5);
				while(i!=tagHtml.Length&&tagHtml[i]!=' ') 
					tmp.Append(tagHtml[i++]); 
				Name=tmp.ToString();

				// what kind of tag is it??
				foreach(string t in cc._pairTagsAr) 
					if (string.Compare(Name,t,true)==0) { IsPair=true; break; }

				foreach(string t in cc._headerTagsAr) 
					if (string.Compare(Name,t,true)==0) { IsHeader=true; return; }
				foreach(string t in cc._paragraphTagsAr) 
					if (string.Compare(Name,t,true)==0) { IsParagraph=true; return; }
				foreach(string t in cc._listItemTagsAr) 
					if (string.Compare(Name,t,true)==0) { IsListItem=true; return; }
				foreach(string t in cc._listTagsAr) 
					if (string.Compare(Name,t,true)==0) { IsList=true; return; }
				IsUndefined=true;
			}


			/// <summary>
			/// Returns string representation of this object
			/// </summary>
			public override string ToString()
			{
				string tp=IsHeader?"h":(IsParagraph?"p":(IsListItem?"li":(IsList?"l":"")));
				return string.Format("[{2}{0} : {1}]",Name,tp,IsEnd?"/":"");
			}


			// properties
			public string Name;
			public string FullTag;
			public bool IsEnd,IsPair=false,IsList=false,IsListItem=false,
				IsParagraph=false,IsHeader=false,IsUndefined=false;

			#endregion
		}

		#endregion
		#region Private - Utility methods

		/// <summary>
		/// Is current browser IE 6 or better :) ?
		/// </summary>
		private bool IE6
		{
			get 
			{
				return (HttpContext.Current.Request.Browser.Browser=="IE"&&
							HttpContext.Current.Request.Browser.MajorVersion>=6); 
			}
		}


		/// <summary>
		/// Initialize hashtable with tag size constants
		/// </summary>
		private void InitConstTab()
		{
			_tagConstTab=new Hashtable();
			string[] parts=TagConstants.Split(';',' ',',','\t');
			foreach(string part in parts)
			{
				string[] keyval=part.Split('=');
				if (!IsKnownTag(keyval[0])) continue;
				try
				{
					_tagConstTab.Add(keyval[0],Single.Parse(keyval[1],
						System.Globalization.CultureInfo.InvariantCulture));
				} catch {}
			}
		}


		/// <summary>
		/// Returns multiplier constant for specified tag
		/// </summary>
		/// <param name="tag">Tag</param>
		/// <returns>Constant</returns>
		private float GetSizeConstant(string tag)
		{
			if (_tagConstTab==null) InitConstTab();
			if (!_tagConstTab.ContainsKey(tag)) return 1;
				else return (float)_tagConstTab[tag];
		}


		/// <summary>
		/// Returns number of characters that take same space as specified tag
		/// (usefull for non-pair tags like IMG)
		/// </summary>
		/// <param name="tag">Tag</param>
		/// <returns>Number of characters</returns>
		private float GetElementSize(string tag)
		{
			if (!_elementsSizesTab.ContainsKey(tag)) return 0;
			else return (float)_elementsSizesTab[tag];
		}


		/// <summary>
		/// Checks if specified tag is known tag
		/// </summary>
		/// <param name="tag">Tag</param>
		/// <returns></returns>
		private bool IsKnownTag(string tag)
		{
			foreach(string t in _pairTagsAr) if (string.Compare(tag,t,true)==0) return true;
			foreach(string t in _paragraphTagsAr) if (string.Compare(tag,t,true)==0) return true;
			foreach(string t in _listItemTagsAr) if (string.Compare(tag,t,true)==0) return true;
			foreach(string t in _listTagsAr) if (string.Compare(tag,t,true)==0) return true;
			foreach(string t in _headerTagsAr) if (string.Compare(tag,t,true)==0) return true;
			return false;
		}


		/// <summary>
		/// Calculates size of whole html content 
		/// (this method is similar to Split, but it contains only code 
		/// needed to calculate content length)
		/// </summary>
		/// <param name="html">Html</param>
		/// <returns>Size (+/-) of content in characters</returns>
		private float ContentLength(string html)
		{
			int i=0;
			float sizeConst=1,ret=0;
			ArrayList listTags=new ArrayList();
			
			while(i<html.Length)
			{
				/****** PARSE TAG ******/
				char c=html[i];
				if (html[i]=='<') 
				{
					// special command
					Match m=regComment.Match(html.Substring(i));
					if (m.Success)
					{
						string tt=m.Value.Substring(4,m.Value.Length-7);
						Match mSpace=regSpace.Match(tt);
						if (mSpace.Success)
						{
							string[] p=mSpace.Groups[1].Value.Trim().Split('=');
							if (p.Length>1&&p[0]=="size")
							{	
								try 
								{ 
									int size=Int32.Parse(p[1]); 
									ret+=size;
								} 
								catch {}
							}
						}
						i+=m.Value.Length;
					}
					else
					{
						// HTML tag
						int j=i;
						Tag tag=new Tag(this,ReadTag(html,ref i));
						ret+=GetElementSize(tag.Name);
					
						if (tag.IsEnd&&(!tag.IsUndefined||tag.IsPair))
						{
							if (listTags.Count>0)
								listTags.RemoveAt(listTags.Count-1);
						}
						if (!tag.IsEnd&&(!tag.IsUndefined||tag.IsPair))
						{
							listTags.Add(tag);
						}
						sizeConst=1;
						foreach(Tag tmp in listTags)
							sizeConst*=GetSizeConstant(tmp.Name);
					}
				}


				/****** PROCESS CONTENT ******/
				if (i<html.Length&&html[i]!='<')
				{
					i++; ret+=sizeConst;
				}
			}		
			return ret;
		}



		/// <summary>
		/// Reads tag from input html at specified position
		/// </summary>
		/// <param name="html">Html content</param>
		/// <param name="index">Index where to read</param>
		/// <returns>Returns readen html tag</returns>
		private string ReadTag(string html,ref int index)
		{
			int s=index,i=index+1;
			while(i!=html.Length&&html[i]!='>') i++;
			index=i+1;

			return html.Substring(s+1,i-s-1);
		}


		#endregion
		#region Private - Rendering
		
		/// <summary>
		/// Possible states used by SplitToCols
		/// </summary>
		private enum ProcessingState 
		{ 
			#region Members
			
			/// <summary> Nothing.. just processing </summary>
			None, 
			/// <summary> Break in paragraph - wait for space </summary>
			WaitForSpace, 
			/// <summary> Break in list - wait for space between items </summary>
			WaitForListSpace, 
			/// <summary> Break in header - wait for empty stack </summary>
			WaitForHeaderEnd, 

			#endregion
		};


		/// <summary>
		/// Split html to columns (#ColumnCount)
		/// </summary>
		/// <param name="html">Input html</param>
		/// <returns>Array with columns</returns>
		private StringBuilder[] SplitToCols(string html)
		{
			return SplitToCols(html,ColumnCount);
		}


		/// <summary>
		/// Splits html into specified number of columns (using all control settings)
		/// </summary>
		/// <param name="html">Input html</param>
		/// <param name="colCount">Number of columns</param>
		/// <returns>Array with columns</returns>
		private StringBuilder[] SplitToCols(string html,int colCount)
		{
			float contLength=ContentLength(html);
			int partLength=(int)(contLength/colCount);

			// will be used as tag stack
			ArrayList listTags=new ArrayList();
			// array of stribuilders to return
			StringBuilder[] ret=new StringBuilder[colCount];
			for(int j=0; j<colCount; j++)
				ret[j]=new StringBuilder(html.Length/colCount);
			int columnIndex=0;

			int i=0,headerStart=0;
			float contentCount=0,sizeConst=1;
			string insertBeginning="",insertEnd="";
			ProcessingState state=ProcessingState.None;
			char lastChar=(char)0;
      bool tagJustEnded=false;

			while(i<html.Length)
			{
				char c=html[i];

				//****** PARSE TAG / COMMENT WITH COMMAND *******//
				if (html[i]=='<')
				{
					Match m=regComment.Match(html.Substring(i));
					if (m.Success)
					{
						// comment with command?
						string tt=m.Value.Substring(4,m.Value.Length-7);
						Match mSpace=regSpace.Match(tt);
						if (mSpace.Success)
						{
							string[] p=mSpace.Groups[1].Value.Trim().Split('=');
							if (p.Length>1&&p[0]=="size")
							{	
								try 
								{ 
									int size=Int32.Parse(p[1]); 
									contentCount+=size;
								} 
								catch {}
							}
						}
						i+=m.Value.Length;
					}
					else
					{
						// html tag
						int j=ret[columnIndex].Length;
						Tag tag=new Tag(this,ReadTag(html,ref i));
						contentCount+=GetElementSize(tag.Name);
						ret[columnIndex].Append("<"+tag.FullTag+">");

						if (tag.IsEnd&&(!tag.IsUndefined||tag.IsPair))
						{
							// process end tag
							if (listTags.Count>0)
								listTags.RemoveAt(listTags.Count-1);
							tagJustEnded=true;
						}
						if (!tag.IsEnd&&(!tag.IsUndefined||tag.IsPair))
						{
							// add start tag
							if (tag.IsHeader) headerStart=j;
							listTags.Add(tag);
						}
						sizeConst=1;
						foreach(Tag tmp in listTags)
							sizeConst*=GetSizeConstant(tmp.Name);
					}
				}



				//****** END OF COLUMN? - set state to split column ASAP *******//
				if (contentCount>=partLength&&listTags.Count<=2)
				{
					Tag lastTag=listTags.Count==0?null:(Tag)listTags[listTags.Count-1];
					if (listTags.Count==0)          // literal content - split as paragraph
					{
						state=ProcessingState.WaitForSpace;
						insertBeginning=""; insertEnd="";
						contentCount=0;
					}
					else if (listTags.Count==1&&lastTag.IsParagraph) // split paragraph
					{
						state=ProcessingState.WaitForSpace;
						insertBeginning="<"+lastTag.FullTag+">";
						insertEnd="</"+lastTag.Name+">";
						contentCount=0;
					}
					else if (listTags.Count==1&&lastTag.IsHeader)     // split header
					{
						state=ProcessingState.WaitForHeaderEnd;
						insertBeginning=""; insertEnd="";
						contentCount=0;
					}
					else if (listTags.Count==2&&lastTag.IsListItem) // split list 
					{
						Tag list=(Tag)listTags[0];
						if (!list.IsList) continue;

						state=ProcessingState.WaitForListSpace;
						insertBeginning="<"+list.FullTag+">";
						insertEnd="</"+list.Name+">";
						contentCount=0;
					} 
						// else wait for another tag
				}


				//****** CAN WE SPLIT HTML NOW? *******//
				bool breakNow=false;
				if (state==ProcessingState.WaitForHeaderEnd&&listTags.Count==0) breakNow=true;
				if (state==ProcessingState.WaitForSpace&&
					(tagJustEnded||SpaceChars.IndexOf(lastChar)!=-1
					 ||(i<html.Length&&html[i]=='<')||(i+1<html.Length&&html[i+1]=='<') )) breakNow=true;
				if (state==ProcessingState.WaitForListSpace&&listTags.Count==1) breakNow=true;

				if (breakNow)
				{
					// split now:-)
					if (state==ProcessingState.WaitForHeaderEnd)
					{
						insertBeginning=ret[columnIndex].ToString().Remove(0,headerStart);
						ret[columnIndex].Remove(headerStart,ret[columnIndex].Length-headerStart);
					}

					ret[columnIndex].Append(insertEnd);
					if (columnIndex+1<ret.Length) columnIndex++;
					ret[columnIndex].Append(insertBeginning);
					state=ProcessingState.None;
				}
				lastChar=c;


				//****** PROCESS CONTENT... *******//
				if (i<html.Length&&html[i]!='<') 
				{
					ret[columnIndex].Append(html[i]); 
					i++; contentCount+=sizeConst;
					if (tagJustEnded) tagJustEnded=false;
				}
				
			}
			return ret;
		}


		/// <summary>
		/// Render columns using current rendermode
		/// </summary>
		/// <param name="output">Output html writer</param>
		/// <param name="cols">Columns to be rendered</param>
		private void RenderCols(HtmlTextWriter output,StringBuilder[] cols)
		{
			int colCount=cols.Length;
			string ctrlId=string.Format("{0}_sec{1}",ClientID,_renderedSecs);

			if (!IE6&&MinColumnsWidth!=0)
			{
				output.Write("<script type=\"text/javascript\">add_colctrl_resizehandler("+
					"'{0}',{1},'{2}%','{3}%');</script>",ctrlId,MinColumnsWidth,100/colCount,
					100-(100/colCount)*(colCount-1));
			}

			if (RenderMode==RenderMode.DivFixed)
				output.Write("<div id=\"{0}\">",ctrlId);
			else
				output.Write("<table><tr>");

			for(int i=0; i<colCount; i++)
			{
				StringBuilder sb=cols[i];
				switch(RenderMode)
				{
					case RenderMode.DivFixed:
						// render div with float:left;
						output.Write("<div id=\"{1}_{2}\" class=\"cc_col\" style=\"float:left;"+
							"width:{0}%;",100/colCount,ctrlId,i);
						
						if (IE6&&MinColumnsWidth!=0)
							output.Write("width:expression(document.getElementById('{2}')."+
								"offsetWidth&lt;{1}?'100%':'{0}%');",i==colCount-1?
								(100-(100/colCount)*(colCount-1)):(100/colCount),
								MinColumnsWidth,ctrlId);

						output.Write("\"><div class=\"cc_cont {0}\">",i==colCount-1?"cc_last":"");
						break;

					case RenderMode.TableFixed:
						// table with fixed width
						output.Write("<td class=\"cc_col\" valign=\"top\" width=\"{0}%\">",
							100/colCount);
						break;

					case RenderMode.TableVariable:
						// table with automatic width
						output.Write("<td class=\"cc_col\" valign=\"top\">");
						break;
				}

				output.Write(sb.ToString());

				if (RenderMode==RenderMode.DivFixed)
					output.Write("</div></div>");
				else
					output.Write("</td>");
			}
			if (RenderMode==RenderMode.DivFixed)
				output.Write("</div><div style=\"clear:both;\"></div>");
			else
				output.Write("</tr></table>");
			_renderedSecs++;
		}


		/// <summary>
		/// Render content using comment tags
		/// </summary>
		/// <param name="output">Output html</param>
		/// <param name="tmp">Input (rendered content)</param>
		private void RenderFormatedCols(HtmlTextWriter output,string tmp)
		{
			bool splitting=false,nSplitting=false;
			int i=0,lastEnd=0;
			int overrideCols=ColumnCount;

			while(i<tmp.Length)
			{
				while(i<tmp.Length)
				{
					// tag?
					if (i+3<tmp.Length&&tmp[i]=='<'&&tmp[i+1]=='!'&&tmp[i+2]=='-'&&tmp[i+3]=='-')
					{
						int j=i; 
						while(j+2<tmp.Length&&!(tmp[j]=='-'&&tmp[j+1]=='-'&&tmp[j+2]=='>')) j++;
            string tag=tmp.ToString().Substring(i+4,j-i-4);

						Match m;
						if (tag=="[/cc:section]")
							// end of splitting
							nSplitting=false; 
						else if ((m=regSect.Match(tag)).Success)
						{
							// start splitting - get cols count
							nSplitting=true;
							overrideCols=ColumnCount;

							string[] p=m.Groups[1].Value.Trim().Split('=');
							if (p.Length>1&&p[0]=="cols")
							{	
								try { overrideCols=Int32.Parse(p[1]); } catch {}
							}
						}
						else { i++; continue; }

						i=j+3;
						break;
					}
					i++;
				}

				// Render columns or not divided section
				string lastSect=tmp.ToString().Substring(lastEnd,i-lastEnd);
				if (!splitting)
					output.Write(lastSect);
				else
					RenderCols(output,SplitToCols(lastSect,overrideCols));

				lastEnd=i;
				splitting=nSplitting;
			}
		}


		#endregion
		#region Overriden


		/// <summary>
		/// Render control
		/// </summary>
		/// <param name="output">Output html writer</param>
		protected override void Render(HtmlTextWriter output)
		{
			StringBuilder tmp=new StringBuilder();
			base.Render(new HtmlTextWriter(new StringWriter(tmp)));

			// Asp.net adds span element bounding whole literal content
			string html=tmp.ToString();
			foreach(string startTag in new string[] {"<span>","<span id=\""+ClientID.ToLower()+"\">"})
			{
				if (html.ToLower().StartsWith(startTag)&&html.EndsWith("</span>"))
				{
					html=html.Substring(startTag.Length,html.Length-startTag.Length-7);
					break;
				}
			}

			if (!EnableFormatTags)
				// split whole content to columns
				RenderCols(output,SplitToCols(html));
			else
				// sections to be divided are determined using <!--[cc:section]-->
				RenderFormatedCols(output,html);
		}


		/// <summary>
		/// If browser is not IE we need to register javascript code for 'ColumnMinWidth' 
		/// </summary>
		protected override void OnLoad(EventArgs e)
		{
			if (MinColumnsWidth!=0&&RenderMode==RenderMode.DivFixed&&!IE6&&
				!Page.IsClientScriptBlockRegistered("columncontrol-mozscript"))
			{
				using(StreamReader sr=new StreamReader
					(System.Reflection.Assembly.GetExecutingAssembly().
						GetManifestResourceStream("EeekSoft.Web.Controls.mozscript.js")))
				{
					Page.RegisterClientScriptBlock("columncontrol-mozscript",
						"<script type=\"text/javascript\">\n"+
						"//<![CDATA[\n"+
						sr.ReadToEnd()
						+"\n//]]>\n</script>");
				}
			}
			base.OnLoad(e);
		}

		#endregion
	}
}
