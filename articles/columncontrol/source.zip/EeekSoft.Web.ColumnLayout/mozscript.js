var oldres=window.onresize,oldload=window.onload,ctrllist=new Array();

function win_resize()
{
  if (oldres!=null) oldres();
	for(ctrli=0; ctrli<ctrllist.length; ctrli++)
	{
		var el=document.getElementById(ctrllist[ctrli].id);
		var i=0;
		while(true)
		{
			var col=document.getElementById(ctrllist[ctrli].id+'_'+(i));
			var next=document.getElementById(ctrllist[ctrli].id+'_'+(i+1));
			if (col==null) break;
			col.style.width=el.clientWidth<ctrllist[ctrli].min?'100%':(next==null?ctrllist[ctrli].lastcol:ctrllist[ctrli].col);
			i++;
		}
	}
}

function win_load()
{
	if (oldload!=null) oldload();
  win_resize();
}

function add_colctrl_resizehandler(id,min,col,lastcol)
{
	var o=new Object();
	o.id=id; o.col=col; o.lastcol=lastcol; o.min=min;
  ctrllist[ctrllist.length]=o;
}

window.onresize=win_resize;
window.onload=win_load;
