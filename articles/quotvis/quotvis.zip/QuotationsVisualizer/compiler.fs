open System
open System.IO
open System.Reflection
open System.Diagnostics
open System.Configuration
open System.Windows.Forms;;
open Microsoft.FSharp
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw;;

(*---------------------------------------------------------------------------*)
let compileExpr (x:string) =
	// Generate source file
	let fsName = Path.GetTempFileName() in
	let fw = new StreamWriter(fsName^".fs") in 
	fw.WriteLine "
		module RuntimeQuot\n
		open System\n
		open System.Windows.Forms\n
		open Microsoft.FSharp\n
		open Microsoft.FSharp.Idioms\n
		open Microsoft.FSharp.MLLib\n
		open Microsoft.FSharp.Quotations\n
		open Microsoft.FSharp.Quotations.Raw;;\n";
	fw.WriteLine x;
	fw.Close();
	
	// Run F# compiler...
	let psi = new ProcessStartInfo() in 
	psi.FileName <- ConfigurationSettings.AppSettings.Item("fsc_path");
	psi.Arguments <- " -a -o \""^fsName^".dll\" \""^fsName^".fs\"";
	psi.CreateNoWindow <- true;
	psi.UseShellExecute <- false;
	psi.RedirectStandardError <- true;
	let p = Process.Start(psi) in
	let result = p.StandardError.ReadToEnd() in
	p.WaitForExit();
	File.Delete (fsName);
	File.Delete (fsName^".fs");
	
	if ((result.Trim()).Length > 0) then begin
		
		// Compilation failed?
		ignore(MessageBox.Show (result,"Compilation error"));
		None;
		
	end else begin	
		
		// Get value of field with name 'q' using reflection..
		let a = Assembly.LoadFile(fsName^".dll") in
		let t = a.GetType("RuntimeQuot") in
		let field = t.GetField("q") in
		let o = field.GetValue(null) in	
		Some(o :?> expr);
		
	end;;
	