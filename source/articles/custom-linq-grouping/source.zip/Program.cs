﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace GroupOrderDemo
{
  // ----------------------------------------------------------------------------------
  // Some necessary classes & interfaces

  interface IAdjacentGrouping<T> : IEnumerable<T> { } 

  class WrappedAdjacentGrouping<T> : IAdjacentGrouping<T> { 
    public IEnumerable<T> Wrapped { get; set; } 
    public IEnumerator<T> GetEnumerator() {  
      return Wrapped.GetEnumerator();  
    } 
    IEnumerator IEnumerable.GetEnumerator() {
      return (IEnumerator)GetEnumerator();
    } 
  }

  class Grouping<K, T> : IGrouping<K, T>
  {
    public K Key { get; set; }
    public IEnumerable<T> Elements;

    public IEnumerator<T> GetEnumerator() {
      return Elements.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator() {
      return (IEnumerator)GetEnumerator();
    }
  }

  // ----------------------------------------------------------------------------------
  // Extnesion methods for converting type and custom GroupBy implementation

  static class MovingExtensions {  
    public static IAdjacentGrouping<T> WithAdjacentGrouping<T>(this IEnumerable<T> e) { 
      return new WrappedAdjacentGrouping<T> { Wrapped = e }; 
    } 
   
    public static IEnumerable<IGrouping<K, T>> GroupBy<T, K>(this IAdjacentGrouping<T> source,  
         Func<T, K> keySelector) where K : IComparable { 
      // Remembers elements of the current group
      List<T> elementsSoFar = new List<T>(); 
      IEnumerator<T> en = source.GetEnumerator(); 
      if (en.MoveNext()) { 
        K lastKey = keySelector(en.Current); 
        do {  
          // Test whether current element starts a new group
          K newKey = keySelector(en.Current); 
          if (newKey.CompareTo(lastKey) != 0) {  
            // Yield the previous group and start next one
            yield return new Grouping<K, T> { Elements = elementsSoFar, Key = lastKey };
            lastKey = newKey;
            elementsSoFar = new List<T>(); 
          } 
          // Add element to the current group
          elementsSoFar.Add(en.Current); 
        } while (en.MoveNext()); 
        // Yield the last group of sequence
        yield return new Grouping<K, T> { Elements = elementsSoFar, Key = lastKey }; 
      }
    } 
  }

  class TradeInfo
  {
    public double Price { get; set; }
    public string Name { get; set; }
  }

  class Program
  {
    // ----------------------------------------------------------------------------------
    // Generating sequence of prime numbers

    static bool IsPrime(long n)
    {
      long max = (long)Math.Sqrt(n);
      for (long i = 2; i <= max; i++)
        if (n % i == 0) return false;
      return true;
    }

    static IEnumerable<long> Primes()
    {
      for (long n = 0; true; n++)
        if (IsPrime(n)) yield return n;
    }
    
    // ----------------------------------------------------------------------------------
    // Examples

    static void Main(string[] args)
    {
      // Grouping trade information
      var trades =
        new List<TradeInfo> { new TradeInfo { Name = "MSFT", Price = 80.00 },
                              new TradeInfo { Name = "MSFT", Price = 70.00 },
                              new TradeInfo { Name = "GOOG", Price = 100.00 },
                              new TradeInfo { Name = "GOOG", Price = 200.00 },
                              new TradeInfo { Name = "GOOG", Price = 300.00 },
                              new TradeInfo { Name = "MSFT", Price = 30.00 },
                              new TradeInfo { Name = "MSFT", Price = 20.00 } };

      var groups =
        from t in trades.WithAdjacentGrouping()
        group t by t.Name into g
        select new {
          Name = g.Key,
          Count = g.Count(),
          AvgPrice = g.Average(t => t.Price) };

      foreach (var g in groups)
        Console.WriteLine(g);
      

      // Grouping prime numbers
      var primeGroups =
        from n in Primes().WithAdjacentGrouping()
        group n by (n / 100000) into g
        select g.Count();

      foreach (var g in primeGroups.Take(10))
        Console.WriteLine(g);
    }
  }
}
