using System;
using System.Drawing;

namespace ScreensaverSample
{
	/// <summary>
	/// Abstraktni trida Cervik, ktera obsahuje kresleni cervika
	/// Zdedene tridy musi implementovat zmenu pozice a barvy
	/// </summary>
	public abstract class Cervik
	{
		#region Static

		/// <summary> Objekt na generovani nahodnych cisel </summary>
		public static Random RndGen;

		/// <summary> Inicializace statickych clenu </summary>
		static Cervik()
		{
			RndGen=new Random();
		}

		#endregion
		#region Properties

		// Vlastnosti cervika, ktere muze menit jeho potomek

		/// <summary> Pozice </summary>
		protected Point Position;
		/// <summary> Velikost </summary>
		protected Size Size;
		/// <summary> Aktualni barva </summary>
		protected Color CurrentColor;

		#endregion

		/// <summary>
		/// Konstruktor, ktery nastavuje vychozi bod
		/// </summary>
		public Cervik(int x,int y)
		{
			Position=new Point(x,y);
			Size=new Size(20,20);
		}

		/// <summary>
		/// Meni pozici (a velikost) cervika -
		///		tato metoda musi byt implementovana v odvozene tride
		/// </summary>
		/// <param name="width">Sirka okna</param>
		/// <param name="height">Vyska okna</param>
		protected abstract void ChangePosAndSize(int width,int height);

		/// <summary>
		/// Meni barvu cervika - 
		///		tato metoda musi byt implementovana v odvozene tride
		/// </summary>
		protected abstract void ChangeColor();

		/// <summary>
		/// Kresli cervika a zavola virtualni metody 
		/// na posunuti a zmenu barvy
		/// </summary>
		/// <param name="gr">Kam se ma vykreslit?</param>
		/// <param name="width">Sirka okna</param>
		/// <param name="height">Vyska okna</param>
		public void DrawFrame(Graphics gr,int width,int height)
		{
			// kresli na aktualni pozici pomoci aktualni barvy
			using(Brush br=new SolidBrush(CurrentColor))
				gr.FillEllipse(br,Position.X-Size.Width/2,
					Position.Y-Size.Height/2,Size.Width,Size.Height);

			// zmenit pozicic a barvu
			ChangePosAndSize(width,height);
			ChangeColor();
		}
	}

}
