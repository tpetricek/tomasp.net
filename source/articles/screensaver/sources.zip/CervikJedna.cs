using System;
using System.Drawing;

namespace ScreensaverSample
{
	/// <summary>
	/// Prvni cervik - 
	///		odrazi se od sten a meni plynule svou barvu
	/// </summary>
	/// <remarks>
	/// Funguje tak, ze si uklada rychlost (vertikalni a horizontalni)
	/// a v kazdem kroku se posune o dany pocet bodu. Pokud narazi 
	/// do zdi tak se odrazi nahodnym smerem
	/// </remarks>
	public class CervikJedna : Cervik
	{
		#region Constructor

		/// <summary>
		/// Inicializuje cervika
		/// </summary>
		public CervikJedna(int x,int y) : base(x,y)
		{
			newColor=CurrentColor;
			ChangeSpeed(0,0);
			CurrentColor=Color.FromArgb(RndGen.Next(256),0,RndGen.Next(256));
		}

		#endregion

		#region Posouvani cervika

		// rychlost
		int speedX,speedY;

		/// <summary>
		/// Meni rychlost cervika
		/// </summary>
		/// <param name="xDir">Jaka se smi zvolit x-ova rychlost</param>
		/// <param name="yDir">Jaka se smi zvolit y-ova rychlost</param>
		/// <remarks>Parametry mohou nabyvat hodnot -1,0,1.
		///		 0 znamena ze se muze zvolit libovolna rychlost
		///		 1 znamena ze musi byt kladna
		///		-1 znamena ze musi byt zaporna
		///	</remarks>
		private void ChangeSpeed(int xDir,int yDir)
		{
			speedX=RndGen.Next(8)+2;
			speedY=RndGen.Next(8)+2;
			if (xDir!=0) speedX=xDir*speedX;
			if (yDir!=0) speedY=yDir*speedY;
			if (xDir==0&&RndGen.Next(2)==0) speedX=-speedX;
			if (yDir==0&&RndGen.Next(2)==0) speedY=-speedY;
		}

		/// <summary>
		/// Posouva cervika (pretizena metoda bazove tridy)
		/// </summary>
		/// <param name="width">Sirka okna</param>
		/// <param name="height">Vyska okna</param>
		protected override void ChangePosAndSize(int width,int height)
		{
			// posouva
			Position.X+=speedX;
			Position.Y+=speedY;

			// kontroluje odraz od zdi
			if (Position.X<0) ChangeSpeed(1,0);
			if (Position.X>width) ChangeSpeed(-1,0);
			if (Position.Y<0) ChangeSpeed(0,1);
			if (Position.Y>height) ChangeSpeed(0,-1);
		}

		#endregion
		#region Zmena barvy cervika

		// nahodne zvolena barva
		// barva cervika se postupne meni a az se 
		// rovna teto tak se zvoli nova "newColor"
		Color newColor;

		/// <summary>
		/// Postupne meni barvu cervika (pretizena metoda)
		/// </summary>
		protected override void ChangeColor()
		{
			// test jestli se nerovnaji (meni se pouze cervena a modra slozka)
			if (CurrentColor.R==newColor.R&&CurrentColor.B==newColor.B)
				newColor=Color.FromArgb(RndGen.Next(256),0,RndGen.Next(256));

			// plynula zmena barvy
			if (newColor.R<CurrentColor.R) CurrentColor=Color.FromArgb(CurrentColor.R-1,0,CurrentColor.B);
			if (newColor.B<CurrentColor.B) CurrentColor=Color.FromArgb(CurrentColor.R,0,CurrentColor.B-1);
			if (newColor.R>CurrentColor.R) CurrentColor=Color.FromArgb(CurrentColor.R+1,0,CurrentColor.B);
			if (newColor.B>CurrentColor.B) CurrentColor=Color.FromArgb(CurrentColor.R,0,CurrentColor.B+1);
		}

		#endregion
	}
}
