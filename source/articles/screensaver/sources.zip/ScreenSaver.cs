using System;
using System.Windows.Forms;

namespace ScreensaverSample
{
	/// <summary>
	/// Objekt ktery obsahuje metodu Main a spousti sporic
	/// </summary>
	public class ScreenSaver
	{
		/// <summary>
		/// Podle parametru z prikazove radky pozna zda se ma spustit
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
		{
			if (args.Length>0)
			{
				// Parametr /c znamena nastaveni screensaveru
				if (args[0].StartsWith("/c"))
				{
					MessageBox.Show("Tento spo�i� obrazovky nem� ��dn� nastaven�.");
					return;
				}
				// Parametr /p znamena nahled - neni podporovano
				if (args[0].StartsWith("/p")) return;					
			}

			// Spusti screensaver
			SaverForm sf=new SaverForm();
			sf.Show();
			while(sf.Created)
			{
				// Dokud se aplikace nezavre vola neustale metodu DrawFrame
				sf.DrawFrame();
				Application.DoEvents();
				System.Threading.Thread.Sleep(10);
			}
		}
	}
}
