using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ScreensaverSample
{
	/// <summary>
	/// Hlavni formular aplikace (screensaveru)
	/// </summary>
	public class SaverForm : System.Windows.Forms.Form
	{
		/// <summary> Pole, ktere obsahuje cerviky na obrazovce </summary>
		Cervik[] cervici;
		/// <summary> Generator nahodnych cisel pro hlavni formular </summary>
		Random rnd;


		/// <summary>
		/// Nastavi vlastnosti formulare a vytvori pole cerviku
		/// </summary>
		public SaverForm()
		{
			// Bez okraje, maximalizovany a zkryt mys
			FormBorderStyle=FormBorderStyle.None;
			WindowState=FormWindowState.Maximized;
			Cursor.Hide();

			// Nastaveni nasledujicich stylu zamezi blikani pri kresleni
			SetStyle(ControlStyles.AllPaintingInWmPaint|
				ControlStyles.DoubleBuffer|ControlStyles.Opaque|ControlStyles.UserPaint,true);

			int x=Screen.PrimaryScreen.Bounds.Width/2;
			int y=Screen.PrimaryScreen.Bounds.Height/2;

			// Nahodne prida do pole cerviku cerviky ruzneho typu
			cervici=new Cervik[5];
			rnd=new Random();
			for(int i=0; i<cervici.Length; i++)
			{
				if (rnd.Next(2)==1)
					cervici[i]=new CervikJedna(x,y);
				else
					cervici[i]=new CervikDva(x,y);
			}
		}


		/// <summary>
		/// Vykresli jeden snimek - napred vykresli nekolik cernych
		/// kruhu (jako mazani) a pote nakresli cerviky
		/// </summary>
		public void DrawFrame()
		{
			using(Graphics gr=CreateGraphics())
			{
				for(int i=0; i<100; i++)
					gr.FillEllipse(Brushes.Black,rnd.Next(Width)-5,rnd.Next(Height)-5,10,10);

				// kreslit cerviky
				foreach(Cervik c in cervici) 
					c.DrawFrame(gr,Width,Height);
			}
		}


		/// <summary>
		/// Pokud uzivatel stiskl klavesu - ukoncit
		/// </summary>
		protected override void OnKeyDown(KeyEventArgs e)
		{
			base.OnKeyDown(e);
			Close();
		}


		/// <summary> Sem se uklada pozice mysi pri spusteni</summary>
		Point ptLast=Point.Empty;

		/// <summary>
		/// Pokud uzivatel pohnul (vice) mysi - ukoncit
		/// </summary>
		protected override void OnMouseMove(MouseEventArgs e)
		{
			if (ptLast==Point.Empty) ptLast=new Point(e.X,e.Y);
			base.OnMouseMove(e);
			if (Math.Abs(ptLast.X-e.X)>5&&Math.Abs(ptLast.Y-e.Y)>5) Close();
		}
	}
}
