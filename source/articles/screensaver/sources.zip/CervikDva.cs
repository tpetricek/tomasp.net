using System;
using System.Drawing;

namespace ScreensaverSample
{
	/// <summary>
	/// Druhy cervik - 
	///		posouva se do 4 smeru a meni pri tom svoji velikost
	///		kdyz zmeni smer zmeni i barvu
	/// </summary>
	/// <remarks>
	/// Urci si smer kterym pojede a pocet kroku ktere tim smerem udela.
	/// Kdyz narazi na okraj sveta tak prejede zleva doprava, zezhora dolu atd.
	/// </remarks>
	public class CervikDva : Cervik
	{
		#region Constructor

		/// <summary>
		/// Inicializuje cervika
		/// </summary>
		public CervikDva(int x,int y) : base(x,y)
		{
			sizeChange=RndGen.Next(2)==0?1:-1;
		}

		#endregion

		#region Posouvani cervika

		// kolik kroku danym smerem se ma udelat ?
		int stepsCount=0;
		
		// jakym smerem se pohybuje ?
		//  (0-levo, 2-pravo, 1-dolu, 3-nahoru)
		int direction;

		// pokud je 1 tak se zvetsuje, pokud -1 tak se zmensuje
		int sizeChange;


		/// <summary>
		/// Meni pozicic cervika (pretizena metoda)
		/// </summary>
		/// <param name="width">Sirka okna</param>
		/// <param name="height">Vyska okna</param>
		protected override void ChangePosAndSize(int width, int height)
		{
			// zmensuje pocet kroku ktere se maji udelat
			// a pokud dojde k nule meni smer
			if (stepsCount--==0)
			{
				// pri pristim volani ChangeColor se zmeni barva!
				changeClr=true;
				
				// nahodne voli kolik kroku se ma udelat
				stepsCount=RndGen.Next(50)+15;
				
				// meni smer cervika - zataci vzdy o 90 nebo -90 stupnu
				if (RndGen.Next(2)==0) direction++; else direction--;
				if (direction==-1) direction=3;
				if (direction==4) direction=0;
			}
			
			// posouva cervika
			if (direction==0) Position.X-=5;
			if (direction==2) Position.X+=5;
			if (direction==1) Position.Y-=5;
			if (direction==3) Position.Y+=5;		

			// kontroluje zda neprejel pres okraj
			if (Position.X<0) Position.X+=width;
			if (Position.Y<0) Position.Y+=height;
			if (Position.X>width) Position.X-=width;
			if (Position.Y>height) Position.Y-=height;

			// pokud se jiz dost zmensi/zvetsil meni zda roste nebo se zmensuje
			if (Size.Width<5||Size.Width>35) sizeChange=-sizeChange;
			// zmensi/zvetsi cervika
			Size=new Size(Size.Width+sizeChange,Size.Height+sizeChange);
		}

		#endregion
		#region Zmena barvy cervika

		// toto je nastavene na true pokud se ma prebarvit
		// (nastavuje se to pri zmene smeru)
		bool changeClr=true;


		/// <summary>
		/// Meni barvu cervika (pretizena metoda)
		/// </summary>
		/// <remarks>Barva se meni pri zmene smeru</remarks>
		protected override void ChangeColor()
		{
			if (changeClr)			
			{
				// voli nahodnou "zluto-zelenou" barvu
				int g=RndGen.Next(128)+64,r=RndGen.Next(g);
				CurrentColor=Color.FromArgb(r,g,0);
				changeClr=false;
			}
		}

		#endregion
	}
}
