using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DemoApplication
{
	/// <summary>
	/// Summary description for design.
	/// </summary>
	public class design : System.Web.UI.Page
	{
		protected EeekSoft.Web.Controls.GraphicalCheckBox GraphicalCheckBox1;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton1;
		protected EeekSoft.Web.Controls.GraphicalCheckBox Graphicalcheckbox2;
		protected EeekSoft.Web.Controls.GraphicalCheckBox Graphicalcheckbox3;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton2;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton3;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			EeekSoft.Web.Controls.GraphicalControlsSettings grs
				=new EeekSoft.Web.Controls.GraphicalControlsSettings();
			string s=DropDownList1.SelectedValue+"/";

			grs.CheckboxCheckedImg=s+"check-checked.gif";
			grs.CheckboxUncheckedImg=s+"check.gif";
			grs.CheckboxCheckedOverImg=s+"check-checked-over.gif";
			grs.CheckboxUncheckedOverImg=s+"check-over.gif";

      grs.RadioCheckedImg=s+"radio-checked.gif";
			grs.RadioUncheckedImg=s+"radio.gif";
			grs.RadioCheckedOverImg=s+"radio-checked-over.gif";
			grs.RadioUncheckedOverImg=s+"radio-over.gif";
			grs.Save();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
