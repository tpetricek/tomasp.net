using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DemoApplication
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected EeekSoft.Web.Controls.GraphicalCheckBox GraphicalCheckBox2;
		protected EeekSoft.Web.Controls.GraphicalCheckBox GraphicalCheckBox3;
		protected System.Web.UI.WebControls.CheckBox CheckBox1;
		protected System.Web.UI.WebControls.CheckBox CheckBox2;
		protected System.Web.UI.WebControls.CheckBox CheckBox3;
		protected System.Web.UI.WebControls.RadioButton RadioButton1;
		protected System.Web.UI.WebControls.RadioButton RadioButton2;
		protected System.Web.UI.WebControls.RadioButton RadioButton3;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton1;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton2;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton3;
		protected EeekSoft.Web.Controls.GraphicalRadioButton Graphicalradiobutton4;
		protected System.Web.UI.WebControls.RadioButton RadioButton4;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected EeekSoft.Web.Controls.GraphicalCheckBox Graphicalcheckbox5;
		protected EeekSoft.Web.Controls.GraphicalCheckBox Graphicalcheckbox4;
		protected EeekSoft.Web.Controls.GraphicalCheckBox Graphicalcheckbox6;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.Label Label9;
		protected EeekSoft.Web.Controls.GraphicalCheckBox GraphicalCheckBox1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			Label1.Visible=false;
			Label2.Visible=false;

			if (Graphicalradiobutton1.Checked)
				Label3.Text="Option 1";
			if (Graphicalradiobutton2.Checked)
				Label3.Text="Option 2";
			if (Graphicalradiobutton4.Checked)
				Label3.Text="Option 4";

			if (RadioButton1.Checked)
				Label4.Text="Option 1";
			if (RadioButton2.Checked)
				Label4.Text="Option 2";
			if (RadioButton4.Checked)
				Label4.Text="Option 4";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.GraphicalCheckBox1.CheckedChanged += new System.EventHandler(this.GraphicalCheckBox1_CheckedChanged);
			this.Graphicalcheckbox6.CheckedChanged += new System.EventHandler(this.Graphicalcheckbox6_CheckedChanged);
			this.Graphicalcheckbox4.CheckedChanged += new System.EventHandler(this.Graphicalcheckbox4_CheckedChanged);
			this.GraphicalCheckBox2.CheckedChanged += new System.EventHandler(this.GraphicalCheckBox2_CheckedChanged);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void GraphicalCheckBox1_CheckedChanged(object sender, System.EventArgs e)
		{
			Label1.Visible=true;
		}

		private void GraphicalCheckBox2_CheckedChanged(object sender, System.EventArgs e)
		{
			Label2.Visible=true;
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void Graphicalcheckbox4_CheckedChanged(object sender, System.EventArgs e)
		{
			Label5.Text=Graphicalcheckbox4.CheckState.ToString();		
		}

		private void Graphicalcheckbox6_CheckedChanged(object sender, System.EventArgs e)
		{
			Label6.Text=Graphicalcheckbox6.CheckState.ToString();
		}
	}
}
