using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Xml;

namespace FractalSnow
{
	/// <summary>
	/// Settings window
	/// </summary>
	public class Settings : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.Button btnOk;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.PictureBox picFlake;
    private System.Windows.Forms.ComboBox comboType;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TrackBar trackDepth;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TrackBar trackBrAngle;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TrackBar trackBranching;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.TrackBar trackShrink;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.TabPage tabPage4;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.PictureBox picColor;
    private System.Windows.Forms.TrackBar trackCount;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.NumericUpDown numStopFalling;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.Label label15;
    private System.Windows.Forms.Label label16;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.Label label18;
    private System.Windows.Forms.Label label19;
    private System.Windows.Forms.Label label20;
    private System.Windows.Forms.NumericUpDown numFallMin;
    private System.Windows.Forms.NumericUpDown numFallMax;
    private System.Windows.Forms.NumericUpDown numSizeMin;
    private System.Windows.Forms.NumericUpDown numSizeMax;
    private System.Windows.Forms.NumericUpDown numMeltFlu;
    private System.Windows.Forms.NumericUpDown numMeltStart;
    private System.Windows.Forms.NumericUpDown numWindChange;
    private System.Windows.Forms.NumericUpDown numWindForce;
    private System.Windows.Forms.ColorDialog colorDlg;
    private System.Windows.Forms.Button btnSavePrev;
    private System.Windows.Forms.RadioButton radioSolid;
    private System.Windows.Forms.RadioButton radioGradient;
    private System.Windows.Forms.Label label21;
    private System.Windows.Forms.Label label22;
    private System.Windows.Forms.RadioButton radioImage;
    private System.Windows.Forms.TextBox textPath;
    private System.Windows.Forms.OpenFileDialog openFile;
    private System.Windows.Forms.Button btnBrowse;
    private System.Windows.Forms.PictureBox picSolid;
    private System.Windows.Forms.PictureBox picTop;
    private System.Windows.Forms.PictureBox picBottom;
    private System.Windows.Forms.TabControl tabCtrl;
    private FractalSnow.SnowControl aboutSnow;
    private System.Windows.Forms.LinkLabel linkMail;
    private System.Windows.Forms.LinkLabel linkWeb;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Settings()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.tabCtrl = new System.Windows.Forms.TabControl();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.numWindChange = new System.Windows.Forms.NumericUpDown();
      this.label18 = new System.Windows.Forms.Label();
      this.label19 = new System.Windows.Forms.Label();
      this.numWindForce = new System.Windows.Forms.NumericUpDown();
      this.label20 = new System.Windows.Forms.Label();
      this.numMeltFlu = new System.Windows.Forms.NumericUpDown();
      this.label15 = new System.Windows.Forms.Label();
      this.label16 = new System.Windows.Forms.Label();
      this.numMeltStart = new System.Windows.Forms.NumericUpDown();
      this.label17 = new System.Windows.Forms.Label();
      this.numSizeMin = new System.Windows.Forms.NumericUpDown();
      this.label12 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.numSizeMax = new System.Windows.Forms.NumericUpDown();
      this.label14 = new System.Windows.Forms.Label();
      this.numFallMin = new System.Windows.Forms.NumericUpDown();
      this.label9 = new System.Windows.Forms.Label();
      this.label11 = new System.Windows.Forms.Label();
      this.numFallMax = new System.Windows.Forms.NumericUpDown();
      this.label10 = new System.Windows.Forms.Label();
      this.picColor = new System.Windows.Forms.PictureBox();
      this.numStopFalling = new System.Windows.Forms.NumericUpDown();
      this.label8 = new System.Windows.Forms.Label();
      this.trackCount = new System.Windows.Forms.TrackBar();
      this.label7 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.tabPage4 = new System.Windows.Forms.TabPage();
      this.btnBrowse = new System.Windows.Forms.Button();
      this.textPath = new System.Windows.Forms.TextBox();
      this.radioImage = new System.Windows.Forms.RadioButton();
      this.picBottom = new System.Windows.Forms.PictureBox();
      this.label22 = new System.Windows.Forms.Label();
      this.picTop = new System.Windows.Forms.PictureBox();
      this.label21 = new System.Windows.Forms.Label();
      this.radioGradient = new System.Windows.Forms.RadioButton();
      this.picSolid = new System.Windows.Forms.PictureBox();
      this.radioSolid = new System.Windows.Forms.RadioButton();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.trackShrink = new System.Windows.Forms.TrackBar();
      this.label5 = new System.Windows.Forms.Label();
      this.trackBranching = new System.Windows.Forms.TrackBar();
      this.label4 = new System.Windows.Forms.Label();
      this.trackBrAngle = new System.Windows.Forms.TrackBar();
      this.label3 = new System.Windows.Forms.Label();
      this.trackDepth = new System.Windows.Forms.TrackBar();
      this.label2 = new System.Windows.Forms.Label();
      this.comboType = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.picFlake = new System.Windows.Forms.PictureBox();
      this.tabPage3 = new System.Windows.Forms.TabPage();
      this.linkWeb = new System.Windows.Forms.LinkLabel();
      this.linkMail = new System.Windows.Forms.LinkLabel();
      this.aboutSnow = new FractalSnow.SnowControl();
      this.btnOk = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.colorDlg = new System.Windows.Forms.ColorDialog();
      this.btnSavePrev = new System.Windows.Forms.Button();
      this.openFile = new System.Windows.Forms.OpenFileDialog();
      this.tabCtrl.SuspendLayout();
      this.tabPage1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numWindChange)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numWindForce)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numMeltFlu)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numMeltStart)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numSizeMin)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numSizeMax)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numFallMin)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numFallMax)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.numStopFalling)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackCount)).BeginInit();
      this.tabPage4.SuspendLayout();
      this.tabPage2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.trackShrink)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackBranching)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackBrAngle)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackDepth)).BeginInit();
      this.tabPage3.SuspendLayout();
      this.SuspendLayout();
      // 
      // tabCtrl
      // 
      this.tabCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.tabCtrl.Controls.Add(this.tabPage1);
      this.tabCtrl.Controls.Add(this.tabPage4);
      this.tabCtrl.Controls.Add(this.tabPage2);
      this.tabCtrl.Controls.Add(this.tabPage3);
      this.tabCtrl.Location = new System.Drawing.Point(4, 8);
      this.tabCtrl.Name = "tabCtrl";
      this.tabCtrl.SelectedIndex = 0;
      this.tabCtrl.Size = new System.Drawing.Size(376, 256);
      this.tabCtrl.TabIndex = 0;
      this.tabCtrl.SelectedIndexChanged += new System.EventHandler(this.tabCtrl_SelectedIndexChanged);
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.numWindChange);
      this.tabPage1.Controls.Add(this.label18);
      this.tabPage1.Controls.Add(this.label19);
      this.tabPage1.Controls.Add(this.numWindForce);
      this.tabPage1.Controls.Add(this.label20);
      this.tabPage1.Controls.Add(this.numMeltFlu);
      this.tabPage1.Controls.Add(this.label15);
      this.tabPage1.Controls.Add(this.label16);
      this.tabPage1.Controls.Add(this.numMeltStart);
      this.tabPage1.Controls.Add(this.label17);
      this.tabPage1.Controls.Add(this.numSizeMin);
      this.tabPage1.Controls.Add(this.label12);
      this.tabPage1.Controls.Add(this.label13);
      this.tabPage1.Controls.Add(this.numSizeMax);
      this.tabPage1.Controls.Add(this.label14);
      this.tabPage1.Controls.Add(this.numFallMin);
      this.tabPage1.Controls.Add(this.label9);
      this.tabPage1.Controls.Add(this.label11);
      this.tabPage1.Controls.Add(this.numFallMax);
      this.tabPage1.Controls.Add(this.label10);
      this.tabPage1.Controls.Add(this.picColor);
      this.tabPage1.Controls.Add(this.numStopFalling);
      this.tabPage1.Controls.Add(this.label8);
      this.tabPage1.Controls.Add(this.trackCount);
      this.tabPage1.Controls.Add(this.label7);
      this.tabPage1.Controls.Add(this.label6);
      this.tabPage1.Location = new System.Drawing.Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Size = new System.Drawing.Size(368, 230);
      this.tabPage1.TabIndex = 2;
      this.tabPage1.Text = "Snow & Environment";
      // 
      // numWindChange
      // 
      this.numWindChange.Location = new System.Drawing.Point(144, 192);
      this.numWindChange.Maximum = new System.Decimal(new int[] {
                                                                  250,
                                                                  0,
                                                                  0,
                                                                  0});
      this.numWindChange.Name = "numWindChange";
      this.numWindChange.Size = new System.Drawing.Size(72, 20);
      this.numWindChange.TabIndex = 22;
      // 
      // label18
      // 
      this.label18.Location = new System.Drawing.Point(88, 192);
      this.label18.Name = "label18";
      this.label18.TabIndex = 21;
      this.label18.Text = "Changing:";
      // 
      // label19
      // 
      this.label19.Location = new System.Drawing.Point(8, 192);
      this.label19.Name = "label19";
      this.label19.Size = new System.Drawing.Size(96, 23);
      this.label19.TabIndex = 25;
      this.label19.Text = "Wind:";
      // 
      // numWindForce
      // 
      this.numWindForce.Location = new System.Drawing.Point(280, 192);
      this.numWindForce.Maximum = new System.Decimal(new int[] {
                                                                 250,
                                                                 0,
                                                                 0,
                                                                 0});
      this.numWindForce.Name = "numWindForce";
      this.numWindForce.Size = new System.Drawing.Size(72, 20);
      this.numWindForce.TabIndex = 23;
      // 
      // label20
      // 
      this.label20.Location = new System.Drawing.Point(224, 192);
      this.label20.Name = "label20";
      this.label20.TabIndex = 24;
      this.label20.Text = "Force:";
      // 
      // numMeltFlu
      // 
      this.numMeltFlu.Location = new System.Drawing.Point(144, 168);
      this.numMeltFlu.Maximum = new System.Decimal(new int[] {
                                                               128,
                                                               0,
                                                               0,
                                                               0});
      this.numMeltFlu.Minimum = new System.Decimal(new int[] {
                                                               1,
                                                               0,
                                                               0,
                                                               0});
      this.numMeltFlu.Name = "numMeltFlu";
      this.numMeltFlu.Size = new System.Drawing.Size(72, 20);
      this.numMeltFlu.TabIndex = 17;
      this.numMeltFlu.Value = new System.Decimal(new int[] {
                                                             1,
                                                             0,
                                                             0,
                                                             0});
      // 
      // label15
      // 
      this.label15.Location = new System.Drawing.Point(88, 168);
      this.label15.Name = "label15";
      this.label15.TabIndex = 16;
      this.label15.Text = "Fluency:";
      // 
      // label16
      // 
      this.label16.Location = new System.Drawing.Point(8, 168);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(96, 23);
      this.label16.TabIndex = 20;
      this.label16.Text = "Melting:";
      // 
      // numMeltStart
      // 
      this.numMeltStart.Location = new System.Drawing.Point(280, 168);
      this.numMeltStart.Maximum = new System.Decimal(new int[] {
                                                                 256,
                                                                 0,
                                                                 0,
                                                                 0});
      this.numMeltStart.Minimum = new System.Decimal(new int[] {
                                                                 1,
                                                                 0,
                                                                 0,
                                                                 0});
      this.numMeltStart.Name = "numMeltStart";
      this.numMeltStart.Size = new System.Drawing.Size(72, 20);
      this.numMeltStart.TabIndex = 18;
      this.numMeltStart.Value = new System.Decimal(new int[] {
                                                               1,
                                                               0,
                                                               0,
                                                               0});
      // 
      // label17
      // 
      this.label17.Location = new System.Drawing.Point(224, 168);
      this.label17.Name = "label17";
      this.label17.TabIndex = 19;
      this.label17.Text = "Start:";
      // 
      // numSizeMin
      // 
      this.numSizeMin.Location = new System.Drawing.Point(144, 144);
      this.numSizeMin.Minimum = new System.Decimal(new int[] {
                                                               2,
                                                               0,
                                                               0,
                                                               0});
      this.numSizeMin.Name = "numSizeMin";
      this.numSizeMin.Size = new System.Drawing.Size(72, 20);
      this.numSizeMin.TabIndex = 12;
      this.numSizeMin.Value = new System.Decimal(new int[] {
                                                             2,
                                                             0,
                                                             0,
                                                             0});
      // 
      // label12
      // 
      this.label12.Location = new System.Drawing.Point(88, 144);
      this.label12.Name = "label12";
      this.label12.TabIndex = 11;
      this.label12.Text = "Minimum:";
      // 
      // label13
      // 
      this.label13.Location = new System.Drawing.Point(8, 144);
      this.label13.Name = "label13";
      this.label13.TabIndex = 15;
      this.label13.Text = "Flake size:";
      // 
      // numSizeMax
      // 
      this.numSizeMax.Location = new System.Drawing.Point(280, 144);
      this.numSizeMax.Minimum = new System.Decimal(new int[] {
                                                               2,
                                                               0,
                                                               0,
                                                               0});
      this.numSizeMax.Name = "numSizeMax";
      this.numSizeMax.Size = new System.Drawing.Size(72, 20);
      this.numSizeMax.TabIndex = 13;
      this.numSizeMax.Value = new System.Decimal(new int[] {
                                                             2,
                                                             0,
                                                             0,
                                                             0});
      // 
      // label14
      // 
      this.label14.Location = new System.Drawing.Point(224, 144);
      this.label14.Name = "label14";
      this.label14.TabIndex = 14;
      this.label14.Text = "Maximum:";
      // 
      // numFallMin
      // 
      this.numFallMin.DecimalPlaces = 1;
      this.numFallMin.Location = new System.Drawing.Point(144, 120);
      this.numFallMin.Maximum = new System.Decimal(new int[] {
                                                               25,
                                                               0,
                                                               0,
                                                               0});
      this.numFallMin.Minimum = new System.Decimal(new int[] {
                                                               1,
                                                               0,
                                                               0,
                                                               0});
      this.numFallMin.Name = "numFallMin";
      this.numFallMin.Size = new System.Drawing.Size(72, 20);
      this.numFallMin.TabIndex = 7;
      this.numFallMin.Value = new System.Decimal(new int[] {
                                                             1,
                                                             0,
                                                             0,
                                                             0});
      // 
      // label9
      // 
      this.label9.Location = new System.Drawing.Point(88, 120);
      this.label9.Name = "label9";
      this.label9.TabIndex = 6;
      this.label9.Text = "Minimum:";
      // 
      // label11
      // 
      this.label11.Location = new System.Drawing.Point(8, 120);
      this.label11.Name = "label11";
      this.label11.TabIndex = 10;
      this.label11.Text = "Falling speed:";
      // 
      // numFallMax
      // 
      this.numFallMax.DecimalPlaces = 1;
      this.numFallMax.Location = new System.Drawing.Point(280, 120);
      this.numFallMax.Maximum = new System.Decimal(new int[] {
                                                               25,
                                                               0,
                                                               0,
                                                               0});
      this.numFallMax.Minimum = new System.Decimal(new int[] {
                                                               1,
                                                               0,
                                                               0,
                                                               0});
      this.numFallMax.Name = "numFallMax";
      this.numFallMax.Size = new System.Drawing.Size(72, 20);
      this.numFallMax.TabIndex = 8;
      this.numFallMax.Value = new System.Decimal(new int[] {
                                                             1,
                                                             0,
                                                             0,
                                                             0});
      // 
      // label10
      // 
      this.label10.Location = new System.Drawing.Point(224, 120);
      this.label10.Name = "label10";
      this.label10.TabIndex = 9;
      this.label10.Text = "Maximum:";
      // 
      // picColor
      // 
      this.picColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picColor.Cursor = System.Windows.Forms.Cursors.Default;
      this.picColor.Location = new System.Drawing.Point(152, 72);
      this.picColor.Name = "picColor";
      this.picColor.Size = new System.Drawing.Size(88, 24);
      this.picColor.TabIndex = 1;
      this.picColor.TabStop = false;
      this.picColor.Click += new System.EventHandler(this.picColor_Click);
      // 
      // numStopFalling
      // 
      this.numStopFalling.Location = new System.Drawing.Point(152, 48);
      this.numStopFalling.Maximum = new System.Decimal(new int[] {
                                                                   500,
                                                                   0,
                                                                   0,
                                                                   0});
      this.numStopFalling.Minimum = new System.Decimal(new int[] {
                                                                   200,
                                                                   0,
                                                                   0,
                                                                   -2147483648});
      this.numStopFalling.Name = "numStopFalling";
      this.numStopFalling.Size = new System.Drawing.Size(88, 20);
      this.numStopFalling.TabIndex = 5;
      // 
      // label8
      // 
      this.label8.Location = new System.Drawing.Point(8, 48);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(168, 23);
      this.label8.TabIndex = 4;
      this.label8.Text = "Stop falling (px from bottom):";
      // 
      // trackCount
      // 
      this.trackCount.Location = new System.Drawing.Point(144, 8);
      this.trackCount.Maximum = 500;
      this.trackCount.Minimum = 5;
      this.trackCount.Name = "trackCount";
      this.trackCount.Size = new System.Drawing.Size(192, 42);
      this.trackCount.TabIndex = 3;
      this.trackCount.TickFrequency = 20;
      this.trackCount.Value = 5;
      // 
      // label7
      // 
      this.label7.Location = new System.Drawing.Point(8, 16);
      this.label7.Name = "label7";
      this.label7.TabIndex = 2;
      this.label7.Text = "Number of flakes:";
      // 
      // label6
      // 
      this.label6.Location = new System.Drawing.Point(8, 80);
      this.label6.Name = "label6";
      this.label6.TabIndex = 0;
      this.label6.Text = "Snow flake color:";
      // 
      // tabPage4
      // 
      this.tabPage4.Controls.Add(this.btnBrowse);
      this.tabPage4.Controls.Add(this.textPath);
      this.tabPage4.Controls.Add(this.radioImage);
      this.tabPage4.Controls.Add(this.picBottom);
      this.tabPage4.Controls.Add(this.label22);
      this.tabPage4.Controls.Add(this.picTop);
      this.tabPage4.Controls.Add(this.label21);
      this.tabPage4.Controls.Add(this.radioGradient);
      this.tabPage4.Controls.Add(this.picSolid);
      this.tabPage4.Controls.Add(this.radioSolid);
      this.tabPage4.Location = new System.Drawing.Point(4, 22);
      this.tabPage4.Name = "tabPage4";
      this.tabPage4.Size = new System.Drawing.Size(368, 230);
      this.tabPage4.TabIndex = 4;
      this.tabPage4.Text = "Background";
      // 
      // btnBrowse
      // 
      this.btnBrowse.Location = new System.Drawing.Point(328, 144);
      this.btnBrowse.Name = "btnBrowse";
      this.btnBrowse.Size = new System.Drawing.Size(24, 23);
      this.btnBrowse.TabIndex = 11;
      this.btnBrowse.Text = "...";
      this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
      // 
      // textPath
      // 
      this.textPath.Location = new System.Drawing.Point(32, 144);
      this.textPath.Name = "textPath";
      this.textPath.Size = new System.Drawing.Size(296, 20);
      this.textPath.TabIndex = 10;
      this.textPath.Text = "";
      // 
      // radioImage
      // 
      this.radioImage.Location = new System.Drawing.Point(16, 120);
      this.radioImage.Name = "radioImage";
      this.radioImage.TabIndex = 9;
      this.radioImage.Text = "Image:";
      // 
      // picBottom
      // 
      this.picBottom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picBottom.Cursor = System.Windows.Forms.Cursors.Default;
      this.picBottom.Location = new System.Drawing.Point(168, 80);
      this.picBottom.Name = "picBottom";
      this.picBottom.Size = new System.Drawing.Size(88, 24);
      this.picBottom.TabIndex = 7;
      this.picBottom.TabStop = false;
      this.picBottom.Click += new System.EventHandler(this.picColor_Click);
      // 
      // label22
      // 
      this.label22.Location = new System.Drawing.Point(112, 80);
      this.label22.Name = "label22";
      this.label22.TabIndex = 8;
      this.label22.Text = "Bottom:";
      this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // picTop
      // 
      this.picTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picTop.Cursor = System.Windows.Forms.Cursors.Default;
      this.picTop.Location = new System.Drawing.Point(168, 56);
      this.picTop.Name = "picTop";
      this.picTop.Size = new System.Drawing.Size(88, 24);
      this.picTop.TabIndex = 6;
      this.picTop.TabStop = false;
      this.picTop.Click += new System.EventHandler(this.picColor_Click);
      // 
      // label21
      // 
      this.label21.Location = new System.Drawing.Point(112, 56);
      this.label21.Name = "label21";
      this.label21.TabIndex = 5;
      this.label21.Text = "Top:";
      this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // radioGradient
      // 
      this.radioGradient.Location = new System.Drawing.Point(16, 56);
      this.radioGradient.Name = "radioGradient";
      this.radioGradient.TabIndex = 4;
      this.radioGradient.Text = "Use gradient";
      // 
      // picSolid
      // 
      this.picSolid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picSolid.Cursor = System.Windows.Forms.Cursors.Default;
      this.picSolid.Location = new System.Drawing.Point(168, 16);
      this.picSolid.Name = "picSolid";
      this.picSolid.Size = new System.Drawing.Size(88, 24);
      this.picSolid.TabIndex = 3;
      this.picSolid.TabStop = false;
      this.picSolid.Click += new System.EventHandler(this.picColor_Click);
      // 
      // radioSolid
      // 
      this.radioSolid.Checked = true;
      this.radioSolid.Location = new System.Drawing.Point(16, 16);
      this.radioSolid.Name = "radioSolid";
      this.radioSolid.TabIndex = 0;
      this.radioSolid.TabStop = true;
      this.radioSolid.Text = "Solid color:";
      // 
      // tabPage2
      // 
      this.tabPage2.Controls.Add(this.trackShrink);
      this.tabPage2.Controls.Add(this.label5);
      this.tabPage2.Controls.Add(this.trackBranching);
      this.tabPage2.Controls.Add(this.label4);
      this.tabPage2.Controls.Add(this.trackBrAngle);
      this.tabPage2.Controls.Add(this.label3);
      this.tabPage2.Controls.Add(this.trackDepth);
      this.tabPage2.Controls.Add(this.label2);
      this.tabPage2.Controls.Add(this.comboType);
      this.tabPage2.Controls.Add(this.label1);
      this.tabPage2.Controls.Add(this.picFlake);
      this.tabPage2.Location = new System.Drawing.Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Size = new System.Drawing.Size(368, 230);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Snowflake Preview";
      // 
      // trackShrink
      // 
      this.trackShrink.LargeChange = 4;
      this.trackShrink.Location = new System.Drawing.Point(96, 128);
      this.trackShrink.Maximum = 25;
      this.trackShrink.Minimum = 10;
      this.trackShrink.Name = "trackShrink";
      this.trackShrink.Size = new System.Drawing.Size(136, 42);
      this.trackShrink.TabIndex = 9;
      this.trackShrink.Value = 15;
      this.trackShrink.Scroll += new System.EventHandler(this.flake_Changed);
      // 
      // label5
      // 
      this.label5.Location = new System.Drawing.Point(16, 136);
      this.label5.Name = "label5";
      this.label5.TabIndex = 10;
      this.label5.Text = "Shrinking:";
      // 
      // trackBranching
      // 
      this.trackBranching.LargeChange = 4;
      this.trackBranching.Location = new System.Drawing.Point(96, 96);
      this.trackBranching.Maximum = 32;
      this.trackBranching.Minimum = 4;
      this.trackBranching.Name = "trackBranching";
      this.trackBranching.Size = new System.Drawing.Size(136, 42);
      this.trackBranching.TabIndex = 7;
      this.trackBranching.Value = 10;
      this.trackBranching.Scroll += new System.EventHandler(this.flake_Changed);
      // 
      // label4
      // 
      this.label4.Location = new System.Drawing.Point(16, 104);
      this.label4.Name = "label4";
      this.label4.TabIndex = 8;
      this.label4.Text = "Branching:";
      // 
      // trackBrAngle
      // 
      this.trackBrAngle.LargeChange = 4;
      this.trackBrAngle.Location = new System.Drawing.Point(96, 64);
      this.trackBrAngle.Maximum = 18;
      this.trackBrAngle.Name = "trackBrAngle";
      this.trackBrAngle.Size = new System.Drawing.Size(136, 42);
      this.trackBrAngle.TabIndex = 5;
      this.trackBrAngle.Value = 2;
      this.trackBrAngle.Scroll += new System.EventHandler(this.flake_Changed);
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(16, 72);
      this.label3.Name = "label3";
      this.label3.TabIndex = 6;
      this.label3.Text = "Branch angle:";
      // 
      // trackDepth
      // 
      this.trackDepth.LargeChange = 4;
      this.trackDepth.Location = new System.Drawing.Point(96, 32);
      this.trackDepth.Maximum = 8;
      this.trackDepth.Name = "trackDepth";
      this.trackDepth.Size = new System.Drawing.Size(136, 42);
      this.trackDepth.TabIndex = 3;
      this.trackDepth.Value = 2;
      this.trackDepth.Scroll += new System.EventHandler(this.flake_Changed);
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 40);
      this.label2.Name = "label2";
      this.label2.TabIndex = 4;
      this.label2.Text = "Fractal depth:";
      // 
      // comboType
      // 
      this.comboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.comboType.Items.AddRange(new object[] {
                                                   "LineType",
                                                   "PointType"});
      this.comboType.Location = new System.Drawing.Point(104, 8);
      this.comboType.Name = "comboType";
      this.comboType.Size = new System.Drawing.Size(121, 21);
      this.comboType.TabIndex = 1;
      this.comboType.SelectedIndexChanged += new System.EventHandler(this.flake_Changed);
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 8);
      this.label1.Name = "label1";
      this.label1.TabIndex = 2;
      this.label1.Text = "Flake type:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // picFlake
      // 
      this.picFlake.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picFlake.Location = new System.Drawing.Point(232, 8);
      this.picFlake.Name = "picFlake";
      this.picFlake.Size = new System.Drawing.Size(130, 130);
      this.picFlake.TabIndex = 0;
      this.picFlake.TabStop = false;
      this.picFlake.Paint += new System.Windows.Forms.PaintEventHandler(this.picFlake_Paint);
      // 
      // tabPage3
      // 
      this.tabPage3.Controls.Add(this.linkWeb);
      this.tabPage3.Controls.Add(this.linkMail);
      this.tabPage3.Controls.Add(this.aboutSnow);
      this.tabPage3.Location = new System.Drawing.Point(4, 22);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Size = new System.Drawing.Size(368, 230);
      this.tabPage3.TabIndex = 3;
      this.tabPage3.Text = "About";
      // 
      // linkWeb
      // 
      this.linkWeb.Location = new System.Drawing.Point(264, 208);
      this.linkWeb.Name = "linkWeb";
      this.linkWeb.Size = new System.Drawing.Size(96, 16);
      this.linkWeb.TabIndex = 4;
      this.linkWeb.TabStop = true;
      this.linkWeb.Text = "www.eeeksoft.net";
      this.linkWeb.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkWeb_LinkClicked);
      // 
      // linkMail
      // 
      this.linkMail.Location = new System.Drawing.Point(8, 208);
      this.linkMail.Name = "linkMail";
      this.linkMail.Size = new System.Drawing.Size(88, 16);
      this.linkMail.TabIndex = 3;
      this.linkMail.TabStop = true;
      this.linkMail.Text = "Tom� Pet���ek";
      this.linkMail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkMail_LinkClicked);
      // 
      // aboutSnow
      // 
      this.aboutSnow.Antialiasing = true;
      this.aboutSnow.BackBrush = null;
      this.aboutSnow.BackImage = null;
      this.aboutSnow.BackType = FractalSnow.SnowControl.BackgroundType.ColorBack;
      this.aboutSnow.FlakeColor = System.Drawing.Color.White;
      this.aboutSnow.Location = new System.Drawing.Point(8, 8);
      this.aboutSnow.MaxFlakes = 20;
      this.aboutSnow.MaxSize = 10;
      this.aboutSnow.MaxSpeed = 5F;
      this.aboutSnow.MeltingFluency = 0;
      this.aboutSnow.MeltingStart = 1;
      this.aboutSnow.MinSize = 4;
      this.aboutSnow.MinSpeed = 2F;
      this.aboutSnow.Name = "aboutSnow";
      this.aboutSnow.Size = new System.Drawing.Size(352, 216);
      this.aboutSnow.StopFalling = -50;
      this.aboutSnow.TabIndex = 2;
      this.aboutSnow.TabStop = false;
      this.aboutSnow.WindChanging = 40;
      this.aboutSnow.WindForce = 20;
      // 
      // btnOk
      // 
      this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.btnOk.Location = new System.Drawing.Point(304, 272);
      this.btnOk.Name = "btnOk";
      this.btnOk.TabIndex = 1;
      this.btnOk.Text = "OK";
      this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.btnCancel.Location = new System.Drawing.Point(224, 272);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.TabIndex = 2;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // colorDlg
      // 
      this.colorDlg.AnyColor = true;
      this.colorDlg.FullOpen = true;
      // 
      // btnSavePrev
      // 
      this.btnSavePrev.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.btnSavePrev.Location = new System.Drawing.Point(8, 272);
      this.btnSavePrev.Name = "btnSavePrev";
      this.btnSavePrev.Size = new System.Drawing.Size(120, 23);
      this.btnSavePrev.TabIndex = 3;
      this.btnSavePrev.Text = "Save and preview";
      this.btnSavePrev.Click += new System.EventHandler(this.btnSavePrev_Click);
      // 
      // openFile
      // 
      this.openFile.Filter = "Images|*.jpg;*.jpeg;*.png;*.gif;*.bmp;*.tif;*.tiff;";
      // 
      // Settings
      // 
      this.AcceptButton = this.btnOk;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.btnCancel;
      this.ClientSize = new System.Drawing.Size(384, 301);
      this.Controls.Add(this.btnSavePrev);
      this.Controls.Add(this.btnCancel);
      this.Controls.Add(this.btnOk);
      this.Controls.Add(this.tabCtrl);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "Settings";
      this.Text = "Settings";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.Settings_Closing);
      this.Load += new System.EventHandler(this.Settings_Load);
      this.tabCtrl.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.numWindChange)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numWindForce)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numMeltFlu)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numMeltStart)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numSizeMin)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numSizeMax)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numFallMin)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numFallMax)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.numStopFalling)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackCount)).EndInit();
      this.tabPage4.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.trackShrink)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackBranching)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackBrAngle)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trackDepth)).EndInit();
      this.tabPage3.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion
    #region General

    /// <summary>
    /// Load
    /// </summary>
    private void Settings_Load(object sender, System.EventArgs e)
    {
      comboType.SelectedIndex=0;
      aboutSnow.BackColor=SystemColors.Control;
      aboutSnow.FlakeColor=SystemColors.ControlText;

      // load settings
      XmlDocument doc=new XmlDocument();
      doc.Load(Application.StartupPath+"\\FractalSnow.xml");

      trackCount.Value=Int32.Parse(doc.SelectSingleNode("settings/@maxflakes").Value);
      numStopFalling.Value=Int32.Parse(doc.SelectSingleNode("settings/@stopfalling").Value);
      numSizeMax.Value=Int32.Parse(doc.SelectSingleNode("settings/size/@max").Value);
      numSizeMin.Value=Int32.Parse(doc.SelectSingleNode("settings/size/@min").Value);
      numFallMax.Value=(decimal)Single.Parse(doc.SelectSingleNode("settings/speed/@max").Value,System.Globalization.NumberFormatInfo.InvariantInfo);
      numFallMin.Value=(decimal)Single.Parse(doc.SelectSingleNode("settings/speed/@min").Value,System.Globalization.NumberFormatInfo.InvariantInfo);
      numMeltFlu.Value=Int32.Parse(doc.SelectSingleNode("settings/melting/@fluency").Value);
      numMeltStart.Value=Int32.Parse(doc.SelectSingleNode("settings/melting/@start").Value);
      numWindChange.Value=Int32.Parse(doc.SelectSingleNode("settings/wind/@changing").Value);
      numWindForce.Value=Int32.Parse(doc.SelectSingleNode("settings/wind/@force").Value);
      picColor.BackColor=Color.FromArgb(Int32.Parse(doc.SelectSingleNode
        ("settings/flake/@r").Value),Int32.Parse(doc.
        SelectSingleNode("settings/flake/@g").Value),Int32.Parse
        (doc.SelectSingleNode("settings/flake/@b").Value));

      switch(doc.SelectSingleNode("settings/background/@type").Value)
      {
        case "color": radioSolid.Checked=true; break;
        case "gradient": radioGradient.Checked=true; break;
        case "image": radioImage.Checked=true; break;
      }
      picSolid.BackColor=Color.FromArgb(Int32.Parse(doc.SelectSingleNode
        ("settings/background/color/@r").Value),Int32.Parse(doc.
        SelectSingleNode("settings/background/color/@g").Value),Int32.Parse
        (doc.SelectSingleNode("settings/background/color/@b").Value));
      picTop.BackColor=Color.FromArgb(Int32.Parse(doc.SelectSingleNode
        ("settings/background/gradient/top/@r").Value),Int32.Parse(doc.
        SelectSingleNode("settings/background/gradient/top/@g").Value),Int32.Parse
        (doc.SelectSingleNode("settings/background/gradient/top/@b").Value));
      picBottom.BackColor=Color.FromArgb(Int32.Parse(doc.SelectSingleNode
        ("settings/background/gradient/bottom/@r").Value),Int32.Parse(doc.
        SelectSingleNode("settings/background/gradient/bottom/@g").Value),Int32.Parse
        (doc.SelectSingleNode("settings/background/gradient/bottom/@b").Value));
      textPath.Text=doc.SelectSingleNode("settings/background/image/@path").Value;
    }


    /// <summary>
    /// Save and preview
    /// </summary>
    private void btnSavePrev_Click(object sender, System.EventArgs e)
    {
      btnOk_Click(null,null);
      ScreenSaver s=new ScreenSaver(-1);
      s.Show();
    }


    /// <summary>
    /// Close
    /// </summary>
    private void btnCancel_Click(object sender, System.EventArgs e)
    {
      Close();
    }


    /// <summary>
    /// Save settings
    /// </summary>
    private void btnOk_Click(object sender, System.EventArgs e)
    {
      XmlDocument doc=new XmlDocument();
      doc.Load(Application.StartupPath+"\\FractalSnow.xml");
      doc.SelectSingleNode("settings/@maxflakes").Value=trackCount.Value.ToString();
      doc.SelectSingleNode("settings/@stopfalling").Value=numStopFalling.Value.ToString();
      doc.SelectSingleNode("settings/size/@max").Value=numSizeMax.Value.ToString();
      doc.SelectSingleNode("settings/size/@min").Value=numSizeMin.Value.ToString();
      doc.SelectSingleNode("settings/speed/@max").Value=numFallMax.Value.ToString(System.Globalization.NumberFormatInfo.InvariantInfo);
      doc.SelectSingleNode("settings/speed/@min").Value=numFallMin.Value.ToString(System.Globalization.NumberFormatInfo.InvariantInfo);
      doc.SelectSingleNode("settings/melting/@fluency").Value=numMeltFlu.Value.ToString();
      doc.SelectSingleNode("settings/melting/@start").Value=numMeltStart.Value.ToString();
      doc.SelectSingleNode("settings/wind/@changing").Value=numWindChange.Value.ToString();
      doc.SelectSingleNode("settings/wind/@force").Value=numWindForce.Value.ToString();

      doc.SelectSingleNode("settings/flake/@r").Value=picColor.BackColor.R.ToString();
      doc.SelectSingleNode("settings/flake/@g").Value=picColor.BackColor.G.ToString();
      doc.SelectSingleNode("settings/flake/@b").Value=picColor.BackColor.B.ToString();

      string val="color";
      if (radioGradient.Checked) val="gradient"; 
      if (radioImage.Checked) val="image"; 
      doc.SelectSingleNode("settings/background/@type").Value=val;

      doc.SelectSingleNode("settings/background/color/@r").Value=picSolid.BackColor.R.ToString();
      doc.SelectSingleNode("settings/background/color/@g").Value=picSolid.BackColor.G.ToString();
      doc.SelectSingleNode("settings/background/color/@b").Value=picSolid.BackColor.B.ToString();

      doc.SelectSingleNode("settings/background/gradient/top/@r").Value=picTop.BackColor.R.ToString();
      doc.SelectSingleNode("settings/background/gradient/top/@g").Value=picTop.BackColor.G.ToString();
      doc.SelectSingleNode("settings/background/gradient/top/@b").Value=picTop.BackColor.B.ToString();
      doc.SelectSingleNode("settings/background/gradient/bottom/@r").Value=picBottom.BackColor.R.ToString();
      doc.SelectSingleNode("settings/background/gradient/bottom/@g").Value=picBottom.BackColor.G.ToString();
      doc.SelectSingleNode("settings/background/gradient/bottom/@b").Value=picBottom.BackColor.B.ToString();

      doc.SelectSingleNode("settings/background/image/@path").Value=textPath.Text;
      doc.Save(Application.StartupPath+"\\FractalSnow.xml");

      if (sender!=null) Close();
    }

    #endregion 
    #region Preview

    /// <summary>
    /// Draw sample flake
    /// </summary>
    private void picFlake_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
    {
      e.Graphics.Clear(Color.DarkBlue);
      SnowFlake flake=new SnowFlake();
      flake.Type=(comboType.SelectedIndex==0)?
        SnowFlake.FlakeType.LineType:SnowFlake.FlakeType.PointType;
      flake.Depth=trackDepth.Value;
      flake.BranchAngle=trackBrAngle.Value*10;
      flake.Branching=1/((float)trackBranching.Value/4.0f);
      flake.Shrinking=1/((float)trackShrink.Value/10.0f);
      flake.Draw(e.Graphics,new Point(65,65));
    }


    /// <summary>
    /// Refresh flake
    /// </summary>
    private void flake_Changed(object sender, System.EventArgs e)
    {
      picFlake.Refresh();    
    }

    #endregion 
    #region Settings


    /// <summary>
    /// Flake color
    /// </summary>
    private void picColor_Click(object sender, System.EventArgs e)
    {
      colorDlg.Color=((Control)sender).BackColor;
      if (colorDlg.ShowDialog()==DialogResult.OK) ((Control)sender).BackColor=colorDlg.Color;
    }


    /// <summary>
    /// Browse for background image
    /// </summary>
    private void btnBrowse_Click(object sender, System.EventArgs e)
    {
      openFile.InitialDirectory=System.IO.Path.GetDirectoryName(textPath.Text);
      if (openFile.ShowDialog()==DialogResult.OK)
        textPath.Text=openFile.FileName;
    }

    #endregion 
    #region About

    /// <summary>
    /// Start / stop about
    /// </summary>
    private void tabCtrl_SelectedIndexChanged(object sender, System.EventArgs e)
    {
      if (tabCtrl.SelectedIndex==3) aboutSnow.Start(); 
      else if (aboutSnow.IsRunning) aboutSnow.Stop();
    }

    /// <summary>
    /// Stop falling snow
    /// </summary>
    private void Settings_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      if (aboutSnow.IsRunning) aboutSnow.Stop();
    }

    /// <summary>
    /// Open link
    /// </summary>
    private void linkMail_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
      System.Diagnostics.Process.Start("mailto:tomas@eeeksoft.net");
    }


    /// <summary>
    /// Open link
    /// </summary>
    private void linkWeb_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
    {
      System.Diagnostics.Process.Start("http://www.eeeksoft.net");
    }

    #endregion
	}
}
