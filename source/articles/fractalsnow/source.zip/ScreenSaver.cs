using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;
using System.Threading;

namespace FractalSnow
{
	/// <summary>
	/// Screensaver form
	/// </summary>
	public class ScreenSaver : System.Windows.Forms.Form
	{
    #region Members

    /// <summary>
    /// Snow control
    /// </summary>
    private SnowControl snowCtrl;
    private Point pt;
    private int iScreen=-1;

    /// <summary>
    /// Create form
    /// </summary>
    /// <param name="iScreen">Screen number</param>
		public ScreenSaver(int iScreen)
		{
      this.iScreen=iScreen;
      BackColor=Color.Black;
      Cursor.Hide(); 

      snowCtrl=new SnowControl();
      Controls.Add(snowCtrl);
      snowCtrl.Dock=DockStyle.Fill;
      snowCtrl.MouseDown+=new MouseEventHandler(snowCtrl_MouseDown);
      this.MouseDown+=new MouseEventHandler(snowCtrl_MouseDown);
      snowCtrl.MouseMove+=new MouseEventHandler(snowCtrl_MouseMove);
      this.MouseMove+=new MouseEventHandler(snowCtrl_MouseMove);
      snowCtrl.KeyDown+=new KeyEventHandler(snowCtrl_KeyDown);
      this.KeyDown+=new KeyEventHandler(snowCtrl_KeyDown);
      pt=Cursor.Position;
    }
    

    /// <summary>
    /// Load settings
    /// </summary>
    protected override void OnLoad(EventArgs e)
    {
      FormBorderStyle=FormBorderStyle.None;

      // multiple monitor support
      if (iScreen==-1)
        Bounds=Screen.AllScreens[Screen.AllScreens.GetLowerBound(0)].Bounds;
      else
        Bounds=Screen.AllScreens[iScreen].Bounds;

      // load settings
      XmlDocument doc=new XmlDocument();
      doc.Load(Application.StartupPath+"\\FractalSnow.xml");

      snowCtrl.MaxFlakes=Int32.Parse(doc.SelectSingleNode("settings/@maxflakes").Value);
      snowCtrl.StopFalling=Int32.Parse(doc.SelectSingleNode("settings/@stopfalling").Value);
      snowCtrl.MaxSize=Int32.Parse(doc.SelectSingleNode("settings/size/@max").Value);
      snowCtrl.MinSize=Int32.Parse(doc.SelectSingleNode("settings/size/@min").Value);
      snowCtrl.MaxSpeed=Single.Parse(doc.SelectSingleNode("settings/speed/@max").Value,System.Globalization.NumberFormatInfo.InvariantInfo);
      snowCtrl.MinSpeed=Single.Parse(doc.SelectSingleNode("settings/speed/@min").Value,System.Globalization.NumberFormatInfo.InvariantInfo);
      snowCtrl.MeltingFluency=Int32.Parse(doc.SelectSingleNode("settings/melting/@fluency").Value);
      snowCtrl.MeltingStart=Int32.Parse(doc.SelectSingleNode("settings/melting/@start").Value);
      snowCtrl.WindChanging=Int32.Parse(doc.SelectSingleNode("settings/wind/@changing").Value);
      snowCtrl.WindForce=Int32.Parse(doc.SelectSingleNode("settings/wind/@force").Value);
      snowCtrl.FlakeColor=Color.FromArgb(Int32.Parse(doc.SelectSingleNode
        ("settings/flake/@r").Value),Int32.Parse(doc.
        SelectSingleNode("settings/flake/@g").Value),Int32.Parse
        (doc.SelectSingleNode("settings/flake/@b").Value));

      switch(doc.SelectSingleNode("settings/background/@type").Value)
      {
        case "color":
          snowCtrl.BackType=SnowControl.BackgroundType.ColorBack;
          snowCtrl.BackColor=Color.FromArgb(Int32.Parse(doc.SelectSingleNode
            ("settings/background/color/@r").Value),Int32.Parse(doc.
            SelectSingleNode("settings/background/color/@g").Value),Int32.Parse
            (doc.SelectSingleNode("settings/background/color/@b").Value));
          break;

        case "gradient":
          snowCtrl.BackType=SnowControl.BackgroundType.BrushBack;
          snowCtrl.BackBrush=new System.Drawing.Drawing2D.LinearGradientBrush(
            new Rectangle(0,0,1,Height),
            Color.FromArgb(Int32.Parse(doc.SelectSingleNode
            ("settings/background/gradient/top/@r").Value),Int32.Parse(doc.
            SelectSingleNode("settings/background/gradient/top/@g").Value),Int32.Parse
            (doc.SelectSingleNode("settings/background/gradient/top/@b").Value)),
            Color.FromArgb(Int32.Parse(doc.SelectSingleNode
            ("settings/background/gradient/bottom/@r").Value),Int32.Parse(doc.
            SelectSingleNode("settings/background/gradient/bottom/@g").Value),Int32.Parse
            (doc.SelectSingleNode("settings/background/gradient/bottom/@b").Value)),90.0f);
          break;

        case "image":
          snowCtrl.BackImage=Bitmap.FromFile(doc.SelectSingleNode
            ("settings/background/image/@path").Value);
          snowCtrl.BackType=SnowControl.BackgroundType.ImageBack;
          break;
      }

      snowCtrl.Start();
      base.OnLoad(e);
    }


    /// <summary>
    /// Close application
    /// </summary>
    protected override void OnClosed(EventArgs e)
    {
      if (iScreen!=-1) Application.Exit();
      base.OnClosed(e);
    }


    /// <summary>
    /// Close form
    /// </summary>
    private void snowCtrl_MouseDown(object sender, MouseEventArgs e)
    {
      Close();
    }


    /// <summary>
    /// Close form
    /// </summary>
    private void snowCtrl_MouseMove(object sender, MouseEventArgs e)
    {
      if (((e.X-pt.X)*(e.X-pt.X)+(e.Y-pt.Y)*(e.Y-pt.Y))>36) Close();
    }


    /// <summary>
    /// Close form
    /// </summary>
    private void snowCtrl_KeyDown(object sender, KeyEventArgs e)
    {
      Close();
    }


    /// <summary>
    /// Show cursor
    /// </summary>
    protected override void OnClosing(CancelEventArgs e)
    {
      snowCtrl.Stop();
      Cursor.Show();
      base.OnClosing(e);
    }


    #endregion
    #region Static

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
		{
      if (args.Length==0||args[0].ToLower()=="/s")
      {
        // create form for each monitor
        for (int i=Screen.AllScreens.GetLowerBound(0); i<=Screen.AllScreens.GetUpperBound(0); i++)
          (new ScreenSaver(i)).Show();
        Application.Run();
        return;
      }
      if (args[0].ToLower().Substring(0,2)=="/p")
      {
        IntPtr hWnd=(IntPtr)UInt32.Parse(args[1]);
        if (IntPtr.Zero!=hWnd)
        {
          Thread thread=new Thread(new ThreadStart(new Preview(hWnd).Run));
          thread.Start();
          Application.Run();
          thread.Join();
        }
      }
      if (args[0].ToLower().Substring(0,2)=="/c")
      {
        Application.Run(new Settings());
      }
    }

    #endregion
  }
}
