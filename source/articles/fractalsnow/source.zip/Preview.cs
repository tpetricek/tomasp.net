using System;
using System.Threading;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace FractalSnow
{
  /// <summary>
  /// Preview
  /// </summary>
  class Preview
  {
    #region Members

    /// <summary>
    /// Parent window
    /// </summary>
    IntPtr parentWindow;

    /// <summary>
    /// Create screen saver preview
    /// </summary>
    /// <param name="parent">Parent window handle</param>
    public Preview(IntPtr parent)
    {
      parentWindow=parent;
    }


    /// <summary>
    /// Draw preview
    /// </summary>
    public void Run()
    {
      while(IsWindow(parentWindow)&&!IsWindowVisible(parentWindow)) Thread.Sleep(50);
      if (IsWindow(parentWindow))
      {
        Random rnd=new Random();
        RECT rc=new RECT();
        GetClientRect(parentWindow,ref rc);
        int size=(int)((double)((rc.Right-rc.Left)>(rc.Bottom-rc.Top)?
          (rc.Bottom-rc.Top):(rc.Right-rc.Left))/2.5);
        while (IsWindow(parentWindow)&&IsWindowVisible(parentWindow))
        {
          Graphics g=Graphics.FromHwnd(parentWindow);
          if (null!=g)
          {
            g.Clear(Color.Black);
            RandomSnowFlake f=new RandomSnowFlake(size,rnd.Next());
            f.Draw(g,new PointF((rc.Left+rc.Right)/2,(rc.Top+rc.Bottom)/2));
          }
          Thread.Sleep(2500);
        }
        Application.Exit();
      }
    }

    #endregion
    #region Win32 Interop

    /// <summary>
    /// Rectangle
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
      public int left;
      public int top;
      public int right;
      public int bottom;

      public int Left
      { get { return left; } }
      public int Top
      { get { return top; } }
      public int Right
      { get { return right; } }
      public int Bottom
      { get { return bottom; } }
      public int Width
      { get { return right-left; } }
      public int Height
      { get { return bottom - top; } }
    }

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hWnd, ref RECT rect);

    #endregion
  }
}
