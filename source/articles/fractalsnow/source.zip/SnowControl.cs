using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace FractalSnow
{
  /// <summary>
  /// Control for falling snowflakes
  /// </summary>
  public class SnowControl : System.Windows.Forms.Control
  {
    #region Constructor

    /// <summary>
    /// Create control
    /// </summary>
    public SnowControl()
    {
      SetStyle(ControlStyles.Opaque|ControlStyles.ResizeRedraw|
        ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint,true);
      tmrFall=new System.Timers.Timer(50);
      tmrFall.Elapsed+=new System.Timers.ElapsedEventHandler(tmrFall_Elapsed);
      mutex=new System.Threading.Mutex();
    }

    #endregion
    #region Variables

    private int iMaxFlakes=200;
    internal float fMaxSpeed=15.0f,fMinSpeed=2.0f;
    internal int iMaxSize=20,iMinSize=5;
    internal int iMeltingFluency=0,iMeltingStart=64;
    internal int iStopFalling=20;
    internal bool bAntialiasing=true;
    internal int iWindChanging=80,iWindForce=30;

    private BackgroundType backType=BackgroundType.ColorBack;
    private Color backColor=Color.Black;
    private Brush brushBack=null;
    private Image imgBack=null;
    internal Color flakeColor=Color.White;

    ArrayList arFlakes;
    System.Timers.Timer tmrFall;
    System.Threading.Mutex mutex;
    System.Threading.Thread paintThread;
    bool bRunning=false;

    #endregion
    #region Properties

    /// <summary>
    /// Maximal number of flake
    /// </summary>
    public int MaxFlakes
    {
      get { return iMaxFlakes; }
      set { iMaxFlakes=value; }
    }


    /// <summary>
    /// Maximal flake falling/melting speed
    /// </summary>
    public float MaxSpeed
    {
      get { return fMaxSpeed; }
      set { fMaxSpeed=value; }
    }


    /// <summary>
    /// Minimal flake falling/melting speed
    /// </summary>
    public float MinSpeed
    {
      get { return fMinSpeed; }
      set { fMinSpeed=value; }
    }


    /// <summary>
    /// Maximal flake size
    /// </summary>
    public int MaxSize
    {
      get { return iMaxSize; }
      set { iMaxSize=value; }
    }


    /// <summary>
    /// Minimal flake size
    /// </summary>
    public int MinSize
    {
      get { return iMinSize; }
      set { iMinSize=value; }
    }


    /// <summary>
    /// Fluency of snowflake melting (alpha blending)
    /// </summary>
    public int MeltingFluency
    {
      get { return iMeltingFluency; }
      set { iMeltingFluency=value; }
    }


    /// <summary>
    /// When flake will start melting
    /// </summary>
    public int MeltingStart
    {
      get { return iMeltingStart; }
      set { iMeltingStart=value; }
    }


    /// <summary>
    /// Where sholud flakes stop falling
    /// </summary>
    public int StopFalling
    {
      get { return iStopFalling; }
      set { iStopFalling=value; }
    }


    /// <summary>
    /// Anitaliased drawing
    /// </summary>
    public bool Antialiasing
    {
      get { return bAntialiasing; }
      set { bAntialiasing=value; }
    }


    /// <summary>
    /// How much is wind changing
    /// </summary>
    public int WindChanging
    {
      get { return iWindChanging; }
      set { iWindChanging=value; }
    }


    /// <summary>
    /// Force of wind
    /// </summary>
    public int WindForce
    {
      get { return iWindForce; }
      set { iWindForce=value; }
    }


    /// <summary>
    /// Background color
    /// </summary>
    public override Color BackColor
    {
      get { return backColor; }
      set { backColor=value; }
    }


    /// <summary>
    /// Use this brush to fill background
    /// </summary>
    public Brush BackBrush
    {
      get { return brushBack; }
      set { brushBack=value; }
    }


    /// <summary>
    /// Use this image as background
    /// </summary>
    public Image BackImage
    {
      get { return imgBack; }
      set { imgBack=value; }
    }

    /// <summary>
    /// Type of control backgound
    /// </summary>
    public BackgroundType BackType
    {
      get { return backType; }
      set { backType=value; }
    }


    /// <summary>
    /// Get or set snow flake color
    /// </summary>
    public Color FlakeColor
    {
      get { return flakeColor; }
      set { flakeColor=value; }
    }


    /// <summary>
    /// Is animation running ?
    /// </summary>
    public bool IsRunning
    {
      get { return paintThread!=null; }
    }
    #endregion
    #region Types

    /// <summary>
    /// Type of background
    /// </summary>
    public enum BackgroundType
    {
      /// <summary>Use image as background</summary>
      ImageBack,
      /// <summary>Use solid color as background</summary>
      ColorBack,
      /// <summary>Use brush as background</summary>
      BrushBack
    }


    /// <summary>
    /// Struct for fallnig snowflake
    /// </summary>
    private class FallingFlake
    {
      #region Variables

      private static Random rndGen;
      private SnowControl ctrl;

      PointF Position;
      SnowFlake Flake;
      float Speed;
      float X,Y;
      int Melting;
  
      #endregion
      #region Methods

      /// <summary>
      /// Init random generator
      /// </summary>
      static FallingFlake()
      {
        rndGen=new Random();
      }


      /// <summary>
      /// Create flake
      /// </summary>
      /// <param name="ctrl">Owner control</param>
      public FallingFlake(SnowControl ctrl)
      {
        this.ctrl=ctrl;
        Melting=ctrl.iMeltingStart;

        Flake=new RandomSnowFlake(ctrl.iMinSize+rndGen.Next(ctrl.iMaxSize),
          rndGen.Next(Int32.MaxValue));
        Flake.Color=ctrl.flakeColor;
        Flake.Antialiasing=ctrl.bAntialiasing;
        Position=new Point(rndGen.Next(ctrl.Width),
          -rndGen.Next(ctrl.Height));
        Speed=ctrl.fMinSpeed+
          (float)rndGen.NextDouble()*(ctrl.fMaxSpeed-ctrl.fMinSpeed);
        X=Position.X;
        Y=Position.Y;
      }


      /// <summary>
      /// Draw falling flake
      /// </summary>
      /// <param name="output">Output graphics</param>
      public void Draw(Graphics output)
      {
        output.CompositingQuality=(ctrl.bAntialiasing)?
          System.Drawing.Drawing2D.CompositingQuality.AssumeLinear:
          System.Drawing.Drawing2D.CompositingQuality.Default;
        if (Melting<ctrl.iMeltingFluency)
          Flake.Draw(output,Position,Melting*(255/ctrl.iMeltingFluency));
        else
          Flake.Draw(output,Position);
      }

      
      /// <summary>
      /// Move flake down
      /// </summary>
      public void Fall()
      {
        Position.Y+=Speed;
        Position.X=X+(float)Math.Sin((Position.Y-Y)/
          (float)ctrl.iWindChanging)*(float)ctrl.iWindForce;
      }


      /// <summary>
      /// Melt flake
      /// </summary>
      public void Melt()
      {
        Melting--;
      }


      #endregion
      #region Properties

      /// <summary>
      /// Is flake falling
      /// </summary>
      public bool IsFalling
      {
        get { return Position.Y<=ctrl.Height-ctrl.iStopFalling; }
      }


      /// <summary>
      /// Is flake melted 
      /// </summary>
      public bool IsVanished
      {
        get { return Melting<=0; }
      }

      #endregion
    }


    #endregion
    #region Methods

    /// <summary>
    /// Start/restart animation
    /// </summary>
    public void Start()
    {
      InitFlakes();
      tmrFall.Enabled=true;
      paintThread=new System.Threading.Thread(
        new System.Threading.ThreadStart(PaintOnThread));
      bRunning=true;
      paintThread.Start();
    }


    /// <summary>
    /// Stop animation
    /// </summary>
    public void Stop()
    {
      tmrFall.Enabled=false;
      bRunning=false;
      paintThread.Join(); paintThread=null;
    }


    /// <summary>
    /// Generate flakes
    /// </summary>
    private void InitFlakes()
    {
      arFlakes=new ArrayList();
      for(int i=0; i<iMaxFlakes; i++)
      {
        arFlakes.Add(new FallingFlake(this));
      }
    }

    #endregion
    #region Event handlers

    /// <summary>
    /// Move snow..
    /// </summary>
    private void tmrFall_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
    {
      mutex.WaitOne();
      int i=0;
      while(i<arFlakes.Count)
      {
        FallingFlake fl=(FallingFlake)arFlakes[i];
        if (fl.IsFalling) fl.Fall(); else fl.Melt();
        if (fl.IsVanished)
        {
          arFlakes.RemoveAt(i);
          arFlakes.Add(new FallingFlake(this));
        }
        else i++;
      }
      mutex.ReleaseMutex();
      //Refresh();
      Application.DoEvents();
    }


    /// <summary>
    /// Paint control
    /// </summary>
    protected override void OnPaint(PaintEventArgs pe)
    {
      if (!bRunning) 
      {
        if (backType==BackgroundType.ImageBack&&imgBack!=null)
          pe.Graphics.DrawImage(imgBack,0,0,Width,Height);
        else if (backType==BackgroundType.BrushBack&&brushBack!=null)
          pe.Graphics.FillRectangle(brushBack,0,0,Width,Height);
        else pe.Graphics.Clear(backColor);
      }
      base.OnPaint(pe);
    }


    /// <summary>
    /// Paint control on thread
    /// </summary>
    private void PaintOnThread()
    {
      while(bRunning)
      {
        mutex.WaitOne();
        Bitmap bmp=new Bitmap(Width,Height);
        Graphics gr=Graphics.FromImage(bmp);

        if (backType==BackgroundType.ImageBack&&imgBack!=null)
          gr.DrawImage(imgBack,0,0,Width,Height);
        else if (backType==BackgroundType.BrushBack&&brushBack!=null)
          gr.FillRectangle(brushBack,0,0,Width,Height);
        else gr.Clear(backColor);

        foreach(FallingFlake fl in arFlakes)
        {
          fl.Draw(gr);
        }

        Graphics ctrl=CreateGraphics();
        ctrl.DrawImageUnscaled(bmp,0,0);
        ctrl.Dispose();
        gr.Dispose(); bmp.Dispose();
        mutex.ReleaseMutex();
        System.Threading.Thread.Sleep(10);
      }
    }

    #endregion
  }
}
