#light
namespace Test

open System
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.Quotations

open ResolveClassDef.QuotExt
open ResolveClassDef.ClassQuotations

(*---------------------------------------------------------------------------*)
(* Example class with information for metaprogramming                        *)

module Person_Meta = begin
  let name = ref ""
  let ctor (n) =
    name := n
    
  let Say (pre:string) =
    let s = pre^", my name is "^(!name)^"." in
    print_string s
    
  let get_Name () =
    (!name)
  let set_Name (value) =
    name:=value
end

type Person = class 
  val mutable name : string;
  new((n:string)) = { name = ""; }
  member this.Say(pre:string) = ()
  member this.Name with get() = "" and set((v:string)) = ()
end


(*---------------------------------------------------------------------------*)
(* Working with class meta-information                                       *)

do
  let clsInfo = getClassFromType ((typeof() : Person typ).result)
  Console.WriteLine("Class '{0}':", clsInfo.name)
  if (clsInfo.baseName <> None) then
    Console.WriteLine(" base: {0}", clsInfo.baseName)
  
  clsInfo.members |> List.iter ( fun m ->
      match cmfMethod.Query m with
        | Some (name, expr, ret) ->
            printf "Method ( %s : %a ) = " name output_any ret
            printf "%a\n\n" output_any expr
        | _ ->
      match cmfField.Query m with
        | Some (name, typ, init) ->
            printf "Field ( %s : %a) " name output_any typ
        | _ ->
      match cmfProp.Query m with
        | Some (name, getter, setter, typ) ->
            printf "Property ( %s : %a )\n" name output_any typ
            printf "get = %a\n" output_any getter
            printf "set = %a\n\n" output_any setter
        | _ ->
      match cmfCtor.Query m with
        | Some (expr) ->
            printf "Ctor = %a\n\n" output_any expr
        | _ ->
            failwith "Error!"
    ) 
  
  ignore(Console.ReadKey())

