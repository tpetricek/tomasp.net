namespace ResolveClassDef

open System
open System.Reflection
open System.CodeDom
open System.Web
open System.Web.UI
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw;;

module QuotExt = begin
(*---------------------------------------------------------------------------*)
(* QUOTATIONS FOR CLASSES                                                    *)

	type classMember =
		| Constructor of expr
		| Method of (string*expr*Type option)
		| Property of (string*expr*expr*Type)
		| Field of (string*Type*expr option);;

	type 'a classMemberFamily =
	 { fMake: 'a -> classMember;
		 fQuery: classMember -> 'a option; }
		with
			member x.Query(y) = x.fQuery(y)
			member x.Make(z) = x.fMake(z)
		end;;

(*---------------------------------------------------------------------------*)

	let cmfCtor : (expr) classMemberFamily = 
		let q x = match x with
			| Constructor v -> Some v
			| _ -> None in
		let mk x = Constructor x in
		{ fQuery=q;fMake=mk; };;

	let cmfMethod : (string*expr*Type option) classMemberFamily =
		let q x = match x with
			| Method v -> Some v
			| _ -> None in
		let mk x = Method x in
		{ fQuery=q;fMake=mk; };;
	
	let cmfField : (string*Type*expr option) classMemberFamily =
		let q x = match x with
			| Field v -> Some v
			| _ -> None in
		let mk x = Field x in
		{ fQuery=q;fMake=mk; };;
	
	let cmfProp : (string*expr*expr*Type) classMemberFamily = 
		let q x = match x with
			| Property v -> Some v
			| _ -> None in
		let mk x = Property x in
		{ fQuery=q;fMake=mk; };;	
	
	type classInfo = {
			name:string;
			baseName:string option;
			members:classMember list;
		};;
		
	let makeClassInfo n b m = 
		{ name=n; baseName=b; members=m; };;

end;;

(*---------------------------------------------------------------------------*)
(* RESOLVE CLASS QUOTATION                                                   *)

open QuotExt;;

module ClassQuotations = begin

	let objType = (typeof() : obj typ).result;;
	let compilationMappingAttr = (typeof() : CompilationMappingAttribute typ).result;;
		
	/// Find quotations for specified member in the class
	/// (definition is stored in module with name ClassName_Meta)
	let findMemberExpr (t:Type) membName =
		let nsNames = if (t.Namespace = null) then [] else (t.Namespace.Split(Array.create 1 '.') |> Array.to_list) in
		let path = (nsNames@[t.Name^"_Meta"], membName) in
		let modDef = { topDefAssembly=t.Assembly.FullName; topDefPath=path; } in
		let defn = resolveTopDef (modDef, []) in
		match defn with
			| Some expr -> expr;
			| None -> failwith (string.Format("Member '{0}' in module "^
					"'{1}.{2}_Meta' could not be found!", membName, t.Namespace, t.Name));;
	
	
	/// Generates class info using reflection and F# quotations
	/// - that are extracted from objects stored in module with name 
	/// "ClassName_Meta" for now :-(
	let getClassFromType (t:Type) = 
		let base = if (t.BaseType = objType) then None else (Some t.BaseType.Name) in

		// constructors
		let ctors = t.GetConstructors() |> Array.to_list 
				|> List.map ( fun ctor ->
			let expr = (findMemberExpr t "ctor") in
			cmfCtor.Make(expr) ) in
				
		// fields (tricky - fields in F# are compiled into properties with 
		//  "[CompilationMapping(SourceLevelConstruct.Field)]" attribute)
		let fields = t.GetProperties(Enum.combine [BindingFlags.DeclaredOnly; BindingFlags.Public; 
				BindingFlags.NonPublic; BindingFlags.Instance]) |> Array.to_list 
				|> List.filter ( fun prop -> 
						match ((prop.GetCustomAttributes(compilationMappingAttr, false)) |> Array.to_list) with
							| [a] -> (a :?> CompilationMappingAttribute).Construct = SourceLevelConstruct.Field
							| _ -> false )
				|> List.map ( fun fld ->
			( cmfField.Make((fld.Name, fld.PropertyType, None))) ) in

		// methods - ignore property getters & setters (get_ / set_)
		let methods = t.GetMethods(Enum.combine [BindingFlags.DeclaredOnly; BindingFlags.Public; 
				BindingFlags.NonPublic; BindingFlags.Instance]) |> Array.to_list 
				|> List.filter ( fun meth -> (meth.Name.StartsWith("get_") || meth.Name.StartsWith("set_")) = false) 
				|> List.map ( fun meth ->
			let expr = (findMemberExpr t meth.Name) in
			let retType = if meth.ReturnType.FullName="System.Void" then None else (Some meth.ReturnType) in
			cmfMethod.Make((meth.Name, expr, retType)) ) in
			
		// properties - ignore properties with "[CompilationMapping(SourceLevelConstruct.Field)]" attribute
		// (this properties are generated for fields by F#)
		let props = t.GetProperties(Enum.combine [BindingFlags.DeclaredOnly; BindingFlags.Public; 
				BindingFlags.NonPublic; BindingFlags.Instance]) |> Array.to_list 
				|> List.filter ( fun prop -> (prop.GetCustomAttributes(compilationMappingAttr, false)).Length = 0 )
				|> List.map ( fun prop ->
			let getExp = (findMemberExpr t ("get_"^prop.Name))	in
			let setExp = (findMemberExpr t ("set_"^prop.Name))	in
			let typ = prop.PropertyType in
			cmfProp.Make ((prop.Name, getExp, setExp, typ)) ) in
		
		// combine all members	
		makeClassInfo (t.Name) base (ctors@fields@methods@props);;

end;;
