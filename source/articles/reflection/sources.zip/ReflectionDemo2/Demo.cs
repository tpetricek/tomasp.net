using System;
using System.Reflection;

namespace ReflectionDemo2
{
	/// <summary>
	/// Trida zamestnanec
	/// </summary>
	class Zamestnanec
	{
		private string _jmeno,_prijmeni;
		private int _plat;

		/// <summary>
		/// Vytvori zamestnance
		/// </summary>
		public Zamestnanec(string jmeno,string prijmeni)
		{
			_jmeno=jmeno; 
			_prijmeni=prijmeni;
		}


		/// <summary>
		/// Plat zamestnance
		/// </summary>
		public int Plat
		{
			get { return _plat; }
			set { _plat=value; }
		}


		/// <summary>
		/// Zmeni zamestnancovi plat
		/// </summary>
		public void ZmenitPlat(float nasobek)
		{
			_plat=(int)(nasobek*(float)_plat);
		}


		/// <summary>
		/// Vraci jmeno zamestnance
		/// </summary>
		public override string ToString()
		{
			return "Zamestnanec ("+_jmeno+" "+_prijmeni+")";
		}
	}

	class DemoApp
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// zjistime aktualni assembly
			Assembly asm=Assembly.GetExecutingAssembly();
			// zjisti typ zamestnanec
			Type zamType=asm.GetType("ReflectionDemo2.Zamestnanec");
			
			// vytvori instanci zamestnance
			// obdoba: objZam=new Zamestnanec("Bill","Gates");
			object objZam=Activator.CreateInstance(zamType,
				new object[] {"Bill","Gates"} );
			// zavola se Zamestnanec.ToString()
			Console.WriteLine(objZam.ToString());

			// Nastavi zamestnanci plat
			// obdoba: objZam.Plat=12345;
			PropertyInfo propPlat=zamType.GetProperty("Plat");
			propPlat.SetValue(objZam,12345,null);

			// Zvysime plat 
			// obdoba: objZam.ZmenitPlat(2.0f);
			MethodInfo met=zamType.GetMethod("ZmenitPlat");
			met.Invoke(objZam,new object[] {2.0f});

			// Zjistime plat
			// obdoba: Console.WriteLine(objZam.Plat);
			// (propPlat jiz mame od minuleho volani)
			int plat=(int)propPlat.GetValue(objZam,null);
			Console.WriteLine("Plat={0}",plat);
		}
	}
}
