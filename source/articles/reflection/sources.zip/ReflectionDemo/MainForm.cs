using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Reflection;

namespace ReflectionDemo
{
	/// <summary>
	/// Hlavni formular aplikace
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region Generated Code

		private System.Windows.Forms.Button btnLoad;
		private System.Windows.Forms.TreeView treeHierarchy;
		private System.Windows.Forms.CheckBox checkOnlyPub;
		private System.Windows.Forms.ImageList hierarchyIcons;
		private System.Windows.Forms.Label label1;
		private System.ComponentModel.IContainer components;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}


		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.btnLoad = new System.Windows.Forms.Button();
			this.treeHierarchy = new System.Windows.Forms.TreeView();
			this.hierarchyIcons = new System.Windows.Forms.ImageList(this.components);
			this.checkOnlyPub = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnLoad
			// 
			this.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnLoad.Location = new System.Drawing.Point(8, 8);
			this.btnLoad.Name = "btnLoad";
			this.btnLoad.TabIndex = 0;
			this.btnLoad.Text = "Load";
			this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
			// 
			// treeHierarchy
			// 
			this.treeHierarchy.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treeHierarchy.ImageList = this.hierarchyIcons;
			this.treeHierarchy.Location = new System.Drawing.Point(16, 40);
			this.treeHierarchy.Name = "treeHierarchy";
			this.treeHierarchy.Size = new System.Drawing.Size(256, 320);
			this.treeHierarchy.TabIndex = 1;
			this.treeHierarchy.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeHierarchy_KeyDown);
			this.treeHierarchy.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeHierarchy_BeforeExpand);
			// 
			// hierarchyIcons
			// 
			this.hierarchyIcons.ImageSize = new System.Drawing.Size(16, 16);
			this.hierarchyIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("hierarchyIcons.ImageStream")));
			this.hierarchyIcons.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// checkOnlyPub
			// 
			this.checkOnlyPub.Checked = true;
			this.checkOnlyPub.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkOnlyPub.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkOnlyPub.Location = new System.Drawing.Point(88, 8);
			this.checkOnlyPub.Name = "checkOnlyPub";
			this.checkOnlyPub.TabIndex = 2;
			this.checkOnlyPub.Text = "Only public";
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label1.Location = new System.Drawing.Point(16, 368);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Press F1 for help on selected class or method.";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 390);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.checkOnlyPub);
			this.Controls.Add(this.treeHierarchy);
			this.Controls.Add(this.btnLoad);
			this.Name = "MainForm";
			this.Text = ".Net Framework Browser";
			this.ResumeLayout(false);

		}
		#endregion

		#region TreeView Utilities

		/// <summary>
		/// Vklada polozku do TreeView a zaradi ji podle abecedy
		/// </summary>
		private void SortedInsert(TreeNodeCollection nodes,TreeNode node,int type)
		{
      SortedInsert(nodes,node,type,false);
		}

		/// <summary>
		/// Vklada polozku do TreeView a zaradi ji podle abecedy a typu
		/// </summary>
		private void SortedInsert(TreeNodeCollection nodes,TreeNode node,int type,bool sortByAllTypes)
		{
			for(int i=0; i<nodes.Count; i++)
			{
				if (((sortByAllTypes||type==0)&&nodes[i].ImageIndex>type)||
						(nodes[i].ImageIndex==type&&
					string.Compare(nodes[i].Text,node.Text)>0))
					{ nodes.Insert(i,node); return; }
			}
			nodes.Add(node);
		}

		#endregion

		/// <summary>
		/// Pridava rekurzivne typ do TreeView vcetne jeho namespaces
		/// </summary>
		/// <param name="nodes">Seznam kam se ma typ zaradit</param>
		/// <param name="nameParts">Casti jmena tridy (rozdelene podle tecky)</param>
		/// <param name="type">Typ ktery se zarazuje do seznamu</param>
		/// <param name="pos">Aktualni pozice v poli nameParts</param>
		/// <returns>Vraci vytvorenou TreeNode</returns>
		private TreeNode AddTreeNode(TreeNodeCollection nodes,string[] nameParts,Type type,int pos)
		{
			// jiz jsme na konci u jmena tridy
			if (pos==nameParts.Length-1)
			{
				// zaradi tridu do TreeView
				TreeNode nd=new TreeNode(nameParts[pos]);
				SortedInsert(nodes,nd,1);
				return nd;
			}
			else
			{
				// vlozit jmeno namespace ..
				TreeNode np=null;
				foreach(TreeNode nd in nodes)
				{
					// pokud jiz v seznamu existuje
					if (nd.Text==nameParts[pos]) 
						{ np=nd; break; }
				}
				if (np==null) 
				{
					// pokud neexistuje prida se
					np=new TreeNode(nameParts[pos]);
					np.ImageIndex=0;
					SortedInsert(nodes,np,0);
				}
				// a rekurzivni volani na dalsi cast jmena
				return AddTreeNode(np.Nodes,nameParts,type,pos+1);
			}
		}


		/// <summary>
		/// Nacita datove typy v assembly a pridava je do seznamu
		/// </summary>
		/// <param name="nodes">Seznam</param>
		/// <param name="asm">Assembly k nacteni</param>
		private void LoadAssemblyTypes(TreeNodeCollection nodes,Assembly asm)
		{
			// prochazi typy v assembly
			foreach(Type t in asm.GetTypes())
			{
				// vlozit typ do seznamu
				string[] nameParts=t.FullName.Split('.');
				if (!t.IsPublic&&checkOnlyPub.Checked) continue;
				TreeNode nd=AddTreeNode(nodes,nameParts,t,0);
				
				// Co je to za typ?
				if (t.BaseType!=null&&(t.BaseType.FullName=="System.MulticastDelegate"||
					t.BaseType.FullName=="System.Delegate"))
					nd.ImageIndex=3; // delegate
				else if (t.IsEnum)
					nd.ImageIndex=4; // enum
				else if (t.IsInterface)
					nd.ImageIndex=5; // interface
				else if (t.IsValueType)
					nd.ImageIndex=2; // struct
				else
					nd.ImageIndex=1; // class
				nd.SelectedImageIndex=nd.ImageIndex;		
				
				// prida jednu child-node a jednotlive metody atd.. 
				// se nactou az pri rozbalovani polozky 
				TreeNode placeholder=new TreeNode("-");
				nd.Nodes.Add(placeholder);
				nd.Tag=t;
			}
		}


		/// <summary>
		/// Nacist typy..
		/// </summary>
		private void btnLoad_Click(object sender, System.EventArgs e)
		{
			string[] assemblies=new string[]
				{"System","mscorlib","System.Data","System.Drawing",
				"System.Management","System.Messaging","System.Runtime.Remoting",
				"System.Security","System.Web","System.Xml","System.Windows.Forms"};
			
			// pro kazdou assembly v seznamu..
			foreach(string name in assemblies)
			{
				LoadAssemblyTypes(treeHierarchy.Nodes,
					Assembly.LoadWithPartialName(name));
			}
		}


		/// <summary>
		/// Pridava ke tride jeji cleny (properties, methods, etc.)
		/// </summary>
		/// <param name="cls">TreeNode s tridou</param>
		/// <param name="type">Typ tridy</param>
		private void AddClassMembers(TreeNode cls,Type type)
		{
			// adresa na MSDN dokumentaci
			string helpUrl=string.Format("http://msdn.microsoft.com/library/en-us/cpref/html/frlrf{0}class{{0}}topic.asp",
				type.FullName.Replace(".",""));

			// Projde vsechny konstruktory..
			foreach(ConstructorInfo ci in type.GetConstructors())
			{
				ParameterInfo[] p=ci.GetParameters();
				string ps="";
				for(int i=0; i<p.Length; i++)
				{
					if (i!=0) ps+=",";
					ps+=p[i].ParameterType.Name+" "+p[i].Name;
				}
				TreeNode nd=new TreeNode(ci.Name+"("+ps+")");
				nd.SelectedImageIndex=nd.ImageIndex=6;
				nd.Tag=string.Format(helpUrl,ci.Name);
				SortedInsert(cls.Nodes,nd,nd.ImageIndex,true);
			}

			// .. udalosti ..
			foreach(EventInfo ei in type.GetEvents())
			{
				TreeNode nd=new TreeNode(ei.Name);
				nd.SelectedImageIndex=nd.ImageIndex=7;
				nd.Tag=string.Format(helpUrl,ei.Name);
				SortedInsert(cls.Nodes,nd,nd.ImageIndex,true);
			}

			// .. fieldy ..
			foreach(FieldInfo fi in type.GetFields())
			{
				if (fi.IsSpecialName) continue;
				TreeNode nd=new TreeNode(fi.Name+" : "+fi.FieldType.Name);
				nd.SelectedImageIndex=nd.ImageIndex=8;
				nd.Tag=string.Format(helpUrl,fi.Name);
				SortedInsert(cls.Nodes,nd,nd.ImageIndex,true);
			}

			// .. metody (i s parametrama) ...
			foreach(MethodInfo mi in type.GetMethods())
			{
				if (mi.IsSpecialName) continue;

				ParameterInfo[] p=mi.GetParameters();
				string ps="";
				for(int i=0; i<p.Length; i++)
				{
					if (i!=0) ps+=",";
					ps+=p[i].ParameterType.Name+" "+p[i].Name;
				}
				TreeNode nd=new TreeNode(mi.Name+"("+ps+")");
				nd.SelectedImageIndex=nd.ImageIndex=9;
				nd.Tag=string.Format(helpUrl,mi.Name);
				SortedInsert(cls.Nodes,nd,nd.ImageIndex,true);
			}

			// .. a properties
			foreach(PropertyInfo pi in type.GetProperties())
			{
				TreeNode nd=new TreeNode(pi.Name+" : "+pi.PropertyType.Name);
				nd.SelectedImageIndex=nd.ImageIndex=10;
				SortedInsert(cls.Nodes,nd,nd.ImageIndex,true);
			}
		}


		/// <summary>
		/// Pred rozbalenim polozky obsahujici tridu - nacist obsah tridy
		/// </summary>
		private void treeHierarchy_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			// Pokud je to trida a obsahuje "placeholder" node
			if (e.Node.ImageIndex!=0&&e.Node.Nodes[0].Text=="-")
			{
				e.Node.Nodes.Clear();
				AddClassMembers(e.Node,(Type)e.Node.Tag);
			}
		}


		/// <summary>
		/// Zobrazit MSDN napovedu.
		/// U tridy je v Tag ulozen Type, ze ktereho se zjisti jmeno tridy
		/// U metod a properties je ulozena primo adresa
		/// </summary>
		private void treeHierarchy_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode==Keys.F1&&treeHierarchy.SelectedNode!=null)
			{
				Type t=treeHierarchy.SelectedNode.Tag as Type;
				string url=treeHierarchy.SelectedNode.Tag as string;

				// je to class - zjistit url
				if (t!=null)
					url=string.Format("http://msdn.microsoft.com/library/en-us/cpref/html/frlrf{0}classtopic.asp",
						t.FullName.Replace(".",""));

				// pokud existuje help zobrazit vychozi prohlizec
				if (url!=null)
					System.Diagnostics.Process.Start(url);
			}
		}
	}
}
