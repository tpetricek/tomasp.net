using System;

namespace UnsafeCodeDemo
{
	// Priklad ukazujici praci s unsafe kodem v C#
	class UnsafeCodeDemo
	{
		// Naplnuje pole bytu primym pristupem do pameti
		// ptr - ukazatel na pole intu
		private unsafe static void UnsafeMethod(int* ptr)
		{
			for(int i=0; i<500; i++)
			{
				*ptr=i; ptr++;
			}
		}

		// Hlavni metoda aplikace
		unsafe static void Main(string[] args)
		{
			// Naplnuje pole integeru cisly
			int[] buffer=new int[500];
			fixed(int* p=buffer)
			{
				UnsafeMethod(p);
			}

			for(int i=0; i<500; i+=10) 
				Console.Write("{0} ",buffer[i]);
			Console.WriteLine("\n");

			// Operator sizeof
			Console.WriteLine("sizeof(char)={0}\n",sizeof(char));

			// Zjisteni velikosti retezce
			string str="Hello world";
			fixed(char* ptr=str)
			{
				int* p=(int*)ptr; p--; 
				Console.WriteLine("Delka '{1}': {0}",*p,str);
			}
		}
	}
}
