using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace UnsafeBitmap
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Generated code

		private System.Windows.Forms.PictureBox picOrig;
		private System.Windows.Forms.PictureBox picNew;
		private System.Windows.Forms.Button btnOpen;
		private System.Windows.Forms.OpenFileDialog openPicture;
		private System.Windows.Forms.CheckBox checkInvert;
		private System.Windows.Forms.CheckBox checkGray;
		private System.Windows.Forms.CheckBox checkBlur;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOpen = new System.Windows.Forms.Button();
			this.picOrig = new System.Windows.Forms.PictureBox();
			this.picNew = new System.Windows.Forms.PictureBox();
			this.openPicture = new System.Windows.Forms.OpenFileDialog();
			this.checkInvert = new System.Windows.Forms.CheckBox();
			this.checkGray = new System.Windows.Forms.CheckBox();
			this.checkBlur = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// btnOpen
			// 
			this.btnOpen.Location = new System.Drawing.Point(8, 8);
			this.btnOpen.Name = "btnOpen";
			this.btnOpen.TabIndex = 0;
			this.btnOpen.Text = "Otev��t..";
			this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
			// 
			// picOrig
			// 
			this.picOrig.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.picOrig.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picOrig.Location = new System.Drawing.Point(8, 40);
			this.picOrig.Name = "picOrig";
			this.picOrig.Size = new System.Drawing.Size(272, 296);
			this.picOrig.TabIndex = 1;
			this.picOrig.TabStop = false;
			// 
			// picNew
			// 
			this.picNew.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left)));
			this.picNew.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picNew.Location = new System.Drawing.Point(288, 40);
			this.picNew.Name = "picNew";
			this.picNew.Size = new System.Drawing.Size(272, 296);
			this.picNew.TabIndex = 2;
			this.picNew.TabStop = false;
			// 
			// openPicture
			// 
			this.openPicture.Filter = "Images|*.jpg;*.jpeg;*.png;*.gif;*.bmp;";
			// 
			// checkInvert
			// 
			this.checkInvert.Location = new System.Drawing.Point(96, 8);
			this.checkInvert.Name = "checkInvert";
			this.checkInvert.TabIndex = 3;
			this.checkInvert.Text = "Invertovat";
			this.checkInvert.Click += new System.EventHandler(this.checkBlur_Click);
			// 
			// checkGray
			// 
			this.checkGray.Location = new System.Drawing.Point(176, 8);
			this.checkGray.Name = "checkGray";
			this.checkGray.TabIndex = 4;
			this.checkGray.Text = "Cernobily";
			this.checkGray.Click += new System.EventHandler(this.checkBlur_Click);
			// 
			// checkBlur
			// 
			this.checkBlur.Location = new System.Drawing.Point(264, 8);
			this.checkBlur.Name = "checkBlur";
			this.checkBlur.TabIndex = 5;
			this.checkBlur.Text = "Rozmazat";
			this.checkBlur.Click += new System.EventHandler(this.checkBlur_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(568, 350);
			this.Controls.Add(this.checkBlur);
			this.Controls.Add(this.checkGray);
			this.Controls.Add(this.checkInvert);
			this.Controls.Add(this.picNew);
			this.Controls.Add(this.picOrig);
			this.Controls.Add(this.btnOpen);
			this.Name = "Form1";
			this.Text = "Main Form";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Upravit velikost obrazku aby zabiraly polovinu okna
		/// </summary>
		private void Form1_Resize(object sender, System.EventArgs e)
		{
			picNew.Width=picOrig.Width=(Width-24)/2;
			picNew.Left=picOrig.Width+8;
		}

		/// <summary>
		/// Otevrit a zpracovat obrazek
		/// </summary>
		private void btnOpen_Click(object sender, System.EventArgs e)
		{
			if (openPicture.ShowDialog()==DialogResult.OK)
			{
				try
				{
					Bitmap bmp=new Bitmap(openPicture.FileName);
					LoadBitmap(bmp);
				}
				catch 
				{
					MessageBox.Show("Nepodarilo se otevrit obrazek");
				}
			}
		}

		/// <summary>
		/// Nacita a zpracovava bitmapu
		/// </summary>
		/// <param name="bmp">Otevrena bitmapa</param>
		private void LoadBitmap(Bitmap bmp)
		{
			// Smazat stare obrazky
			Image old=picOrig.Image;
			picOrig.Image=null;
			if (old!=null&&old!=bmp) old.Dispose();
			old=picNew.Image;
			picNew.Image=null;
			if (old!=null) old.Dispose();

			// Nacist novy
			picOrig.Image=bmp;
			picNew.Image=CreateModifiedBitmap(bmp);
		}


		/// <summary>
		/// Zmena nastaveni
		/// </summary>
		private void checkBlur_Click(object sender, System.EventArgs e)
		{
			if (picOrig.Image==null) return;
			LoadBitmap((Bitmap)picOrig.Image);		
		} 


		/// <summary>
		/// Pocita barvu na dane pozici
		/// </summary>
		/// <param name="ptr">Ukazatel do puvodni bitmapy</param>
		/// <param name="x">X-ova souradnice</param>
		/// <param name="y">Y-ova souradnice</param>
		/// <param name="data">Informace o puvodni bitmape</param>
		/// <returns>Vraci vypoctenou barvu</returns>
		private unsafe Color CalculateColor(int* ptr,int x,int y,BitmapData data)
		{
			Color c=Color.FromArgb(*ptr); 

			// ROZMAZAVANI
			// je potreba udelat jako prvni, protoze cte barvy kolem generovaneho pixelu
			if (checkBlur.Checked)
			{
				int d=2;
				int r=0,g=0,b=0,count=0;

				// Projde ctverec 5x5 kolem aktualniho pixelu..
				for(int dx=-d; dx<=d; dx++)
				{
					if (x+dx<0||x+dx>=data.Width) continue;
					for(int dy=-d; dy<=d; dy++)
					{
						if (y+dy<0||y+dy>=data.Height) continue;

						// .. precte barvu ..
						int* p=(ptr+dx)+dy*data.Stride/sizeof(int);
						
						// a spocita artimeticky prumer v tomto ctverci
						Color tmp=Color.FromArgb(*p); 
						r+=tmp.R; g+=tmp.G; b+=tmp.B;
						count++;
					}
				}
				c=Color.FromArgb(r/count,g/count,b/count);
			}
			

			// CERNOBILA
			if (checkGray.Checked)
			{
				// spocita sedou barvu podle R,G a B
				int nc=(11*c.R+59*c.G+30*c.B)/100; 
				c=Color.FromArgb(nc,nc,nc);
			}


			// INVERZE
			if (checkInvert.Checked)
			{
				// spocita inverzni barvu
				c=Color.FromArgb(255-c.R,255-c.G,255-c.B);
			}

			return c;
		}


		/// <summary>Vytvori cernobilou kopii bitmapy</summary> 
		/// <param name="bmp">Vstupni bitmapa</param> 
		/// <returns>Upravena bitmapa</returns> 
		private unsafe Bitmap CreateModifiedBitmap(Bitmap bmp) 
		{ 
			// Vytvori novou bitmapu, do ktere se bude ukladat nova
			Bitmap ret=new Bitmap(bmp.Width,bmp.Height); 
  
			// zamkne data bitmapy, takze k nim lze primo pristupovat 
			BitmapData data=bmp.LockBits( 
				new Rectangle(0,0,bmp.Width,bmp.Height), 
				ImageLockMode.ReadOnly,PixelFormat.Format32bppArgb); 
			BitmapData retData=ret.LockBits( 
				new Rectangle(0,0,bmp.Width,bmp.Height), 
				ImageLockMode.WriteOnly,PixelFormat.Format32bppArgb); 
  
			// prochazi postupne po radcich 
			for(int y=0; y<data.Height; y++) 
			{ 
				// vypocita pozice, kde zacinaji data daneho radku 
				int* pos=(int*)((int)data.Scan0+(y*data.Stride)); 
				int* retPos=(int*)((int)retData.Scan0+(y*retData.Stride)); 
  
				int x=0;
				while(x<data.Width) 
				{ 
					// vypocitat novou barvu 
					*retPos=CalculateColor(pos,x,y,data).ToArgb(); 
					pos++; retPos++; x++;
				} 
			} 
  
			// uvolni data bitmapy 
			bmp.UnlockBits(data); 
			ret.UnlockBits(retData); 
			return ret; 
		}
	}
}
