﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using RssFeedsLibrary;

public partial class _Default : System.Web.UI.Page 
{
    protected void ButtonClicked(object sender, EventArgs e)
    {
			var fs = new FeedSearch(txtKeywords.Text);
			var res = fs.Search(
				new string[] {
					"http://blogs.msdn.com/MainFeed.aspx?Type=AllBlogs",
					"http://msmvps.com/blogs/MainFeed.aspx",
					"http://weblogs.asp.net/MainFeed.aspx",
				});
			rptContent.DataSource = res;
			rptContent.DataBind();
    }
}
