﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EeekSoft.Functional.Events;

namespace EventOperators.CSharp
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();


			FirstExample();
			// SecondExample();			
			// ThirdExample();
			// FourthExample();
			// FifthExample();
			// SixthExample();
		}

		private void FirstExample()
		{
			// First example 
			btnClick.AttachEvent("Click")
				.Select(ea => 1).Sum()
				.Aggregate(1, (total, current) => total * current)
				.Listen(n =>
					lblOut.Text = String.Format("Current count is: {0}", n));
		}

		private void SecondExample()
		{
			// Second example
			var eZigZag =
				Reactive.Merge
					(checkDecrement.AttachEvent("Click"),
					 Reactive.After(1000, EventArgs.Empty))
				.Aggregate(-1, (current, ea) => current * -1);

			eZigZag.SwitchRepeatedly(n =>
						from ea in btnClick.AttachEvent("Click") select n)
				.Sum()
				.Listen(n => lblOut.Text = String.Format("Current count is: {0}", n));
		}

		private void ThirdExample()
		{
			// Third example
			btnClick.AttachEvent("Click").Select(_ => "Clicked for the first time!")
				.SwitchFirst(s =>
					btnClick.AttachEvent("Click").Select(_ => 1).Sum().Select(n => string.Format("Clicked {0} times!", n)))
				.Listen(s => lblOut.Text = s);
		}

		private void FourthExample()
		{
			// Fourth example
			Func<IEvent<string>> eClickOrTimeout = null;
			eClickOrTimeout = () =>
				// Triggered when user clicks on the button or after 5 seconds
				Reactive.Merge
					(btnClick.AttachEvent("Click").Select(_ => "Click..."),
					 Reactive.After(5000, "Timeout!"))
				.SwitchFirst(e => eClickOrTimeout());

			eClickOrTimeout().Listen(s => lblOut.Text = s);
		}

		private void FifthExample()
		{
			// Fifth example
			Reactive.After(1000, "")
				.SwitchRecursive(s =>
						Reactive.Merge
							(from e in btnClick.AttachEvent("Click") select "click",
							 from e in Reactive.Repeatedly(5000, EventArgs.Empty) select "timeout"))
				.Listen(s => lblOut.Text = s);
		}

		private void SixthExample()
		{
			// Sixth example
			(from n in
				 Reactive.Merge(Reactive.After(1000, EventArgs.Empty),
												checkDecrement.AttachEvent("Click"))
					.Aggregate(1, (current, _) => current * -1)
			 from m in btnClick.AttachEvent("Click").UseSwitchRepeatedly()
			 select -1 * n)
			 .Sum().Listen(n =>
					lblOut.Text = String.Format("Current count is: {0}", n));
		}
	}
}
