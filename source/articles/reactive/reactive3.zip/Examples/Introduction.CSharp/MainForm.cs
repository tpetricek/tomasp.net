﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

using EeekSoft.Functional;
using EeekSoft.Functional.Events;

namespace ChapterUnkFRP
{	
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void Main_Load(object sender, EventArgs ea)
		{
			Cursor.Position = this.PointToScreen(new Point(150, 200));
			Bitmap bmp = (Bitmap)this.BackgroundImage;

			// Cursor moved out of the path
			var eOut =
				from me in this.AttachEvent<MouseEventArgs>("MouseMove")
				let clr = bmp.GetPixel(me.X, me.Y)
				where clr.R != 255 || clr.G != 255 || clr.B != 255
				select "Oops!\nYou stepped on the grass!";

			// Cursor is close to the end
			var eFinish =
				from me in this.AttachEvent<MouseEventArgs>("MouseMove")
				let dist = Math.Pow(450 - me.X, 2) + Math.Pow(250 - me.Y, 2)
				where dist < 250
				select "Congratulations!\nYou made it to the end!";

			var eMerged = Reactive.Merge(eOut, eFinish);
			eMerged.First().Listen(str => MessageBox.Show(str));
		}
	}
}
