﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EeekSoft.Functional
{
	public class Tuple<TFirst, TSecond>
	{
		private readonly TFirst first;
		private readonly TSecond second;

		public TFirst First
		{
			get { return first; }
		}
		public TSecond Second
		{
			get { return second; }
		}

		public Tuple(TFirst first, TSecond second)
		{
			this.first = first;
			this.second = second;
		}

		public static readonly Func<Tuple<TFirst, TSecond>, TFirst> Fst = (t) => t.First;
		public static readonly Func<Tuple<TFirst, TSecond>, TSecond> Snd = (t) => t.Second;
	}

	public static class Tuple
	{
		public static Tuple<TFirst, TSecond> New<TFirst, TSecond>(TFirst first, TSecond second)
		{
			return new Tuple<TFirst, TSecond>(first, second);
		}
	}
}
