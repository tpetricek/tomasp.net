﻿#define TRACE_LIVING
#define TRACE_VERBOSE

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using System.Diagnostics;

namespace EeekSoft.Functional.Events
{
	public class EventLogging
	{
		internal static int id = 0;
		internal static int living = 0;

		public static int Living { get { return living; } }

		[Conditional("TRACE_LIVING")]
		internal static void WriteLine(string type, string format, params object[] args)
		{
#if !TRACE_VERBOSE
			if (type != "FINALIZE") return;
#endif
			Debug.WriteLine(String.Format(format, args));
		}
	}


	public interface IEvent
	{
		void Stop();
	}

	public interface IEvent<T> : IEvent
	{
		void Add(Action<T> handler);
		void Remove(Action<T> handler);
	}

	#region Different SelectMany implementations

	public interface IEventSwitchFirst<T> : IEvent<T> { }
	public interface IEventSwitchRepeatedly<T> : IEvent<T> { }
	public interface IEventSwitchRecursive<T> : IEvent<T> { }

	class EventSwitchRecursive<T> : IEventSwitchRecursive<T>
	{
		IEvent<T> evt;

		public EventSwitchRecursive(IEvent<T> evt)
		{
			this.evt = evt;
		}

		public void Add(Action<T> handler)
		{
			evt.Add(handler);
		}

		public void Remove(Action<T> handler)
		{
			evt.Remove(handler);
		}

		public void Stop()
		{
			evt.Stop();
		}
	}

	class EventSwitchRepeatedly<T> : IEventSwitchRepeatedly<T>
	{
		IEvent<T> evt;

		public EventSwitchRepeatedly(IEvent<T> evt)
		{
			this.evt = evt;
		}

		public void Add(Action<T> handler)
		{
			evt.Add(handler);
		}

		public void Remove(Action<T> handler)
		{
			evt.Remove(handler);
		}

		public void Stop()
		{
			evt.Stop();
		}
	}

	class EventSwitchFirst<T> : IEventSwitchFirst<T>
	{
		IEvent<T> evt;

		public EventSwitchFirst(IEvent<T> evt)
		{
			this.evt = evt;
		}

		public void Add(Action<T> handler)
		{
			evt.Add(handler);
		}

		public void Remove(Action<T> handler)
		{
			evt.Remove(handler);
		}

		public void Stop()
		{
			evt.Stop();
		}
	}

	#endregion

	// PRIVATE


	class EventStd<T> : IEvent<T>
	{
		EventInfo ei;
		object owner;
		MethodInfo closureInvoke;
		Dictionary<Action<T>, Delegate> createdDelegates;

		public EventStd(object owner, string name)
		{
			closureInvoke = typeof(Closure).GetMethod("Invoke", BindingFlags.Public | BindingFlags.Instance);

			createdDelegates = new Dictionary<Action<T>, Delegate>();
			ei = owner.GetType().GetEvent(name);
			this.owner = owner;
		}

		class Closure
		{
			Action<T> f;
			EventStd<T> owner;

			public Closure(EventStd<T> owner, Action<T> f)
			{
				this.f = f;
				this.owner = owner;
			}

			public void Invoke(object sender, T e)
			{
				f(e);
				EventLogging.WriteLine("INVOKE", "EventStd({0}), count={1}", owner.ei.Name, owner.createdDelegates.Count);
			}
		}

		public void Add(Action<T> fh)
		{
			var eh = Delegate.CreateDelegate(ei.EventHandlerType, new Closure(this, fh), closureInvoke);
			createdDelegates.Add(fh, eh);
			ei.AddEventHandler(owner, eh);
			EventLogging.WriteLine("ADD", "EventStd({0}), count={1}", ei.Name, createdDelegates.Count);
		}

		public void Remove(Action<T> fh)
		{
			ei.RemoveEventHandler(owner, createdDelegates[fh]);
			createdDelegates.Remove(fh);
			EventLogging.WriteLine("REMOVE", "EventStd({0}), count={1}", ei.Name, createdDelegates.Count);
		}

		public void Stop()
		{
			foreach(var h in createdDelegates.Values)
				ei.RemoveEventHandler(owner, h);
		}
	}

	class EventCns<T> : IEvent<T>
	{
		List<Action<T>> handlers;
		Action cleanup;


		int myid = 0;

#if TRACE_LIVING
		~EventCns()
		{
			EventLogging.living--;
			EventLogging.WriteLine("FINALIZE", "EventCns({0}), Living: {1}", myid, EventLogging.living);
		}
#endif

		private EventCns(Action cleanup)
		{
#if TRACE_LIVING
			EventLogging.living++;
			myid = EventLogging.id++;
#endif

			this.cleanup = cleanup;
			handlers = new List<Action<T>>();
		}

		public static Tuple<IEvent<T>, Action<T>> Create(Action cleanup)
		{
			var evt = new EventCns<T>(cleanup);

			// ToArray here, because the collection can be modified ..
			return Tuple.New<IEvent<T>, Action<T>>(evt, (arg) => {
					EventLogging.WriteLine("INVOKE", "EventCns({0}), count={1}", evt.myid, evt.handlers.Count);
					foreach (var h in evt.handlers.ToArray()) 
						h(arg); 
				});
		}

		public void Add(Action<T> handler)
		{
			handlers.Add(handler);
			EventLogging.WriteLine("ADD", "EventCns({0}), count={1}", myid, handlers.Count);
		}

		public void Remove(Action<T> handler)
		{
			handlers.Remove(handler);
			EventLogging.WriteLine("REMOVE", "EventCns({0}), count={1}", myid, handlers.Count);

			if (handlers.Count == 0)
				cleanup();
		}

		public void Stop()
		{
			handlers.Clear();
			cleanup();
		}
}


	// PUBLIC


	public static class EventUtils
	{
		// only for winforms ?

/*
    public static IEvent<EventArgs> Event(this Control owner, string name)
		{
			return new EventStd<EventArgs>(owner, name);
		}

		public static IEvent<T> Event<T>(this Control owner, string name) // where T : Delegate
		{
			return new EventStd<T>(owner, name);
		}
*/
		public static IEvent<EventArgs> AttachEvent(this Control owner, string name)
		{
			return new EventStd<EventArgs>(owner, name);
		}

		public static IEvent<T> AttachEvent<T>(this Control owner, string name) // where T : Delegate
		{
			return new EventStd<T>(owner, name);
		}
	}

	public static class Reactive
	{
		// CREATE etc.

		public static IEvent<EventArgs> Attach(object owner, string name)
		{
			return new EventStd<EventArgs>(owner, name);
		}

		public static IEvent<T> Attach<T>(object owner, string name)
		{
			return new EventStd<T>(owner, name);
		}

		public static Tuple<IEvent<T>, Action<T>> Create<T>(Action cleanup)
		{
			return EventCns<T>.Create(cleanup);
		}

		/*
		public static IEvent<T> Once<T>(double interval, T value)
		{
			return Repeatedly(interval, null).Select(_ => value).First();
		}

		public static IEvent<DateTime> Once(double interval)
		{
			return Repeatedly(interval, null).First();
		}
		*/
		public static IEvent<DateTime> Repeatedly(double interval)
		{
			var tmr = new System.Timers.Timer(interval);
			var t = Create<DateTime>(() => {
					tmr.Enabled = false;
					tmr.Dispose();
				});

			Action<DateTime> fElapsed = (st) => {
						Action f = () => t.Second(st);
						if (Application.OpenForms.Count > 0)
							Application.OpenForms[0].Invoke(f);
						else
							f();
					};

			tmr.Elapsed += (_, e) => fElapsed(e.SignalTime);
			tmr.Enabled = true;
			return t.First;			
		}

		public static IEvent<T> After<T>(double interval, T value)
		{
			return After(interval).Select(_ => value);
		}

		public static IEvent<T> Repeatedly<T>(double interval, T value)
		{
			return Repeatedly(interval).Select(_ => value);
		}

		public static IEvent<DateTime> After(double interval)
		{
			var tmr = new System.Timers.Timer(interval);
			var t = Create<DateTime>(() => {
					tmr.Enabled = false;
					tmr.Dispose();
				});

			Action<DateTime> fElapsed = (st) => {
					Action f = () => t.Second(st);
					if (Application.OpenForms.Count > 0)
						Application.OpenForms[0].Invoke(f);
					else
						f();
				};

			tmr.Elapsed += (_, e) => {
					fElapsed(e.SignalTime);
					tmr.Enabled = false;
					tmr.Dispose(); 
				};
			tmr.Enabled = true;
			return t.First;
		}

		public static IEvent<T> Never<T>()
		{
			var t = Create<T>(() => { });
			return t.First;
		}

		// ??

		// Recursive switch
		public static IEvent<T> SwitchRecursive<T>(this IEvent<T> ev, Func<T, IEvent<T>> switchFunc)
		{
			Func<IEvent<T>, IEvent<T>> doSwitch = null;
			doSwitch = (src) => src.SwitchFirst(v => doSwitch(switchFunc(v)));
			return doSwitch(ev);
		}

		// not efficient at all! I think...
		// do some optimization for recursive SwitchFirsts... yuck

		public static IEvent<T> SwitchFirst<T>(this IEvent<T> evt, Func<T, IEvent<T>> switchFunc)
		{
			IEvent<T> switchedTo = null;
			Action<T> forwarder = null;

			var result = Create<T>(() => { if (switchedTo != null) switchedTo.Remove(forwarder); });
			forwarder = (v) => result.Second(v);

			Action<T> handler = null;
			handler = (v) =>
			{
				// evt.Remove(handler); removed by 'First'
				result.Second(v);
				var prev = switchedTo;
				switchedTo = switchFunc(v);
				switchedTo.Add(forwarder);
				// do this after.. switchFunc can use the same value again!
				if (prev != null) { prev.Remove(forwarder); }
			};
			evt.First().Add(handler); // first here - no need for it later

			return result.First;
		}

		// ??

		public static IEvent<Tuple<T,R>> SwitchRepeatedlyRemember<R, T>(this IEvent<T> evt, Func<T, IEvent<R>> switchFunc)
		{
			Action<T> handler = null;
			var result = Create<Tuple<T,R>>(() => { evt.Remove(handler); });

			Action<R> forwarder = null;

			IEvent<R> last = null;
			handler = (v) =>
			{
				IEvent<R> current = switchFunc(v);
				if (last != null) last.Remove(forwarder);
				last = current;

				forwarder = (v2) => result.Second(Tuple.New(v, v2));
				current.Add(forwarder);
			};

			evt.Add(handler);
			return result.First;
		}

		public static IEvent<R> SwitchRepeatedly<R, T>(this IEvent<T> evt, Func<T, IEvent<R>> switchFunc)
		{
			return evt.SwitchRepeatedlyRemember(switchFunc).Select(t => t.Second);
		}

		// Select many

		public static IEventSwitchFirst<T> UseSwitchFirst<T>(this IEvent<T> e)
		{
			return new EventSwitchFirst<T>(e);
		}

		public static IEventSwitchRepeatedly<T> UseSwitchRepeatedly<T>(this IEvent<T> e)
		{
			return new EventSwitchRepeatedly<T>(e);
		}

		public static IEventSwitchRecursive<T> UseSwitchRecursive<T>(this IEvent<T> e)
		{
			return new EventSwitchRecursive<T>(e);
		}

		public static IEvent<R> SelectMany<T, R>(this IEvent<T> source, Func<T, IEventSwitchRecursive<T>> sel, Func<T, T, R> selRes)
		{
			return source.SwitchRecursive(t => sel(t)).Select(t => selRes(t,t));
		}

		public static IEvent<R> SelectMany<T, S, R>(this IEvent<T> source, Func<T, IEventSwitchRepeatedly<S>> sel, Func<T, S, R> selRes)
		{
			return source.SwitchRepeatedlyRemember(t => sel(t)).Select(t => selRes(t.First, t.Second));
		}

		public static IEvent<R> SelectMany<T, R>(this IEvent<T> source, Func<T, IEventSwitchFirst<T>> sel, Func<T, T, R> selRes)
		{
			return source.SwitchFirst(t => sel(t)).Select(t => selRes(t, t));
		}

		public static IEvent<T> Take<T>(this IEvent<T> a, int count)
		{
			int countSoFar = 0;
			Action<T> handler = null;

			var t = Create<T>( () => {
					if (countSoFar < count) a.Remove(handler);
				});

			handler = (e) => {
					countSoFar++;
					if (countSoFar <= count) 
					{
						t.Second(e);
						// free after call!
						if (countSoFar == count) 
							a.Remove(handler);
					}
				};

			a.Add(handler);
			return t.First;
		}

		public static IEvent<T> First<T>(this IEvent<T> a)
		{
			return a.Take(1);
		}

		// FUNCTIONS ..

		public static IEvent<T> Merge<T>(IEvent<T> a, IEvent<T> b)
		{
			Tuple<IEvent<T>, Action<T>> t = null;
			t = Create<T>(() => {
					a.Remove(t.Second);
					b.Remove(t.Second);
				});
			a.Add(t.Second);
			b.Add(t.Second);
			return t.First;
		}

		public static void Listen<T>(this IEvent<T> ev, Action<T> handler)
		{
			ev.Add(handler);
		}

		public static IEvent<T> Pass<T>(this IEvent<T> ev, Action<T> f)
		{
			Tuple<IEvent<T>, Action<T>> t = null;
			Action<T> handler = (arg) => { f(arg); t.Second(arg); };
			t = Create<T>(() => ev.Remove(handler));
			ev.Add(handler);
			return t.First;
		}

		// LINQ

		public static IEvent<TResult> Select<T, TResult>(this IEvent<T> ev, Func<T, TResult> mapf)
		{
			Tuple<IEvent<TResult>, Action<TResult>> t = null;
			Action<T> handler = (arg) => t.Second(mapf(arg));
			t = Create<TResult>( () => ev.Remove(handler) );
			ev.Add(handler);
			return t.First;
		 }

		public static IEvent<T> Where<T>(this IEvent<T> ev, Func<T, bool> filterf)
		{
			Tuple<IEvent<T>, Action<T>> t = null;
			Action<T> handler = (arg) => { if (filterf(arg)) t.Second(arg); };
			t = Create<T>( () => ev.Remove(handler) );
			ev.Add(handler);
			return t.First;
		}

		public static IEvent<TAcc> Aggregate<T, TAcc>(this IEvent<T> source, TAcc seed, Func<TAcc, T, TAcc> func)
		{
			Tuple<IEvent<TAcc>, Action<TAcc>> t = null;
			var state = seed;
			Action<T> handler = st => { state = func(state, st); t.Second(state); };

			t = Create<TAcc>( () => source.Remove(handler) );
			source.Add(handler);
			return t.First;
		}

		// Aggregates

		public static IEvent<int> Sum<TSource>(this IEvent<TSource> source, Func<TSource, int> selector)
		{
			return source.Aggregate(0, (a, b) => a + selector(b));
		}

		public static IEvent<double> Sum<TSource>(this IEvent<TSource> source, Func<TSource, double> selector)
		{
			return source.Aggregate(0.0, (a, b) => a + selector(b));
		}

		public static IEvent<int> Sum(this IEvent<int> source)
		{
			return source.Aggregate(0, (a, b) => a + b);
		}

		public static IEvent<double> Sum(this IEvent<double> source)
		{
			return source.Aggregate(0.0, (a, b) => a + b);
		}

	}
}
