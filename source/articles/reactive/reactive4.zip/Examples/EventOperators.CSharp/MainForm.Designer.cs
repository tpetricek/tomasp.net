﻿namespace EventOperators.CSharp
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.checkDecrement = new System.Windows.Forms.CheckBox();
			this.btnClick = new System.Windows.Forms.Button();
			this.lblOut = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// checkDecrement
			// 
			this.checkDecrement.AutoSize = true;
			this.checkDecrement.Location = new System.Drawing.Point(109, 16);
			this.checkDecrement.Name = "checkDecrement";
			this.checkDecrement.Size = new System.Drawing.Size(92, 17);
			this.checkDecrement.TabIndex = 0;
			this.checkDecrement.Text = "Decrementing";
			this.checkDecrement.UseVisualStyleBackColor = true;
			// 
			// btnClick
			// 
			this.btnClick.Location = new System.Drawing.Point(17, 12);
			this.btnClick.Name = "btnClick";
			this.btnClick.Size = new System.Drawing.Size(75, 23);
			this.btnClick.TabIndex = 1;
			this.btnClick.Text = "Click me!";
			this.btnClick.UseVisualStyleBackColor = true;
			// 
			// lblOut
			// 
			this.lblOut.AutoSize = true;
			this.lblOut.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.lblOut.Location = new System.Drawing.Point(14, 47);
			this.lblOut.Name = "lblOut";
			this.lblOut.Size = new System.Drawing.Size(152, 23);
			this.lblOut.TabIndex = 2;
			this.lblOut.Text = "Current count is: 0";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(235, 100);
			this.Controls.Add(this.lblOut);
			this.Controls.Add(this.btnClick);
			this.Controls.Add(this.checkDecrement);
			this.Name = "MainForm";
			this.Text = "Demo";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox checkDecrement;
		private System.Windows.Forms.Button btnClick;
		private System.Windows.Forms.Label lblOut;
	}
}

