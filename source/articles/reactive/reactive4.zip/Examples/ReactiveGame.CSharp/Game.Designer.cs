﻿namespace ReactiveGame.CSharp
{
	partial class Game
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
			this.lblTime = new System.Windows.Forms.Label();
			this.lblScore = new System.Windows.Forms.Label();
			this.picSmiley = new System.Windows.Forms.PictureBox();
			this.Label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.picSmiley)).BeginInit();
			this.SuspendLayout();
			// 
			// lblTime
			// 
			this.lblTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.lblTime.BackColor = System.Drawing.SystemColors.ControlDark;
			this.lblTime.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.lblTime.ForeColor = System.Drawing.SystemColors.ControlLight;
			this.lblTime.Location = new System.Drawing.Point(501, 0);
			this.lblTime.Name = "lblTime";
			this.lblTime.Size = new System.Drawing.Size(95, 20);
			this.lblTime.TabIndex = 6;
			this.lblTime.Text = "Time: 20";
			this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblScore
			// 
			this.lblScore.BackColor = System.Drawing.SystemColors.ControlDark;
			this.lblScore.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.lblScore.ForeColor = System.Drawing.SystemColors.ControlLight;
			this.lblScore.Location = new System.Drawing.Point(0, 0);
			this.lblScore.Name = "lblScore";
			this.lblScore.Size = new System.Drawing.Size(94, 20);
			this.lblScore.TabIndex = 5;
			this.lblScore.Text = "Score: 0";
			this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// picSmiley
			// 
			this.picSmiley.Image = ((System.Drawing.Image)(resources.GetObject("picSmiley.Image")));
			this.picSmiley.Location = new System.Drawing.Point(75, 34);
			this.picSmiley.Name = "picSmiley";
			this.picSmiley.Size = new System.Drawing.Size(100, 100);
			this.picSmiley.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.picSmiley.TabIndex = 4;
			this.picSmiley.TabStop = false;
			// 
			// Label1
			// 
			this.Label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
									| System.Windows.Forms.AnchorStyles.Right)));
			this.Label1.BackColor = System.Drawing.SystemColors.ControlDark;
			this.Label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
			this.Label1.ForeColor = System.Drawing.SystemColors.ControlLight;
			this.Label1.Location = new System.Drawing.Point(80, 0);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(439, 20);
			this.Label1.TabIndex = 7;
			this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Game
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(596, 475);
			this.Controls.Add(this.lblTime);
			this.Controls.Add(this.lblScore);
			this.Controls.Add(this.picSmiley);
			this.Controls.Add(this.Label1);
			this.Name = "Game";
			this.Text = "Game";
			this.Load += new System.EventHandler(this.Game_Load);
			((System.ComponentModel.ISupportInitialize)(this.picSmiley)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		internal System.Windows.Forms.Label lblTime;
		internal System.Windows.Forms.Label lblScore;
		internal System.Windows.Forms.PictureBox picSmiley;
		internal System.Windows.Forms.Label Label1;

	}
}

