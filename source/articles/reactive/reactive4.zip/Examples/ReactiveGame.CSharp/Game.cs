﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EeekSoft.Functional.Events;

namespace ReactiveGame.CSharp
{
	public partial class Game : Form
	{
		public Game()
		{
			InitializeComponent();
		}

		private void Game_Load(object sender, EventArgs ea)
    {
			// Display number of clicks
			var eClicked = 
				(from md in picSmiley.AttachEvent<MouseEventArgs>("MouseDown") 
				 where md.Button == MouseButtons.Left 
				 where Math.Pow(picSmiley.Width / 2 - md.X, 2) + 
								Math.Pow(picSmiley.Height / 2 - md.Y, 2) < 2250
				 select 1).Sum().Pass(sum => 
					 lblScore.Text = String.Format("Score: {0}", sum));

			// Moves the smiley every time the user clicked on it or after specified time
			var rnd = new Random();
			var eMoveSmiley = 
			 (from e in Reactive.After(1000, 0) 
				from s in Reactive.Merge(eClicked, Reactive.After(600.0, 0)).UseSwitchRecursive() 
				select new Point 
						(rnd.Next(ClientSize.Width - picSmiley.Width), 
						 20 + rnd.Next(ClientSize.Height - picSmiley.Height - 20)))
				.Pass(pos => picSmiley.Location = pos);

			// Count-down timer, shows the time on a label
			var start = DateTime.Now;
			(from e in Reactive.Repeatedly(1000) 
			 let sec = 20 - e.Subtract(start).TotalSeconds 
			 select new { Time = sec, Message = 
					 String.Format("Time: {0}", (int)sec) })
			 .Pass(s => lblTime.Text = s.Message)
			 .Where(t => t.Time <= 0).First()
			 .Listen(_ => {
					 eClicked.Stop();
					 eMoveSmiley.Stop();
					 MessageBox.Show("Game over!\n" + lblScore.Text);
				 });
		}
	}
}
