﻿Imports System.Windows.Forms
Imports EeekSoft.Functional.Events

Public Class Game

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal eargs As System.EventArgs) Handles MyBase.Load

    ' Display number of clicks
    Dim eClicked = _
      Aggregate md In PicSmiley.AttachEvent(Of MouseEventArgs)("MouseDown") _
      Where md.Button = MouseButtons.Left _
      Where Math.Pow(PicSmiley.Width / 2 - md.X, 2) + _
            Math.Pow(PicSmiley.Height / 2 - md.Y, 2) < 2250 _
      Into Sum(1)
    eClicked.Listen(Function(sum) SetText(LblScore, String.Format("Score: {0}", sum)))

    ' Moves the smiley every time the user clicked on it or after specified time
    Dim rnd = New Random()
    Dim eMoveSmiley = _
      From e In Reactive.After(1000, 0) _
      From s In Reactive.Merge(eClicked, Reactive.After(600.0, 0)).UseSwitchRecursive() _
      Select New Point _
          (rnd.Next(ClientSize.Width - PicSmiley.Width), _
           20 + rnd.Next(ClientSize.Height - PicSmiley.Height - 20))
    eMoveSmiley.Listen(AddressOf MoveSmiley)

    ' Count-down timer, shows the time on a label
    Dim start = DateTime.Now
    Dim eCountDown = _
      From e In Reactive.Repeatedly(1000) _
      Let sec = 20 - e.Subtract(start).TotalSeconds _
      Select New With _
        {.Time = sec, .Message = _
         String.Format("Time: {0}", CType(sec, Integer))}
    eCountDown.Listen(Function(s) SetText(LblTime, s.Message))

    ' Stop the game when time is less then zero
    eCountDown _
      .Where(Function(t) t.Time <= 0) _
      .Listen(Function() StopGame(eClicked, eMoveSmiley, eCountDown))

  End Sub

  Function StopGame(ByVal ParamArray events As IEvent()) As Integer
    For Each e In events
      e.Stop()
    Next
    MessageBox.Show("Game over!" + vbNewLine + LblScore.Text)
    Return 0
  End Function

  Sub MoveSmiley(ByVal pos As Point)
    PicSmiley.Location = pos
  End Sub

  Function SetText(ByVal lbl As Label, ByVal str As String) As Integer
    lbl.Text = str
    Return 0
  End Function

End Class
