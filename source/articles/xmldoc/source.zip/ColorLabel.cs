using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Data;
using System.Windows.Forms;

namespace XmlDocDemo
{
	/// <summary>
	///		Ovladaci prvek, ktery vypisuje dany text. Pozadi muze 
	///		byt dvoubarevny prechod a na prvek lze kreslit hvezdicky.
	///		<para> Tento ovladaci prvek je podobny prvku <see cref="Label"/>,
	///		ale umoznuje navic nastavit barevny prechod na pozadi a pridavat
	///		na prvek hvezdicky pomoci metody <see cref="AddStar"/>.
	/// </para>
	/// </summary>
	/// <include file='doc.xml' path='/documentation/member[@name="ColorLabel"]'/>
	public class ColorLabel : Control
	{
		#region Private fields

		private Color _textColor;
		private Color _starColor;
		private Color _topColor;
		private Color _bottomColor;
		private ArrayList _stars;

		private static Random _rndGen;

		#endregion

		#region Constructors

		/// <summary>
		/// Inicializuje generator nahodnych cisel pouzivany v ColorLabel
		/// </summary>
		/// <remarks>
		/// Generator je ukladan staticky, aby se pri vytvoreni
		/// nekolika ovladacich prvku naraz negenrovala nahodna cisla stejne
		/// </remarks>
		static ColorLabel()
		{
			_rndGen=new Random();
		}


		/// <summary>
		/// Nastavuje vychozi barvy ovladaciho prvku
		/// </summary>
		public ColorLabel()
		{
			_topColor=SystemColors.ActiveCaption;
			_textColor=SystemColors.ActiveCaptionText;
			_bottomColor=SystemColors.Control;
			_starColor=SystemColors.InactiveCaptionText;
			_stars=new ArrayList();
		}

		#endregion
		#region Properties

		/// <summary>
		/// Nastavuje nebo zjistuje barvu textu
		/// </summary>
		public Color TextColor
		{
			get { return _textColor; }
			set 
			{ 
				_textColor=value; 
				Refresh();
			}
		}


		/// <summary>
		/// Nastavuje nebo zjistuje horni barvu pozadi
		/// </summary>
		public Color TopColor
		{
			get { return _topColor; }
			set 
			{ 
				_topColor=value; 
				Refresh();
			}
		}


		/// <summary>
		/// Nastavuje nebo zjistuje dolni barvu pozadi
		/// </summary>
		public Color BottomColor
		{
			get { return _bottomColor; }
			set 
			{ 
				_bottomColor=value; 
				Refresh();
			}
		}

		#endregion
		#region Public methods

		/// <summary>
		///		Pridava hvezdicku na nahodnou pozici v ovladacim prvku
		/// </summary>
		/// <remarks>
		///		Tato metoda je obdobna nasledujicimu kodu:
		///		<code>
		///		Random rnd=new Random();
		///		lbl.AddStar(new Point(rnd.Next(lbl.Width),rnd.Next(lbl.Height)));
		///		</code>
		/// </remarks>
		public void AddStar()
		{
			AddStar(new Point(_rndGen.Next(Width),_rndGen.Next(Height)));
		}

		/// <summary>
		/// Pridava hvezdicku na pozici urcenou parametrem <paramref name="position" />
		/// </summary>
		/// <param name="position">Pozice hvezdicky v pixelech</param>
		/// <exception cref="ArgumentException">Vyjimka je vyhozena pokud jsou obe souradnice rovny nule.</exception>
		public void AddStar(Point position)
		{
			if (position.X==0&&position.Y==0) 
				throw new ArgumentException("Souradnice nesmi byt obe rovny nule.");

			if (position.X<0) position.X=0;
			if (position.X>Width-20) position.X=Width-20;
			if (position.Y<0) position.Y=0;
			if (position.Y>Height-20) position.Y=Height-20;
			
			_stars.Add(position);
			Refresh();
		}

		#endregion

		#region Implementation

		/// <summary>
		/// Vykresluje ovladaci prvek (podle zadaneho nastaveni)
		/// </summary>
		/// <param name="e">Informace pro udalost</param>
		protected override void OnPaint(PaintEventArgs e)
		{
			Rectangle rc=new Rectangle(0,0,Width,Height);
			using(Brush br=new LinearGradientBrush(rc,_topColor,_bottomColor,90))
				e.Graphics.FillRectangle(br,rc);

			using(Brush br=new SolidBrush(_textColor))
			{
				StringFormat sf=new StringFormat();
				sf.Alignment=StringAlignment.Center;
				sf.LineAlignment=StringAlignment.Center;
				e.Graphics.DrawString(Text,Font,br,rc,sf);
			}
			using(Font fnt=new Font(FontFamily.GenericMonospace,20,FontStyle.Bold))
			{
				using(Brush br=new SolidBrush(_starColor))
				{
					foreach(Point pt in _stars)
						e.Graphics.DrawString("*",fnt,br,pt.X-5,pt.Y-5);
				}
			}

			base.OnPaint (e);
		}

		#endregion
	}
}
