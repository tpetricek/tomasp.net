﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.ParallelArrays;

namespace CSharpIntroduction
{
  class Program
  {
    static void Main(string[] args)
    {
      var rnd = new Random();
      var nums = 
        (from n in Enumerable.Range(0, 10)
         select (float)rnd.Next(10)).ToArray();

      // Build a computation that calculates average of neigbors 
      var input = new FloatParallelArray(nums);
      var sum = 
        ParallelArrays.Shift(input, 1) + input + 
        ParallelArrays.Shift(input, -1);
      var output = sum / 3.0f;

      // Run the computation
      var target = new DX9Target();
      var res = target.ToArray1D(output);

      // Output the original data and calculated 'blurred' result
      Action<float[]> WriteArray = (vals) =>
        Console.WriteLine(vals.Aggregate("", (str, f) => str + Math.Round(f) + ", "));

      WriteArray(nums);
      WriteArray(res);      
    }
  }
}
