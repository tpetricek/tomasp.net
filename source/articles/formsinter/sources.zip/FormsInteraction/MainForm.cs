using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace FormsInteraction
{
	/// <summary>
	/// Hlavni okno aplikace, ktere obsahuje tlacitka na otevreni
	/// a zavreni panelu s nastroji
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		#region Standardni generovany kod

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnShow = new System.Windows.Forms.Button();
			this.btnHide = new System.Windows.Forms.Button();
			this.colorBox = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// btnShow
			// 
			this.btnShow.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnShow.Location = new System.Drawing.Point(8, 8);
			this.btnShow.Name = "btnShow";
			this.btnShow.Size = new System.Drawing.Size(120, 23);
			this.btnShow.TabIndex = 0;
			this.btnShow.Text = "Zobrazit nastroje";
			this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
			// 
			// btnHide
			// 
			this.btnHide.Enabled = false;
			this.btnHide.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnHide.Location = new System.Drawing.Point(136, 8);
			this.btnHide.Name = "btnHide";
			this.btnHide.Size = new System.Drawing.Size(120, 23);
			this.btnHide.TabIndex = 1;
			this.btnHide.Text = "Skryt nastroje";
			this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
			// 
			// colorBox
			// 
			this.colorBox.BackColor = System.Drawing.Color.White;
			this.colorBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.colorBox.Location = new System.Drawing.Point(8, 40);
			this.colorBox.Name = "colorBox";
			this.colorBox.Size = new System.Drawing.Size(272, 208);
			this.colorBox.TabIndex = 2;
			this.colorBox.TabStop = false;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.colorBox);
			this.Controls.Add(this.btnHide);
			this.Controls.Add(this.btnShow);
			this.Name = "MainForm";
			this.Text = "MainForm";
			this.Move += new System.EventHandler(this.MainForm_Move);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Zde se vytvori hlavni formular a aplikace se spusti
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.Run(new MainForm());
		}

		/// <summary> Tlacitko na zobrazeni panelu s nastroji </summary>
		private System.Windows.Forms.Button btnShow;
		/// <summary> Tlacitko na skryti panelu s nastroji </summary>
		private System.Windows.Forms.Button btnHide;
		private System.Windows.Forms.PictureBox colorBox;

		/// <summary>
		/// Panel s nastroji
		/// </summary>
		private ToolsForm frmTools;

		/// <summary>
		/// Povoluje nebo zakazuje tlacitka na praci s panelem nastroju
		/// </summary>
		/// <param name="allowHide">
		/// Pokud je true smi se panel zkryt, pokud false smi se zobrazit
		/// </param>
		public void EnableButtons(bool allowHide)
		{
			btnShow.Enabled=!allowHide;
			btnHide.Enabled=allowHide;
		}

		/// <summary>
		/// Nastavi barvu ovladaciho prvku na formulari
		/// </summary>
		public void SetColor(int r,int g,int b)
		{
			colorBox.BackColor=Color.FromArgb(r,g,b);
		}

		/// <summary>
		/// Zobrazit panel nastroju
		/// </summary>
		private void btnShow_Click(object sender, System.EventArgs e)
		{
			// vytvorit formular
      frmTools=new ToolsForm(this);

			// nastavi panelu s nastroji vlastnika na tento formular,
			// takze panel s nastroji bude vzdy "nad" nim
			frmTools.Owner=this;

			// zobrazi a posune panel
			frmTools.Show();
			frmTools.Location=new Point(Left+Width,Top);

			EnableButtons(true);
		}


		/// <summary>
		/// Skryt panel nastroju
		/// </summary>
		private void btnHide_Click(object sender, System.EventArgs e)
		{
			if (frmTools!=null) frmTools.Close();
		}


		/// <summary>
		/// Pri posunuti s hlavnim formularem se posouva i panel s nastroji 
		/// (ale jen pokud existuje !!)
		/// </summary>
		private void MainForm_Move(object sender, System.EventArgs e)
		{
			if (frmTools!=null)
			{
				frmTools.Left=Left+Width;
				frmTools.Top=Top;
			}
		}
	}
}
