using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace FormsInteraction
{
	/// <summary>
	/// Formular, ktery reprezentuje panel s nastroji
	/// </summary>
	public class ToolsForm : System.Windows.Forms.Form
	{
		#region Standardni generovany kod

		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.LinkLabel lnkChangeCol;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnClose = new System.Windows.Forms.Button();
			this.lnkChangeCol = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// btnClose
			// 
			this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnClose.Location = new System.Drawing.Point(32, 16);
			this.btnClose.Name = "btnClose";
			this.btnClose.TabIndex = 0;
			this.btnClose.Text = "Zavrit panel";
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lnkChangeCol
			// 
			this.lnkChangeCol.Location = new System.Drawing.Point(32, 56);
			this.lnkChangeCol.Name = "lnkChangeCol";
			this.lnkChangeCol.TabIndex = 1;
			this.lnkChangeCol.TabStop = true;
			this.lnkChangeCol.Text = "Zmenit barvu";
			this.lnkChangeCol.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkChangeCol_LinkClicked);
			// 
			// ToolsForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(146, 168);
			this.Controls.Add(this.lnkChangeCol);
			this.Controls.Add(this.btnClose);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "ToolsForm";
			this.ShowInTaskbar = false;
			this.Text = "Panel s nastroji";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.ToolsForm_Closing);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Zde si ukladame referenci na objekt hlavniho formulare,
		/// pomoci ktere je pozdeji mozne s formularem pracovat
		/// </summary>
		MainForm main;

		/// <summary>
		/// Vytvori panel s nastroji a predava mu referenci na hlavni form
		/// </summary>
		/// <param name="main">Reference na hlavni form</param>
		public ToolsForm(MainForm main)
		{
			this.main=main;
			InitializeComponent();
		}


		/// <summary>
		/// Zavrit panel s nastroji
		/// </summary>
		private void btnClose_Click(object sender, System.EventArgs e)
		{
			Close();
		}


		/// <summary>
		/// Kdyz se panel zavira tak overuje jestli ho uzivatel opravdu chce zavrit
		/// </summary>
		private void ToolsForm_Closing(object sender, 
			System.ComponentModel.CancelEventArgs e)
		{
			if (MessageBox.Show("Opravdu chcete zavrit panel?",Text,
				MessageBoxButtons.YesNo)==DialogResult.No)
			{
				// nezavirat
				e.Cancel=true;
			}
			else
			{
				// nastavit hlavnimu formu, ze je panel zavreny
				main.EnableButtons(false);
			}
		}


		/// <summary>
		/// Meni barvu ovladaciho prvku v hlavnim frmulari
		/// </summary>
		private void lnkChangeCol_LinkClicked(object sender, 
			System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			Random rnd=new Random();
			main.SetColor(rnd.Next(256),rnd.Next(256),rnd.Next(256));
		}
	}
}
