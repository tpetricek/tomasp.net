#light

open System
open System.Reflection
open System.Windows.Forms
open Microsoft.FSharp
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw

(*---------------------------------------------------------------------------*)
/// Resolves F# quotations of all top level definitions 
let resolveAssemblyTopDefs name classFun (defFun:(Type -> MemberInfo -> expr -> unit)) =
  let asm = Assembly.LoadFile(name) in
  asm.GetTypes() |> Array.iter ( fun t ->
    classFun t )