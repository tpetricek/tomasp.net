#light

open System
open System.IO
open System.Reflection
open System.Diagnostics
open System.Configuration
open System.Windows.Forms
open Microsoft.FSharp
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw

(*---------------------------------------------------------------------------*)
let compileExpr (x:string) =
  // Generate source file
  let fsName = Path.GetTempFileName() in
  let fw = new StreamWriter(fsName^".fs") in 
  fw.WriteLine "
    module RuntimeQuot\n
    open System\n
    open System.Windows.Forms\n
    open Microsoft.FSharp\n
    open Microsoft.FSharp.Idioms\n
    open Microsoft.FSharp.MLLib\n
    open Microsoft.FSharp.Quotations\n
    open Microsoft.FSharp.Quotations.Raw\n"
  fw.WriteLine x
  fw.Close()
  
  // Run F# compiler...
  let psi = new ProcessStartInfo() in 
  psi.FileName <- ConfigurationSettings.AppSettings.Item("fsc_path")
  psi.Arguments <- " -a -o \""^fsName^".dll\" \""^fsName^".fs\""
  psi.CreateNoWindow <- true
  psi.UseShellExecute <- false
  psi.RedirectStandardError <- true
  let p = Process.Start(psi) in
  let result = p.StandardError.ReadToEnd() in
  p.WaitForExit()
  File.Delete (fsName)
  File.Delete (fsName^".fs")
  
  if ((result.Trim()).Length > 0) then 
    // Compilation failed?
    ignore(MessageBox.Show (result,"Compilation error"))
    None
  else 
    // Get value of field with name 'q' using reflection..
    let a = Assembly.LoadFile(fsName^".dll") in
    let t = a.GetType("RuntimeQuot") in
    let prop = t.GetProperty("q") in
    let o = prop.GetValue(null, [] |> List.to_array) in  
    Some(o :?> expr)

/// Read the whole content of stream
let readToEnd (s : Stream) = 
  let n = Int64.to_int s.Length in 
  let res = Array.zero_create n in 
  let i = ref 0 in 
  while (!i < n) do 
    i := !i + s.Read(res,!i,(n - !i)) 
  done
  res

/// Resolves F# quotations of all top level definitions 
let resolveAssemblyTopDefs name classFun defFun =
  let asm = Assembly.LoadFile(name) in
  asm.GetManifestResourceNames() |> Array.to_list 
    |> List.filter (fun rn -> rn.StartsWith(pickledDefinitionsResourceNameBase)) 
    |> List.iter (fun rn -> explicitlyRegisterTopDefs asm rn (readToEnd (asm.GetManifestResourceStream(rn))))
  
  let topDefs = 
        asm.GetTypes() 
     |> Array.to_list 
     |> List.map ( fun t ->
          let tName = (if t.Namespace = null then [] else t.Namespace.Split(Array.create 1 '.') |> Array.to_list)@[t.Name]       
          let names = Array.concat [ t.GetMethods() |> Array.map ( fun m -> (m :> MemberInfo) );
                                 t.GetProperties() |> Array.map ( fun p -> (p :> MemberInfo) ) ]
          let defns = 
                names 
              |> Array.to_list 
              |> List.map ( fun mi ->
                   let path = (tName, mi.Name) 
                   let modDef = { topDefAssembly=t.Assembly.FullName; topDefPath=path; } 
                   (mi, resolveTopDef (modDef, [])) ) 
              |> List.filter ( fun (_, d) -> d <> None ) 
          (t, defns) )
     |> List.filter ( fun (_, d) -> d <> [] )
  
  if (topDefs <> []) then
    topDefs |> List.iter ( fun (t, dList) ->
      let r = classFun t in
      dList |> List.iter ( fun (mi, d) ->
        match d with
          | Some(def) -> defFun r mi def
          | _ -> () ) )