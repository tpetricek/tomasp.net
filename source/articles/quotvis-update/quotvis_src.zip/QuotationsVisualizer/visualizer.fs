#light
#nowarn "57" // disable "active patterns" warning

open System
open System.Windows.Forms
open Microsoft.FSharp
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw
open Microsoft.FSharp.Experimental

let pattern f = { new IPattern<_,_> with get_Query () = f }

let EFAnd  = efAnd 
let EFApp = efApp
let EFApps = efApps
let EFAnyTopDefn = efAnyTopDefn
// TODO: arraymk
let EFBool = efBool
let EFByte = efByte
let EFChar = efChar
let EFCtorCall  = efCtorCall 
let EFConst = efConst
let EFCond  = efCond 
// TODO: coerce
let EFDouble = efDouble
// TODO: defn
// TODO: delegatemk
let EFEquality  = efEquality 
// TODO: false
let EFForLoop = efForLoop
// TODO: getaddr
let EFHole = efHole
let EFInt16 = efInt16
let EFInt32 = efInt32
let EFInt64 = efInt64
let EFLambda = efLambda
let EFLambdas = efLambdas
let EFLiftedValue = efLiftedValue
let EFLet  = efLet 
let EFLetRec  = efLetRec 
let EFMethodCall  = efMethodCall 
let EFOr  = efOr 
let EFPropGetCall  = efPropGetCall 
let EFQuote = efQuote
// TODO: recdget
// TODO: recdmk
let EFSByte = efSByte
let EFSeq  = efSeq 
let EFSingle = efSingle
let EFString = efString
// TODO: template
// TODO: true
// TODO: tupleget
let EFTupleMk  = efTupleMk 
let EFUInt16 = efUInt16
let EFUInt32 = efUInt32
let EFUInt64 = efUInt64
// TODO: unionget
// TODO: unionmk
// TODO: uniontest
let EFUnit = efUnit
let EFVar = efVar
let EFWhileLoop = efWhileLoop



let buildExprTreeOpt (x:expr) (tree:TreeNode) (useApps:bool) =

  // Function used in pattern matching to force 
  // matching with efApp instead of efApps
  let SimpleFailApps = pattern (fun n -> 
    if (useApps) then None else ( match n with | EFApps(v) -> Some(v) | _ -> None ) )
  let SimpleFailLambdas = pattern (fun n -> 
    if (useApps) then None else  ( match n with | EFLambdas(v) -> Some(v) | _ -> None ) )
  
  let rec buildExprTree x (tree:TreeNode) =
    match x with // the big pattern match..
      (************************ SPECIAL ************************)      
      | EFLiftedValue(o) ->                      // Lifted value - instance of .NET object
          let s = if (o = null) then "" else ((o.GetType()).FullName) in
          let n = new TreeNode("(lifted-value) "^s, 21, 21) in 
          ignore(tree.Nodes.Add(n));
      | EFQuote(quoted) ->                       // Inner quotations <@@ ... @@>
          let n = new TreeNode("(quoted)", 20, 20) in 
          buildExprTree quoted n;
          ignore(tree.Nodes.Add(n));
      | EFTupleMk(types,vals) ->                 // make tuple
          let n = new TreeNode("(tuple)", 16, 16) in 
          List.iter (fun arg ->
            buildExprTree arg n) vals;
          ignore(tree.Nodes.Add(n));
      
      (************************ STATEMENTS ************************)      
      | EFForLoop(nfrom,nto,body) ->             // Statement: for i=start to end do body; done;
          let n = new TreeNode("(for-loop)",19,19) in 
          let nf = new TreeNode("(from)",4,4) in 
          let nt = new TreeNode("(to)",4,4) in 
          let nb = new TreeNode("(body)",3,3) in 
          buildExprTree nfrom nf;
          buildExprTree nto nt;
          buildExprTree body nb;
          ignore(n.Nodes.Add(nf));
          ignore(n.Nodes.Add(nt));
          ignore(n.Nodes.Add(nb));
          ignore(tree.Nodes.Add(n));
      | EFWhileLoop(cond,body) ->                // Statement: while condition do body; done;
          let n = new TreeNode("(while-loop)",19,19) in 
          let nc = new TreeNode("(cond)",4,4) in 
          let nb = new TreeNode("(body)",3,3) in 
          buildExprTree cond nc;
          buildExprTree body nb;
          ignore(n.Nodes.Add(nc));
          ignore(n.Nodes.Add(nb));
          ignore(tree.Nodes.Add(n));
      | EFCond(t,(cond,tr,fl)) ->                // if .. then .. else .. expression
          let n = new TreeNode("(condition)",19,19) in 
          let ni = new TreeNode("(if)",4,4) in 
          let nt = new TreeNode("(then)",3,3) in 
          let nf = new TreeNode("(else)",3,3) in 
          buildExprTree cond ni;
          buildExprTree tr nt;
          buildExprTree fl nf;
          ignore(n.Nodes.Add(ni));
          ignore(n.Nodes.Add(nt));
          ignore(n.Nodes.Add(nf));
          ignore(tree.Nodes.Add(n));
          
      (************************ OPERATORS ************************)      
      | EFAnd(lv,rv) ->                          // and operator
          let n = new TreeNode("(and)",18,18) in 
          let nl = new TreeNode("(left)",4,4) in 
          let nr = new TreeNode("(right)",4,4) in 
          buildExprTree lv nl;
          buildExprTree rv nr;
          ignore(n.Nodes.Add(nl));
          ignore(n.Nodes.Add(nr));
          ignore(tree.Nodes.Add(n));
      | EFOr(lv,rv) ->                           // or operator
          let n = new TreeNode("(or)",18,18) in 
          let nl = new TreeNode("(left)",4,4) in 
          let nr = new TreeNode("(right)",4,4) in 
          buildExprTree lv nl;
          buildExprTree rv nr;
          ignore(n.Nodes.Add(nl));
          ignore(n.Nodes.Add(nr));
          ignore(tree.Nodes.Add(n));
      | EFEquality(t,(lv,rv)) ->                 // equality left = right
          let n = new TreeNode("(equality)",18,18) in 
          let nl = new TreeNode("(left)",4,4) in 
          let nr = new TreeNode("(right)",4,4) in 
          buildExprTree lv nl;
          buildExprTree rv nr;
          ignore(n.Nodes.Add(nl));
          ignore(n.Nodes.Add(nr));
          ignore(tree.Nodes.Add(n));
          
      (************************ LET .. IN, .NET CALLS  ************************)
      | EFSeq(a,b) ->                            // sequence of expressions
          let n = new TreeNode("(sequence)", 14, 14) in 
          ignore(tree.Nodes.Add(n));
          buildExprTree a n;
          buildExprTree b n;
      | EFMethodCall(meth,sth,args) ->           // method call
          let n = new TreeNode("(call) " + meth.methName, 12, 12) in 
          ignore(tree.Nodes.Add(n));
          List.iter (fun arg ->
            buildExprTree arg n) args;
      | EFPropGetCall(prop,sth,arg) ->           // property-get call
          let n = new TreeNode("(get-property) " + prop.propGetMethName, 12, 12) in 
          ignore(tree.Nodes.Add(n));
          buildExprTree arg n;
      | EFCtorCall(ct,sth,args) ->              // construtor invocation
          let n = new TreeNode("(constructor) " + ct.ctorParent.tcName, 13, 13) in 
          ignore(tree.Nodes.Add(n));
          List.iter (fun arg ->
            buildExprTree arg n) args;
      | EFLetRec(exprs,body) ->                  // let rec .. in ...
          let n = new TreeNode("(let-rec)", 9, 9) in 
          List.iter (fun (name,b) -> 
              let n1 = new TreeNode("(value) "+name.vName.Text, 11, 11) in 
              buildExprTree b n1;
              ignore(n.Nodes.Add(n1));
            ) exprs;
          let n2 = new TreeNode("(in)", 10, 10) in 
          buildExprTree body n2;
          ignore(n.Nodes.Add(n2));
          ignore(tree.Nodes.Add(n));
      | EFLet((name,a),b) ->                     // let .. in ...
          let n = new TreeNode("(let)", 9, 9) in 
          let n1 = new TreeNode("(value) "+name.vName.Text, 11, 11) in 
          buildExprTree a n1;
          let n2 = new TreeNode("(in)", 10, 10) in 
          buildExprTree b n2;
          ignore(n.Nodes.Add(n1));
          ignore(n.Nodes.Add(n2));
          ignore(tree.Nodes.Add(n));
          
      (************************ PRIMITIVE DATA TYPES ************************)
      | EFDouble(x) ->                             // double value
          let n = new TreeNode("(double) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFSingle(x) ->                             // single value
          let n = new TreeNode("(single) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFBool(x) ->                              // bool value
          let n = new TreeNode("(bool) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFByte(x) ->                             // byte value
          let n = new TreeNode("(byte) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFSByte(x) ->                             // signed byte value
          let n = new TreeNode("(sbyte) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFChar(x) ->                             // char value
          let n = new TreeNode("(char) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFInt16(x) ->                            // int16 value
          let n = new TreeNode("(int16) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFInt32(x) ->                            // int32 value
          let n = new TreeNode("(int32) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFUInt16 (x) ->                          // uint16 value
          let n = new TreeNode("(uint16) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFUInt32 (x) ->                          // uint32 value
          let n = new TreeNode("(uint32) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFInt64(x) ->                            // int64 value
          let n = new TreeNode("(int64) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFUInt64 (x) ->                          // uint64 value
          let n = new TreeNode("(uint64) " + x.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFString(x) ->                           // string value
          let n = new TreeNode("(string) " + x, 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFUnit ->                           // unit value
          let n = new TreeNode("(unit)", 6, 6) in 
          ignore(tree.Nodes.Add(n));
          
    (************************ TOP LEVEL DEFINITONS, VARIABLES, CONSTANTS, HOLE ************************)
      | EFAnyTopDefn(a,t) ->                     // top level definition
          let t1,t2 = a.topDefPath in
          let n = new TreeNode("(top-level) " + t2.ToString(), 5, 5) in 
          ignore(tree.Nodes.Add(n));
      | EFVar(a) ->                              // variable
          let n = new TreeNode("(variable) " + a.Text, 7, 7) in 
          ignore(tree.Nodes.Add(n));
      | EFConst(a,t) ->                          // constant
          let n = new TreeNode("(const) " + a.ToString(), 6, 6) in 
          ignore(tree.Nodes.Add(n));
      | EFHole(a) ->                             // hole
          let n = new TreeNode("(hole)", 8, 8) in
          ignore(tree.Nodes.Add(n));
          
      (************************ LAMBDA, FUNCTION APPLICATIONS ************************)      
      | SimpleFailLambdas (a,b) ->                // Lambda expression - match only when user wants "app" instead of "apps"
          let n = new TreeNode("(lambda series)", 15, 15) in 
          let n1 = new TreeNode("(parameters)",4,4) in 
          List.iter (fun var -> 
            ignore(n1.Nodes.Add(new TreeNode("(parameter) " + var.vName.Text, 4, 4))); ) a;
          let n2 = new TreeNode("(operation)",3,3) in 
          buildExprTree b n2;
          ignore(n.Nodes.Add(n1));
          ignore(n.Nodes.Add(n2));
          ignore(tree.Nodes.Add(n));
      | EFLambda(a,b) ->                         // lambda expression
          let n = new TreeNode("(lambda) " + a.vName.Text, 15, 15) in 
          buildExprTree b n;
          ignore(tree.Nodes.Add(n));
      | SimpleFailApps (a,b) ->                   // Function application - match only when user wants "app" instead of "apps"
          let n = new TreeNode("(series of function application)",2,2) in
          let n1 = new TreeNode("(operation)",3,3) in 
          buildExprTree a n1;
          ignore(n.Nodes.Add(n1));
          let n2 = new TreeNode("(parameters)",4,4) in 
          List.iter (fun arg ->
            buildExprTree arg n2) b;
          ignore(n.Nodes.Add(n2));
          ignore(tree.Nodes.Add(n));
      | EFApp(a,b) ->                            // app
          let n = new TreeNode("(single function application)",1,1) in
          let n1 = new TreeNode("(operation)",3,3) in 
          buildExprTree a n1;
          ignore(n.Nodes.Add(n1));
          let n2 = new TreeNode("(parameter)",4,4) in 
          buildExprTree b n2;
          ignore(n.Nodes.Add(n2));
          ignore(tree.Nodes.Add(n));
      | _ ->                                     // someting unknown?
          let n = new TreeNode("?", 17, 17) in 
          ignore(tree.Nodes.Add(n)) in
          
  // call buildExprTree
  buildExprTree x tree


// Builds root node and calls buildExprTreeOpt
let getExpressionTree e useApps = 
  let rootNode = new TreeNode("(root)") in
  buildExprTreeOpt e rootNode useApps;
  rootNode
  