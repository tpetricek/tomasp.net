open System
open System.Drawing
open System.Resources
open System.Reflection
open System.Windows.Forms;;
open Microsoft.FSharp
open Microsoft.FSharp.Idioms
open Microsoft.FSharp.MLLib
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw;;

open Visualizer;;
open Compiler;;

(*---------------------------------------------------------------------------*)
/// Dialog that is opened when user wants to add new F# 
/// (that will be compiled at runtime using FSC)
type EnterCodeDialog = class inherit Form as base

	val code : TextBox;
	val title : TextBox;
	val mutable expression : expr;

	/// Build GUI...
	new ((parent:#Form)) as this = 
		{ inherit Form(); 
			code = new TextBox();
			title = new TextBox();
			expression = <@@ 1 @@>;
		} then
		this.Owner <- parent;
		this.Width <- 400;
		this.Height <- 300;
		this.StartPosition <- FormStartPosition.CenterParent;
		this.Text <- "Enter quotation expression";
		this.ShowInTaskbar <- false;
		this.MaximizeBox <- false;
		this.MinimizeBox <- false;
		this.FormBorderStyle <- FormBorderStyle.FixedDialog;
		let lbl = new Label() in 
		lbl.Text <- "Title:";
		lbl.Left <- 4;
		lbl.Width <- 50;
		lbl.Top <- 4;
		lbl.TextAlign <- ContentAlignment.MiddleLeft;
		this.Controls.Add(lbl);
		this.title.Text <- "Generated";
		this.title.Left <- 54;
		this.title.Width <- this.ClientSize.Width - 58;
		this.title.Top <- 4;
		this.title.Anchor <- MLLib.Enum.combine [AnchorStyles.Left; AnchorStyles.Right; AnchorStyles.Top];
		this.code.Text <- "let q = <@@ 1 @@>;;";
		this.code.SelectionLength <- 0;
		this.code.Multiline <- true;
		this.code.WordWrap <- false;
		this.code.ScrollBars <- ScrollBars.Vertical;
		this.code.Font <- new Font(FontFamily.GenericMonospace, Float.to_float32 9.0);
		this.code.Left <- 4;
		this.code.Width <- this.ClientSize.Width - 8;
		this.code.Top <- 28;
		this.code.Height <- this.ClientSize.Height - 64;
		this.code.Anchor <- MLLib.Enum.combine [AnchorStyles.Bottom; AnchorStyles.Left; AnchorStyles.Right; AnchorStyles.Top];
		this.Controls.Add(this.code);
		this.Controls.Add(this.title);
		let ok = new Button() in
		this.AcceptButton <- ok;
		ok.FlatStyle <- FlatStyle.System;
		ok.Text <- "OK";
		ok.Left <- this.ClientSize.Width - 64;
		ok.Width <- 60;
		ok.Top <- this.ClientSize.Height - 28;
		ok.Height <- 22;
		ok.Anchor <- MLLib.Enum.combine [AnchorStyles.Bottom; AnchorStyles.Right];
		ok.Click.Add( fun _ -> 
				match (compileExpr this.EnteredCode) with
					| Some(e) ->
						this.expression <- e;
						this.DialogResult <- DialogResult.OK; 
						this.Close(); 
					| _ -> ignore(0);
			);
		this.Controls.Add(ok);

	/// F# source code entered by user
	member this.EnteredCode
		with get() = this.code.Text;

	/// Title of entered expression 
	/// (will be used as title for tab page) 
	member this.EnteredTitle
		with get() = this.title.Text;
	
	/// Compiled expression
	member this.CompiledExpression
		with get() = this.expression;
end;;

(*---------------------------------------------------------------------------*)
/// Tab page that is used for displaying expression trees
/// It contains original object that represents the expression
type QuotationTabPage = class inherit TabPage as base

	val expression : expr;
	val tree : TreeView;
	
	/// Build GUI...
	new ((s:string),(h:string),(e:expr),(imgs:ImageList)) as this = 
		{ inherit TabPage();
			expression = e; 
			tree = new TreeView();
		} then
		let pnl = new Panel() in
		let hdr = new TextBox() in
		hdr.Text <- (h.Replace("\t", "  ")).Replace("\n","\r\n");
		hdr.ReadOnly <- true;
		hdr.Multiline <- true;
		hdr.WordWrap <- false;
		hdr.ScrollBars <- ScrollBars.Vertical;
		hdr.Font <- new Font(FontFamily.GenericMonospace, Float.to_float32 9.0);
		pnl.Dock <- DockStyle.Bottom;
		pnl.Height <- 140;
		this.Text <- s;
		this.Controls.Add(this.tree);
		this.Controls.Add(pnl);
		pnl.Controls.Add(hdr);
		hdr.Left <- 10;
		hdr.Top <-10;
		hdr.Width <- pnl.Width - 20;
		hdr.Height <- pnl.Height - 20;
		hdr.Anchor <- MLLib.Enum.combine [AnchorStyles.Bottom; AnchorStyles.Left; AnchorStyles.Right; AnchorStyles.Top];
		this.tree.ImageList <- imgs;
		this.tree.Dock <- DockStyle.Fill;

	/// Returns TreeView
	member this.QuotationTree
		with get() = this.tree;
		
	// Returns expression at this tab 
	member this.Expression 
		with get() = this.expression;		
		
end;;

(*---------------------------------------------------------------------------*)
type Main = class inherit Form as base

	val mutable tabs : TabControl;
	val mutable checkApps : CheckBox;
	val mutable checkExpand : CheckBox;
	val mutable treeIcons : ImageList;

	new () as this = 
		{ inherit Form(); 
			tabs = null; checkApps = null;
			checkExpand = null; treeIcons = null;
		} then
		this.InitializeComponent();
	
	/// Build GUI...
  member this.InitializeComponent() =
		this.tabs <- new TabControl();
		this.checkApps <- new CheckBox();
		this.checkExpand <- new CheckBox();
		let pnl = new Panel() in 
		let lbl1 = new Label() in
		let lbl2 = new Label() in
		let lnkExpand = new LinkLabel() in
		let lnkCollapse = new LinkLabel() in
		let lnkAddQuot = new LinkLabel() in
		let lnkCloseCurrent = new LinkLabel() in
		
		// settings
		pnl.Dock <- DockStyle.Right;
		pnl.Width <- 250; 
		this.checkExpand.Text <- "Call deepMacroExpand on quotation";
		this.checkExpand.Left <- 16;
		this.checkExpand.Width <- 220;
		this.checkExpand.Top <- 72;
		this.checkApps.Text <- "Display series of applications (efApps) instead of single application (efApp)";
		this.checkApps.FlatStyle <- FlatStyle.System;
		this.checkExpand.FlatStyle <- FlatStyle.System;
		this.checkApps.Left <- 16;
		this.checkApps.Width <- 220;
		this.checkApps.Top <- 32;
		this.checkApps.Height <- 40;
		this.checkApps.CheckedChanged.Add(fun _ -> this.RegenerateQuotations() );
		this.checkExpand.CheckedChanged.Add(fun _ -> this.RegenerateQuotations() );
		lbl1.Font <- new Font(lbl1.Font.Name, Float.to_float32 10.0, FontStyle.Bold);
		lbl1.Text <- "Settings";
		lbl1.Left <- 4;
		lbl1.Top <- 8;
		
		// tools
		lbl2.Font <- new Font(lbl1.Font.Name, Float.to_float32 10.0, FontStyle.Bold);
		lbl2.Text <- "Tools";
		lbl2.Left <- 4;
		lbl2.Top <- 112;		
		lnkExpand.Text <- "Expand current tree";
		lnkExpand.Left <- 32;
		lnkExpand.Width <- 200;
		lnkExpand.Top <- 136;
		lnkExpand.Click.Add(fun _ -> this.CollapseOrExpandTree(true));
		lnkCollapse.Text <- "Collapse current tree";
		lnkCollapse.Left <- 32;
		lnkCollapse.Width <- 200;
		lnkCollapse.Top <- 160;		
		lnkCollapse.Click.Add(fun _ -> this.CollapseOrExpandTree(false));
		lnkCloseCurrent.Text <- "Close current page";
		lnkCloseCurrent.Left <- 32;
		lnkCloseCurrent.Width <- 200;
		lnkCloseCurrent.Top <- 184;		
		lnkCloseCurrent.Click.Add(fun _ -> this.CloseCurrentTab() );		
		lnkAddQuot.Text <- "Add new quotation";
		lnkAddQuot.Left <- 32;
		lnkAddQuot.Width <- 200;
		lnkAddQuot.Top <- 208;		
		lnkAddQuot.Click.Add(fun _ -> this.AddQuotation() );				
		
		pnl.Controls.Add(lbl1);
		pnl.Controls.Add(lbl2);
		pnl.Controls.Add(lnkExpand);
		pnl.Controls.Add(lnkCollapse);
		pnl.Controls.Add(lnkCloseCurrent);
		pnl.Controls.Add(lnkAddQuot);
		pnl.Controls.Add(this.checkApps);
		pnl.Controls.Add(this.checkExpand);
		
		// tabs & form
		this.tabs.Dock <- DockStyle.Fill;
		this.Text <- "Quotations Visualizer";
		this.Width <- 800;
		this.Height <- 600;
		this.Controls.Add(this.tabs);
		this.Controls.Add(pnl);
		
		// load icons
		this.treeIcons <- new ImageList();
		this.treeIcons.TransparentColor <- Color.Fuchsia;
		let mgr = new ResourceManager("Resources.Main", Assembly.GetExecutingAssembly()) in		
		List.iter (fun n -> this.treeIcons.Images.Add(mgr.GetObject(n) :?> Bitmap))
			["root"; "app"; "apps"; "action"; "param"; "topdef"; "constant"; "var"; "hole"; 
			 "let"; "letin"; "letwhat"; "call"; "ctorcall"; "seq"; "lambda"; "tuple"; "error"; "oper"; "statement"];

	/// Adds new quotation to Tab control
	member this.AddQuotation (t:string) (h:string) (e:expr) = 
		let tab = new QuotationTabPage(t,h,e,this.treeIcons) in
		this.tabs.Controls.Add(tab);
		this.GenerateQuotation tab;
		
	/// Close current tab 
	member this.CloseCurrentTab () = 
		if (this.tabs.SelectedTab = null) then begin
			ignore(MessageBox.Show("No page is opened!", this.Text));
		end else begin
			this.tabs.Controls.Remove(this.tabs.SelectedTab);
		end;
		
	/// Generates trees for all expressions
	/// (this is called when settings are changed)
	member this.RegenerateQuotations () =
		foreach this.tabs.Controls (fun (ctrl:Control) ->
			let tab = (ctrl :?> QuotationTabPage) in
			this.GenerateQuotation tab;
		);
		
	/// Generates quotation tree on one tab page
	member this.GenerateQuotation (tab:QuotationTabPage) =
		let exp = if (this.checkExpand.Checked) then deepMacroExpandUntil (fun _ -> false) tab.Expression else tab.Expression in
		let node = getExpressionTree exp (this.checkApps.Checked) in
		tab.QuotationTree.Nodes.Clear();
		ignore(tab.QuotationTree.Nodes.Add(node));
		tab.QuotationTree.ExpandAll();
				
	/// Collapses or expands tree on current tab page
	member this.CollapseOrExpandTree (expand:bool) = 
		if (this.tabs.SelectedTab = null) then begin
			ignore(MessageBox.Show("No page is opened!", this.Text));
		end else begin
			let t = this.tabs.SelectedTab in
			let tr = (t :?> QuotationTabPage).QuotationTree in
			if (expand) then tr.ExpandAll() else tr.CollapseAll();
		end;
		
	/// Add quotation entered by user
	member this.AddQuotation () =
		let dlg = new EnterCodeDialog(this) in
		if (dlg.ShowDialog() = DialogResult.OK) then begin
			this.AddQuotation dlg.EnteredTitle dlg.EnteredCode dlg.CompiledExpression;			
		end;
		
end;;
  