open System
open System.Windows.Forms
open Microsoft.FSharp
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw;;

open Gui;;

// Some quotations that will be displayed when application is launched
let var = 2;;
let quotations = [
	("Addition", 
		"<@@ 1+(2-var) @@>",
		 <@@ 1+(2-var) @@>);
		 
	("Statements", 
		"<@@ for i = 0 to 10 do print_int i; done; @@>",
		 <@@ for i = 0 to 10 do print_int i; done; @@>);
		 		 
	("Float calculations", 
		"<@@ sin(5.0*3.0) + 4.0/2.0 @@>",
		 <@@ sin(5.0*3.0) + 4.0/2.0 @@>);
		 
	("Math with holes",  
		"(<@@. 5*_ + _/2 .@@>).Raw",
		 (<@@. 5*_ + _/2 .@@>).Raw);
		 
	("Variable binding", 
		"<@@ let t = (1,2) in let a,b = t in a + b; @@>",
		 <@@ let t = (1,2) in let a,b = t in a + b; @@>);

	("Lambda function", 
		"<@@ let rec fact = fun a -> if (a=0) then 1 else (a*fact a-1) in fact 10; @@>",
		 <@@ let rec fact = fun a -> if (a=0) then 1 else (a*fact a-1) in fact 10; @@>);
		 		 
	("Form creation", 
		"<@@ 
			let tmp = \"Hello world\" in
			let form = new Form() in
			form.Text <- tmp.ToString(); 
			form.Show();
		@@>",
		<@@ 
			let tmp = "Hello world" in
			let form = new Form() in
			form.Text <- tmp.ToString(); 
			form.Show();
		@@>)
(*;
	// Currently the following expression can't be quoted
	("Objects", 
		"<@@ 
			let someData = { new IComparable with CompareTo a = 1 } in 
			someData.CompareTo(5);
		@@>",
		<@@ 
			let someData = { new IComparable with CompareTo a = 1 } in 
			someData.CompareTo(5);
		@@>)
*)		
];;

[<STAThread>]    
do let form = new Main() in
	List.iter(fun q ->
			let name, code, exp = q in
			form.AddQuotation name code exp)
		quotations;
	Application.EnableVisualStyles();
	Application.Run(form);