open System
open System.Windows.Forms
open Microsoft.FSharp
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Raw
open Microsoft.FSharp.MLLib.Pervasives;;

let buildExprTreeOpt (x:expr) (tree:TreeNode) (useApps:bool) =

	// Function gused in pattern matching to force 
	// matching with efApp instead of efApps
	let noneIfApp x =
		if (useApps) then x else None in
	
	let rec buildExprTree x (tree:TreeNode) =

		(************************ STATEMENTS ************************)			
		
		// Statement: for i=start to end do body; done;
		match Raw.efForLoop.Query x with
			| Some(nfrom,nto,body) ->
					let n = new TreeNode("(for-loop)",19,19) in 
					let nf = new TreeNode("(from)",4,4) in 
					let nt = new TreeNode("(to)",4,4) in 
					let nb = new TreeNode("(body)",3,3) in 
					buildExprTree nfrom nf;
					buildExprTree nto nt;
					buildExprTree body nb;
					ignore(n.Nodes.Add(nf));
					ignore(n.Nodes.Add(nt));
					ignore(n.Nodes.Add(nb));
					ignore(tree.Nodes.Add(n));
			| _ ->

		// Statement: while condition do body; done;
		match Raw.efWhileLoop.Query x with
			| Some(cond,body) ->
					let n = new TreeNode("(while-loop)",19,19) in 
					let nc = new TreeNode("(cond)",4,4) in 
					let nb = new TreeNode("(body)",3,3) in 
					buildExprTree cond nc;
					buildExprTree body nb;
					ignore(n.Nodes.Add(nc));
					ignore(n.Nodes.Add(nb));
					ignore(tree.Nodes.Add(n));
			| _ ->
			
		// if .. then .. else .. expression
		match Raw.efCond.Query x with
			| Some (t,(cond,tr,fl)) ->
					let n = new TreeNode("(condition)",19,19) in 
					let ni = new TreeNode("(if)",4,4) in 
					let nt = new TreeNode("(then)",3,3) in 
					let nf = new TreeNode("(else)",3,3) in 
					buildExprTree cond ni;
					buildExprTree tr nt;
					buildExprTree fl nf;
					ignore(n.Nodes.Add(ni));
					ignore(n.Nodes.Add(nt));
					ignore(n.Nodes.Add(nf));
					ignore(tree.Nodes.Add(n));
			| _ ->
			
		(************************ OPERATORS ************************)			
		
		// and operator
		match Raw.efAnd.Query x with
			| Some (lv,rv) ->
					let n = new TreeNode("(and)",18,18) in 
					let nl = new TreeNode("(left)",4,4) in 
					let nr = new TreeNode("(right)",4,4) in 
					buildExprTree lv nl;
					buildExprTree rv nr;
					ignore(n.Nodes.Add(nl));
					ignore(n.Nodes.Add(nr));
					ignore(tree.Nodes.Add(n));
			| _ ->
			
		// or operator
		match Raw.efOr.Query x with
			| Some (lv,rv) ->
					let n = new TreeNode("(or)",18,18) in 
					let nl = new TreeNode("(left)",4,4) in 
					let nr = new TreeNode("(right)",4,4) in 
					buildExprTree lv nl;
					buildExprTree rv nr;
					ignore(n.Nodes.Add(nl));
					ignore(n.Nodes.Add(nr));
					ignore(tree.Nodes.Add(n));
			| _ ->			
			
		// equality left = right
		match Raw.efEquality.Query x with
			| Some (t,(lv,rv)) ->
					let n = new TreeNode("(equality)",18,18) in 
					let nl = new TreeNode("(left)",4,4) in 
					let nr = new TreeNode("(right)",4,4) in 
					buildExprTree lv nl;
					buildExprTree rv nr;
					ignore(n.Nodes.Add(nl));
					ignore(n.Nodes.Add(nr));
					ignore(tree.Nodes.Add(n));
			| _ ->

		(************************ TUPLES, CALLS, LET .. IN .. ************************)
		// make tuple
		match Raw.efTupleMk.Query x with
			| Some (types,vals) ->
					let n = new TreeNode("(tuple)", 16, 16) in 
					List.iter (fun arg ->
						buildExprTree arg n) vals;
					ignore(tree.Nodes.Add(n));
			| _ ->	
			
		// sequence of commands
		match Raw.efSeq.Query x with
			| Some (a,b) ->
					let n = new TreeNode("(sequence)", 14, 14) in 
					ignore(tree.Nodes.Add(n));
					buildExprTree a n;
					buildExprTree b n;
			| _ ->	
						
		// method call
		match Raw.efMethodCall.Query x with
			| Some (meth,sth,args) -> 
					let n = new TreeNode("(call) " + meth.methName, 12, 12) in 
					ignore(tree.Nodes.Add(n));
					List.iter (fun arg ->
						buildExprTree arg n) args;
			| _ -> 

		// method call
		match Raw.efPropGetCall.Query x with
			| Some (prop,sth,arg) -> 
					let n = new TreeNode("(get-property) " + prop.propGetMethName, 12, 12) in 
					ignore(tree.Nodes.Add(n));
					buildExprTree arg n;
			| _ -> 


		// construtor invocation
		match Raw.efCtorCall.Query x with
			| Some (ct,sth,args) -> 
					let n = new TreeNode("(constructor) " + ct.ctorParent.tcName, 13, 13) in 
					ignore(tree.Nodes.Add(n));
					List.iter (fun arg ->
						buildExprTree arg n) args;
			| _ -> 

		// let rec .. in ...
		match Raw.efLetRec.Query x with
			| Some(exprs,body) ->
					let n = new TreeNode("(let-rec)", 9, 9) in 
					List.iter (fun (name,b) -> 
							let n1 = new TreeNode("(value) "+name.vName.Text, 11, 11) in 
							buildExprTree b n1;
							ignore(n.Nodes.Add(n1));
						) exprs;
					let n2 = new TreeNode("(in)", 10, 10) in 
					buildExprTree body n2;
					ignore(n.Nodes.Add(n2));
					ignore(tree.Nodes.Add(n));
			| _ ->
			
		// let .. in ...
		match Raw.efLet.Query x with
			| Some((name,a),b) ->
					let n = new TreeNode("(let)", 9, 9) in 
					let n1 = new TreeNode("(value) "+name.vName.Text, 11, 11) in 
					buildExprTree a n1;
					let n2 = new TreeNode("(in)", 10, 10) in 
					buildExprTree b n2;
					ignore(n.Nodes.Add(n1));
					ignore(n.Nodes.Add(n2));
					ignore(tree.Nodes.Add(n));
			| _ ->

		(************************ PRIMITIVE DATA TYPES ************************)
		// double value
		match Raw.efDouble.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(double) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 
			
		// bool value
		match Raw.efBool.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(bool) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 		
			
		// byte value
		match Raw.efByte.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(byte) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 						

		// char value
		match Raw.efChar.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(char) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 						
		
		// int32 value
		match Raw.efInt32.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(int32) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 
			
		// uint32 value
		match Raw.efUInt32 .Query x with  
			| Some (x) -> 
					let n = new TreeNode("(uint32) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 			

		// int64 value
		match Raw.efInt64.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(int64) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 
			
		// uint64 value
		match Raw.efUInt64 .Query x with  
			| Some (x) -> 
					let n = new TreeNode("(uint64) " + x.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 			

		// string value
		match Raw.efString.Query x with  
			| Some (x) -> 
					let n = new TreeNode("(string) " + x, 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 
		
		(************************ TOP LEVEL DEFINITONS, VARIABLES, CONSTANTS, HOLE ************************)
		// top level definition
		match Raw.efAnyTopDefn.Query x with  
			| Some (a,t) -> 
					let t1,t2 = a.topDefPath in
					let n = new TreeNode("(top-level) " + t2.ToString(), 5, 5) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 
		
		// variable
		match Raw.efVar.Query x with
			| Some (a) ->
					let n = new TreeNode("(variable) " + a.Text, 7, 7) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 
		
		// constant
		match Raw.efConst.Query x with
			| Some (a,t) ->
					let n = new TreeNode("(const) " + a.ToString(), 6, 6) in 
					ignore(tree.Nodes.Add(n));
			| _ -> 

			
		// hole
		match Raw.efHole.Query x with  
			| Some (a) -> 
					let n = new TreeNode("(hole)", 8, 8) in
					ignore(tree.Nodes.Add(n));
			| _ ->
			
		(************************ LAMBDA, FUNCTION APPLICATIONS ************************)			
		
		// lambda expression
		match Raw.efLambda.Query x with
			| Some (a,b) ->
					let n = new TreeNode("(lambda) " + a.vName.Text, 15, 15) in 
					buildExprTree b n;
					ignore(tree.Nodes.Add(n));
			| _ -> 
								
		// apps
		match noneIfApp(Raw.efApps.Query x) with  
			| Some (a,b) -> 
					let n = new TreeNode("(series of function application)",2,2) in
					let n1 = new TreeNode("(operation)",3,3) in 
					buildExprTree a n1;
					ignore(n.Nodes.Add(n1));
					let n2 = new TreeNode("(parameters)",4,4) in 
					List.iter (fun arg ->
						buildExprTree arg n2) b;
					ignore(n.Nodes.Add(n2));
					ignore(tree.Nodes.Add(n));
			| _ ->
			
		// app
		match Raw.efApp.Query x with  
			| Some (a,b) -> 
					let n = new TreeNode("(single function application)",1,1) in
					let n1 = new TreeNode("(operation)",3,3) in 
					buildExprTree a n1;
					ignore(n.Nodes.Add(n1));
					let n2 = new TreeNode("(parameter)",4,4) in 
					buildExprTree b n2;
					ignore(n.Nodes.Add(n2));
					ignore(tree.Nodes.Add(n));
			| _ -> 
								
		// what is this??
					let n = new TreeNode("?", 17, 17) in 
					ignore(tree.Nodes.Add(n)) in
					
	// call buildExprTree
	buildExprTree x tree;;


// Builds root node and calls buildExprTreeOpt
let getExpressionTree e useApps = 
	let rootNode = new TreeNode("(root)") in
	buildExprTreeOpt e rootNode useApps;
	rootNode;;
	