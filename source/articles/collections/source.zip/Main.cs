using System;
using System.Collections;

namespace CollectionsDemo
{
	/// <summary>
	/// Objekt, ktery uklada informace o zamestnanci
	/// </summary>
	class Zamestnanec
	{
		public string Jmeno;
		public int Plat;

		public Zamestnanec(string jmeno,int plat)
		{
			Jmeno=jmeno;
			Plat=plat;
		}
	}


	/// <summary>
	/// Porovnava zamestnance podle platu
	/// </summary>
	public class PorovnatPodlePlatu : IComparer
	{
		// x < y - zaporne cislo
		// x = y - 0
		// x > y - kladne cislo
		public int Compare(object x, object y)
		{
			return ((Zamestnanec)x).Plat-((Zamestnanec)y).Plat;
		}
	}

	/// <summary>
	/// Porovnava zamestnance podle jmena
	/// </summary>
	public class PorovnatPodleJmena : IComparer
	{
		// x < y - zaporne cislo
		// x = y - 0
		// x > y - kladne cislo
		public int Compare(object x, object y)
		{
			return String.Compare(((Zamestnanec)x).Jmeno,((Zamestnanec)y).Jmeno);
		}
	}

	class Demo
	{
		/// <summary>
		/// Hlavni metoda konzolove aplikace
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			/***************************************************************/
			// Jednoducha ukazka prace s polem
			Console.WriteLine("== vypis cisel z pole a hledani ==");
			int[] cisla=new int[] {1,2,3,4,5};
			foreach(int i in cisla)
				Console.Write("{0}, ",i);
			Console.WriteLine();

			// .. hledani v poli
			Console.WriteLine("Dvojka je na: {0}",Array.BinarySearch(cisla,2));
			Console.WriteLine();

			/***************************************************************/
			// Serazeni pole
			Console.WriteLine("== serazeni pole ==");
			Zamestnanec[] zam=new Zamestnanec[5];
			zam[0]=new Zamestnanec("Martin",15);
			zam[1]=new Zamestnanec("Libor",10);
			zam[2]=new Zamestnanec("David",5);
			zam[3]=new Zamestnanec("Jiri",20);
			zam[4]=new Zamestnanec("Tomas",15);

			// .. setridit podle platu
			Array.Sort(zam,new PorovnatPodlePlatu());
			foreach(Zamestnanec zamestnanec in zam)
				Console.WriteLine("{0} ({1})",zamestnanec.Jmeno,zamestnanec.Plat);
			Console.WriteLine();

			// .. setridit podle jmena
			Array.Sort(zam,new PorovnatPodleJmena());
			foreach(Zamestnanec zamestnanec in zam)
				Console.WriteLine("{0} ({1})",zamestnanec.Jmeno,zamestnanec.Plat);
			Console.WriteLine();

			/***************************************************************/
			// Prace s ArrayListem
			Console.WriteLine("== prace s ArrayListem ==");
			ArrayList list=new ArrayList();
			list.Add(new Zamestnanec("Ondrej",10));
			list.Add(new Zamestnanec("Jan",1));

			list.Sort(new PorovnatPodlePlatu());
			Zamestnanec[] zam2=(Zamestnanec[])list.ToArray(typeof(Zamestnanec));
			foreach(Zamestnanec zamestnanec in zam2)
				Console.WriteLine("{0} ({1})",zamestnanec.Jmeno,zamestnanec.Plat);
			Console.WriteLine();

			/***************************************************************/
			// Prace s Hashtable
			// .. ke kazdemu zamestnanci ulozime plat
			Console.WriteLine("== prace s Hashtable ==");
			Hashtable tab=new Hashtable();
			tab.Add("Tomas",15);
			tab.Add("Jiri",20);
			tab.Add("David",5);

			// .. lze rychle zjistit plat podle jmena
			Console.WriteLine("Tomasuv plat: {0}",(int)tab["Tomas"]);
			Console.WriteLine();

			/***************************************************************/
			// Prace se SortedList
			Console.WriteLine("== prace se SortedList ==");
			// .. vlozit zamestnance
			SortedList sorted=new SortedList(new PorovnatPodleJmena());
			sorted.Add(new Zamestnanec("Martin",15),null);
			sorted.Add(new Zamestnanec("Libor",10),null);
			sorted.Add(new Zamestnanec("Jiri",20),null);

			// .. zamestnanci jsou automaticky serazeni (dle jmena)
			foreach(Zamestnanec zamestnanec in sorted.Keys)
				Console.WriteLine("{0} ({1})",zamestnanec.Jmeno,zamestnanec.Plat);
			Console.WriteLine();
		}
	}
}
