using System;
using System.Collections.Generic;
using System.Text;
using System.Query;
using System.Xml.XLinq;
using System.Data.DLinq;
using System.Expressions;
using System.Reflection;
using EeekSoft.Query;

namespace EeekSoft.Expressions
{
	/// <summary>
	/// Contains extension methods for Expression class. These methods
	/// can be used to 'call' expression tree and can be translated to IQueryable
	/// </summary>
	public static class ExpressionExtensions
	{
		#region Extension methods

		/// <summary>
		/// Invoke expression (compile & invoke). If you want to be able to expand
		/// call to expression you have to use this method for invocation.
		/// </summary>
		public static T Invoke<A0, T>(this Expression<Func<A0, T>> expr, A0 a0)
		{
			return expr.Compile().Invoke(a0);
		}

		/// <summary>
		/// Takes expr and replaces all calls to Invoke (extension) method by it's implementation 
		/// (modifies expression tree)
		/// </summary>
		public static Expression<F> Expand<F>(this Expression<F> expr)
		{
			return (Expression<F>)new ExpressionExpander().Visit(expr);
		}

		/// <summary>
		/// Takes expr and replaces all calls to Invoke (extension) method by it's implementation 
		/// (modifies expression tree)
		/// </summary>
		public static Expression Expand(this Expression expr)
		{
			return new ExpressionExpander().Visit(expr);
		}

		#endregion
	}


	/// <summary>
	/// Implementation of ExpressionVisiter that does the replacement
	/// </summary>
	internal class ExpressionExpander : ExpressionVisitor
	{
		#region Initialization

		Dictionary<ParameterExpression,Expression> _replaceVars;

		internal ExpressionExpander()
		{
			_replaceVars = null;
		}

		private ExpressionExpander(Dictionary<ParameterExpression,Expression> replaceVars)
		{
			_replaceVars = replaceVars;
		}

		#endregion
		#region Utilities

		S Foldl<T,S>(Func<S,T,S> fun, S init, IEnumerable<T> list)
		{
			foreach(T el in list)
				init = fun(init, el);
			return init;
		}
		
		#endregion
		#region Overrides

		internal override Expression VisitParameter(ParameterExpression p)
		{
			if ((_replaceVars != null) && (_replaceVars.ContainsKey(p)))
				return _replaceVars[p];
			else
				return base.VisitParameter(p);
		}

		internal override Expression VisitMethodCall(MethodCallExpression m)
		{
			// Expand expression tree 'calls'
			if (m.Method.DeclaringType == typeof(ExpressionExtensions))
			{
				ConstantExpression c = (ConstantExpression)m.Parameters[0];
				LambdaExpression lambda = (LambdaExpression)c.Value;
				
				Dictionary<ParameterExpression,Expression> replaceVars
					= new Dictionary<ParameterExpression,Expression>();
				for (int i = 0; i < lambda.Parameters.Count; i++)
				{
					Expression rep = m.Parameters[i + 1];
					if ((_replaceVars != null) && (rep is ParameterExpression) && (_replaceVars.ContainsKey((ParameterExpression)rep)))
						replaceVars.Add(lambda.Parameters[i], _replaceVars[(ParameterExpression)rep]);
					else
						replaceVars.Add(lambda.Parameters[i], rep);
				}
				if (_replaceVars != null)
				{
					foreach (KeyValuePair<ParameterExpression, Expression> pair in _replaceVars)
						replaceVars.Add(pair.Key, pair.Value);
				}
				return new ExpressionExpander(replaceVars).Visit(lambda.Body);
			}

			// Replace calls to ContainsAll and ContainsAny with Ands & Ors
			if (m.Method.DeclaringType == typeof(GeneralUtils))
			{
				string[] vals;
				try
				{
					ConstantExpression kwds = m.Parameters[1] as ConstantExpression;
					vals = (string[])kwds.Value;
				}
				catch 
				{
					throw new Exception(string.Format("Second argument for the '{0}' method must be non empty string array!", m.Method.Name));
				}

				// Init parameters
				MethodInfo contMeth = typeof(string).GetMethod("Contains");
				Expression thisRef = Visit(m.Parameters[0]);

				// Combine using And when method is ContainsAll or using Or when method is ConainsAny
				Func<Expression, string, Expression> agg;
				switch(m.Method.Name)
				{
					case "ContainsAny":
						agg = (expr, str) => Expression.Or(expr, 
							Expression.Call(contMeth, thisRef, new Expression[] { Expression.Constant(str) }));
						break;
					case "ContainsAll":
						agg = (expr, str) => Expression.And(expr, 
							Expression.Call(contMeth, thisRef, new Expression[] { Expression.Constant(str) }));
						break;
					default:
						throw new NotImplementedException();
				}
				return Foldl<string,Expression>(agg,
					Expression.Call(contMeth, thisRef, new Expression[] { Expression.Constant(vals[0]) }),
					vals.Skip(1));
			}
			return base.VisitMethodCall(m);
		}

		#endregion
	}
}