#include "AssemblyInfo.h"
#include "EeekSoft.CLinq.h"
#include "EeekSoft.CLinq.Utils.h"
#include "EeekSoft.CLinq.Query.h"

using namespace EeekSoft::CLinq;