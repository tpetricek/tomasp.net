﻿#light
#I @"c:\Program Files\Reference Assemblies\Microsoft\Framework\v3.5" 
#r "System.Core.dll"
#r "System.Data.Linq.dll" 
#r "FLinq.dll"
#r "Northwind.dll"

open System
open System.Data.Linq
open Microsoft.FSharp.Quotations
open Microsoft.FSharp.Quotations.Typed
open Microsoft.FSharp.Bindings.DLinq
open nwind

let db = new Northwind("Server=.; Database=Northwind; Integrated Security=SSPI")
let custTable = « §db.Customers »

/// Dictionary for getting a 'selector' of a Customer property
/// with key of type string
let dict = 
  Map.of_list
    [ "CompanyName", « fun (c:Customer) -> c.CompanyName »;
      "Country",     « fun c -> c.Country »;
      "ContactName", « fun c -> c.ContactName »; ]
  
/// Function for building a query working with the customer table.
/// Selector is of type 'CustomerPropSelector'
let queryTemplate selector (value:Expr<string>) = 
  custTable |> 
    « { for c in _ do
          let s = (_ c) in
          when (s:string).IndexOf(_:string) <> -1
          -> c } » value selector

/// Utility function to dump a sequence (IEnumerable) of customers
let dump (q:#seq<Customer>) = 
  for c in q do
    Console.WriteLine("{0,-25}{2,10}, {1,-8}{3,-30}", c.CompanyName, c.Country, c.City, c.ContactName)
  Console.ReadLine();

/// Demonstrates the use of 'queryTemplate' function
let simple_demo() =
  Console.Write("Filter - field name (CompanyName, ContactName, Country):\n> ");
  let field = Console.ReadLine();
  Console.Write("Filter - value:\n> ");
  let value = Console.ReadLine();
  
  let q = queryTemplate dict.[field] « §value »
  SQL q |> dump


// Elementary conditions
let falseCond = « fun (c:Customer) -> false »
let trueCond  = « fun (c:Customer) -> true  »

// Condition combinators, declared as infix operators
let (||*) f g = « fun (c:Customer) -> (_ c) || (_ c) » f g
let (&&*) f g = « fun (c:Customer) -> (_ c) && (_ c) » f g

/// Demonstrates the use of combinators
let simplecombine_demo() = 
  let isUk = « fun (c:Customer) -> c.Country = "UK" »
  let isSeattle = « fun (c:Customer) -> c.City = "Seattle" »

  // Build an expression using 'or' combinator
  let expr = isUk ||* isSeattle
  let q = custTable |> « { for c in _ when _ c -> c } » expr
  SQL q |> dump


/// An advanced demo using 'fold' to combine more than 2 conditions
let combining_demo() = 
  Console.Write("Build || or && query (enter 'or' or 'and'):\n> ");
  let generateOr = Console.ReadLine().ToLower() = "or"  

  // Declare infix combinator, depending on an operator we use
  let (^^) = if generateOr then (||*) else (&&*)
  
  // Build the expression by 'folding' all items in dictionary
  let expr = 
    dict.Fold
      // Function to combine key, value & state
      (fun key propSelector e ->
        // Read the value from the user
        Console.Write("Enter value for '{0}':\n> ", key);
        let enteredVal = Console.ReadLine();
        
        // Build a condition testing whether entered value is a substring
        // using 'testTemplate' and combine it with current expression using '^^'
        let currentExpr = 
          « fun (c:Customer) -> ((_ c):string).IndexOf(_:string) <> -1 » 
            propSelector « §enteredVal »
        (currentExpr ^^ e)) 
      // Initial state
      (if generateOr then falseCond else trueCond)
  
  // Dump the results..  
  let q = custTable |> « { for c in _ when _ c -> c } » expr
  SQL q |> dump

combining_demo()