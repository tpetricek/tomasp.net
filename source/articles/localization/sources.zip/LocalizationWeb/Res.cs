using System;
using System.Web;

using System.Threading;
using System.Resources;
using System.Globalization;

namespace LocalizationWeb
{
	/// <summary>
	/// Trida pomoci ktere se bude v aplikaci pristupovat k 
	/// datum ulozenym v resources
	/// </summary>
	public class Res
	{
		#region Static members
		
		/// <summary> Trida pro cteni resources </summary>
		private static ResourceManager _rm;

		/// <summary>
		/// Vytvori tridu ResourceManager. Staci pouze
		/// jedna instance pro celou aplikaci
		/// </summary>
		static Res()
		{
			_rm=new ResourceManager("LocalizationWeb.Texts",
				System.Reflection.Assembly.GetExecutingAssembly());
		}


		/// <summary>
		/// Nastavuje jazyk - ulozi se do cookie
		/// </summary>
		/// <param name="lang">Kod jazyka</param>
		public static void SetLang(string lang)
		{
			HttpCookie ck=new HttpCookie("weblang",lang);
			HttpContext.Current.Request.Cookies.Remove("weblang");
			HttpContext.Current.Request.Cookies.Add(ck);
			HttpContext.Current.Response.Cookies.Add(ck);
		}

		#endregion

		#region Private & Initialization
		
		/// <summary> Urcuje jazyk - pro aktualni Request! </summary>
		private CultureInfo _culture;


		/// <summary>
		/// Vytvari tridu Res - pro aktualni request zjistuje
		/// v jakem jazyce se maji zobrazovat texty (z UserLanguages nebo cookie)
		/// </summary>
		public Res()
		{
			HttpCookie ck=HttpContext.Current.Request.Cookies["weblang"];
			if (ck!=null)
			{
				try
				{
					_culture=new CultureInfo(ck.Value);
				}
				catch {}
			}      
			if (_culture==null)
			{
				try
				{
					_culture=new CultureInfo(HttpContext.Current.Request.UserLanguages[0]);
				}
				catch 
				{
					_culture=Thread.CurrentThread.CurrentUICulture;
				}
			}
		}

		#endregion
		#region Public properties
		
		/// <summary>
		/// Vraci retezec podle klice ve spravnem jazyce 
		/// </summary>
		public string this[string key]
		{
			get { return _rm.GetString(key,_culture); }
		}

		#endregion
	}
}
