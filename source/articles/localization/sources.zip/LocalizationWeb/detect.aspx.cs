using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace LocalizationWeb
{
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblLang;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Ceskym uzivatelum se zobrazi "ahoj svete" ostatnim "hello world"
			foreach(string lang in Request.UserLanguages)
			{
				if (lang=="cs") 
				{
					lblLang.Text="Ahoj sv�te !";
					return;
				}
			}
			lblLang.Text="Hello world !";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
