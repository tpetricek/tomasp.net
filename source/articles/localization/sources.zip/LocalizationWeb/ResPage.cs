using System;

namespace LocalizationWeb
{
	/// <summary>
	/// Bazova trida pro snadny pristup k textum v resources
	/// </summary>
	public class ResPage : System.Web.UI.Page
	{
		/// <summary> Instance tridy Res - aby se nenacitala pokazde znovu </summary>
		private Res _resMgr;

		/// <summary>
		/// Smaze aktualni instanci - takze se pri pristim 
		/// volani Texts nacte znovu (v novem jazyce)
		/// </summary>
		protected void ResetLang()
		{
			_resMgr=null;
		}


		/// <summary>
		/// Vraci tridu pro praci s resources - snadny pristup k textum
		/// pomoci: <% = Texts["key"] %>
		/// </summary>
		public Res Texts
		{
			get 
			{
				if (_resMgr==null) _resMgr=new Res();
				return _resMgr; 
			}
		}
	}
}
