using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace LocalizationWeb
{
	/// <summary>
	/// Stranka na ktere se zadavaji udaje
	/// </summary>
	public class ResDemo : ResPage
	{
		protected System.Web.UI.WebControls.TextBox txtName;
		protected System.Web.UI.WebControls.TextBox txtInfo;
		protected System.Web.UI.WebControls.LinkButton lnkCzech;
		protected System.Web.UI.WebControls.LinkButton lnkEnglish;
		protected System.Web.UI.WebControls.Button btnSubmit;

		/// <summary>
		/// Nastavuje texty ovladacim prvkum na strance
		/// </summary>
		void InitTexts()
		{
			btnSubmit.Text=Texts["submitBtn"];
			lnkCzech.Text=Texts["langCs"];
			lnkEnglish.Text=Texts["langEn"];
		}

		/// <summary>
		/// Pri nacteni nastavi texty..
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			InitTexts();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lnkCzech.Click += new System.EventHandler(this.lnkCzech_Click);
			this.lnkEnglish.Click += new System.EventHandler(this.lnkEnglish_Click);
			this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion


		/// <summary>
		/// Odesle formular - pomoci Server.Transfer zobrazi 'resdemo_view.aspx'
		/// </summary>
		private void btnSubmit_Click(object sender, System.EventArgs e)
		{
			Response.Clear();
			Server.Transfer("resdemo_view.aspx",true);
			Response.End();
		}


		/// <summary>
		/// Prepne jazyk na cestinu a znovu nacte texty pro ovladaci prvky
		/// </summary>
		private void lnkCzech_Click(object sender, System.EventArgs e)
		{
			Res.SetLang("cs");
			ResetLang();
			InitTexts();			
		}

		/// <summary>
		/// Prepne jazyk na anglictinu a znovu nacte texty pro ovladaci prvky
		/// </summary>
		private void lnkEnglish_Click(object sender, System.EventArgs e)
		{
			Res.SetLang("en");
			ResetLang();
			InitTexts();
		}
	}
}
