using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Ink;

namespace TabletPcDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region Generated code

		private System.Windows.Forms.PictureBox drawBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox picColor;
		private System.Windows.Forms.ColorDialog colorDlg;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.drawBox = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.picColor = new System.Windows.Forms.PictureBox();
			this.colorDlg = new System.Windows.Forms.ColorDialog();
			this.SuspendLayout();
			// 
			// drawBox
			// 
			this.drawBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.drawBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.drawBox.Location = new System.Drawing.Point(8, 40);
			this.drawBox.Name = "drawBox";
			this.drawBox.Size = new System.Drawing.Size(400, 300);
			this.drawBox.TabIndex = 0;
			this.drawBox.TabStop = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			this.label1.Text = "Barva:";
			// 
			// picColor
			// 
			this.picColor.BackColor = System.Drawing.Color.Black;
			this.picColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.picColor.Location = new System.Drawing.Point(64, 8);
			this.picColor.Name = "picColor";
			this.picColor.Size = new System.Drawing.Size(64, 24);
			this.picColor.TabIndex = 2;
			this.picColor.TabStop = false;
			this.picColor.Click += new System.EventHandler(this.picColor_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(416, 350);
			this.Controls.Add(this.picColor);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.drawBox);
			this.Name = "Form1";
			this.Text = "Ink demo";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		
		// Objekt pro zachytavani INK dat
		InkCollector col;
		// Bitmapa na kterou se kresli
		Bitmap tmp;

		private void Form1_Load(object sender, System.EventArgs e)
		{
			// Inicializace bitmapy
			tmp=new Bitmap(drawBox.Width,drawBox.Height);
			drawBox.Image=tmp;
			using(Graphics gr=Graphics.FromImage(tmp))
				gr.FillRectangle(Brushes.White,0,0,tmp.Width,tmp.Height);

			// Inicializace objektu pro zachytavani car
			col=new InkCollector(drawBox);
			col.Enabled=true;
			col.Stroke+=new InkCollectorStrokeEventHandler(col_Stroke);
		}

		private void col_Stroke(object sender, InkCollectorStrokeEventArgs e)
		{
			// Ziskat body nakreslene krivky a prevest je na pixely
			Point[] pts=e.Stroke.BezierPoints;
			using(Graphics g=CreateGraphics())
				col.Renderer.InkSpaceToPixel(g,ref pts);

			// Pomoci vybrane barvy vybarvit krivku
			using(Brush br=new SolidBrush(picColor.BackColor))
				using(Graphics gr=Graphics.FromImage(tmp))
					gr.FillClosedCurve(br,pts);

			// Smaze nakreslenou krivku a aktualizuje picture box
			col.Ink.DeleteStrokes();
			drawBox.Refresh();
		}

		private void picColor_Click(object sender, System.EventArgs e)
		{
			if (colorDlg.ShowDialog()==DialogResult.OK)
				picColor.BackColor=colorDlg.Color;
		}
	}
}
