using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DynamicControls
{
	/// <summary>
	/// Priklad na dynamicke pridavani ovladacich prvku
	/// </summary>
	public class Advanced : System.Web.UI.Page
	{
		#region Standardni generovany kod

		protected System.Web.UI.WebControls.TextBox txtName;
		protected System.Web.UI.WebControls.Button btnGenerate;
		protected System.Web.UI.WebControls.PlaceHolder plcChecks;
		protected System.Web.UI.WebControls.Button btnSubmit;
		protected System.Web.UI.WebControls.Label lblSelected;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}


		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		string gen="";

		/// <summary>
		/// Inicializace - pokud uzivatel kliknul na pridat, pridava checkbox
		/// </summary>
		/// <param name="e"></param>
		override protected void OnInit(EventArgs e)
		{
			// Pokud uzivatel kliknul na button
			if (Request.Form["btnGenerate"]!=null)
			{
				// .. a pokud zadal jmeno, tak prida checkbox
				gen=Request.Form["txtName"];
			}
			InitializeComponent();
			base.OnInit(e);
		}
		

		/// <summary>
		/// Nacita nastaveni z view state
		/// </summary>
		protected override void LoadViewState(object savedState)
		{
			object[] vs=(object[])savedState;
			string savedGen=(string)vs[1];
			if (savedGen!="")
			{
				if (gen!="") gen+=";";
				gen+=savedGen;
			}
			if (gen!=""&&gen!=null)
					AddCheckboxes(gen.Split(';'));
			base.LoadViewState(vs[0]);
		}

		/// <summary>
		/// Uklada nastaveni checkboxu do view state
		/// </summary>
		protected override object SaveViewState()
		{
			object[] vs=new object[2];
			vs[0]=base.SaveViewState();
			vs[1]=gen;
			return vs;
		}

		/// <summary>
		/// Pridava checkboxy jejichz jmena dostane v poli
		/// </summary>
		private void AddCheckboxes(string[] names)
		{
			plcChecks.Controls.Clear();
			foreach(string name in names)
			{
				CheckBox check=new CheckBox();
				check.Text=name;
				// zde se generuje ID podle jmena, to je potreba aby si Asp.Net
				// pamatovalo, ktery checkbox je zaskrtnuty
				check.ID=name.Replace(' ','_');
				plcChecks.Controls.AddAt(0,check);

				Literal ltr=new Literal();
				ltr.Text="<br />";
				plcChecks.Controls.AddAt(1,ltr);
			}
		}
		
		
		/// <summary>
		/// Zjistuje jake polozky jsou vybrane
		/// </summary>
		private void btnSubmit_Click(object sender, System.EventArgs e)
		{
			string txt="";
			// prochazi vsechny generovane polozky
			foreach(Control c in plcChecks.Controls)
			{
				CheckBox ch=c as CheckBox;
				// a pokud je to checkbox tak prida jeho jmeno
				if (ch!=null&&ch.Checked) txt+=ch.Text+"; ";
			}
			lblSelected.Text="Vybrane polozky jsou: "+txt;
		}
	}
}
