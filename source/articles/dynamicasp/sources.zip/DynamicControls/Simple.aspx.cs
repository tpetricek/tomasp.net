using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DynamicControls
{
	/// <summary>
	/// Ukazka dynamickeho generovani ovladacich prvku
	/// </summary>
	public class Simple : System.Web.UI.Page
	{
		#region Standardni generovany kod

		protected System.Web.UI.WebControls.PlaceHolder placeCtrls;
		protected System.Web.UI.WebControls.Label lblMessage;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Vytvari dynamicky ovladaci prvky
		/// </summary>
		override protected void OnInit(EventArgs e)
		{
			for(int i=1; i<=5; i++)
			{
				// Vytvori ovladaci prvek..
				Button btn=new Button();
				btn.ID=string.Format("btn{0}",i);
				btn.Text=string.Format("Cudlik {0}",i);
				btn.Click+=new EventHandler(btn_Click);
				// .. a prida ho do placeCtrls
				placeCtrls.Controls.Add(btn);
			}

			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// Kliknuti na tlacitko
		/// </summary>
		private void btn_Click(object sender, EventArgs e)
		{
			// zjistit tlacitko.. a zobrazit zpravu
			Button clicked=(Button)sender;
			lblMessage.Text="Klikli jste na tlacitko: "+clicked.Text;
		}
	}
}
