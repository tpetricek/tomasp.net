<?php

/**
 * Texy! universal text -> html converter
 * --------------------------------------
 *
 * This source file is subject to the GNU GPL license.
 *
 * @author     David Grudl aka -dgx- <dave@dgx.cz>
 * @link       http://texy.info/
 * @copyright  Copyright (c) 2004-2006 David Grudl
 * @license    GNU GENERAL PUBLIC LICENSE v2
 * @package    Texy
 * @category   Text
 * @version    $Revision: 41 $ $Date: 2006-10-07 07:27:24 +0200 (Sat, 07 Oct 2006) $
 */

// security - include texy.php, not this file
/* if (!defined('TEXY')) die(); */




/**
 * IMAGE WITH DESCRIPTION MODULE CLASS
 */
class TexyImageDescModule extends TexyModule
{
    /** @var callback    Callback that will be called with newly created element */
    public $handler;

    public $boxClass   = 'image';        // non-floated box class
    public $leftClass  = 'image left';   // left-floated box class
    public $rightClass = 'image right';  // right-floated box class

    /**
     * Module initialization.
     */
    public function init()
    {
        if ($this->texy->imageModule->allowed)
            $this->texy->registerBlockPattern(
                $this,
                'processBlock',
                '#^'.TEXY_PATTERN_IMAGE.TEXY_PATTERN_LINK_N.'?? +\*\*\* +(.*)<MODIFIER_H>?()$#mU'
            );
    }



    /**
     * Callback function (for blocks)
     *
     *            [*image*]:link *** .... .(title)[class]{style}>
     *
     */
    public function processBlock($parser, $matches)
    {
        list(, $mURLs, $mImgMod1, $mImgMod2, $mImgMod3, $mImgMod4, $mLink, $mContent, $mMod1, $mMod2, $mMod3, $mMod4) = $matches;
        //    [1] => URLs
        //    [2] => (title)
        //    [3] => [class]
        //    [4] => {style}
        //    [5] => >
        //    [6] => url | [ref] | [*image*]
        //    [7] => ...
        //    [8] => (title)
        //    [9] => [class]
        //    [10] => {style}
        //    [11] => >

        $el = new TexyImageDescElement($this->texy);
        $el->modifier->setProperties($mMod1, $mMod2, $mMod3, $mMod4);

        $elImage = new TexyImageElement($this->texy);
        $elImage->setImagesRaw($mURLs);
        $elImage->modifier->setProperties($mImgMod1, $mImgMod2, $mImgMod3, $mImgMod4);

        $el->modifier->hAlign = $elImage->modifier->hAlign;
        $elImage->modifier->hAlign = NULL;

        $content = $el->appendChild($elImage);

        if ($mLink) {
            $elLink = new TexyLinkElement($this->texy);
            if ($mLink == ':') {
                $elImage->requireLinkImage();
                $elLink->link->copyFrom($elImage->linkImage);
            } else {
                $elLink->setLinkRaw($mLink);
            }

            $content = $el->appendChild($elLink, $content);
        }

        $elDesc = new TexyGenericBlockElement($this->texy);
        $elDesc->parse(ltrim($mContent));
        $content .= $el->appendChild($elDesc);
        $el->setContent($content, TRUE);

        if ($this->handler)
            if (call_user_func_array($this->handler, array($el)) === FALSE) return;

        $parser->element->appendChild($el);
    }




} // TexyImageModule














/**
 * HTML ELEMENT IMAGE (WITH DESCRIPTION)
 */
class TexyImageDescElement extends TexyTextualElement
{



    protected function generateTags(&$tags)
    {
        $attrs = $this->modifier->getAttrs('div');
        $attrs['class'] = $this->modifier->classes;
        $attrs['style'] = $this->modifier->styles;
        $attrs['id'] = $this->modifier->id;

        if ($this->modifier->hAlign == TexyModifier::HALIGN_LEFT) {
            $attrs['class'][] = $this->texy->imageDescModule->leftClass;

        } elseif ($this->modifier->hAlign == TexyModifier::HALIGN_RIGHT)  {
            $attrs['class'][] = $this->texy->imageDescModule->rightClass;

        } elseif ($this->texy->imageDescModule->boxClass)
            $attrs['class'][] = $this->texy->imageDescModule->boxClass;

        $tags['div'] = $attrs;
    }



}  // TexyImageDescElement
