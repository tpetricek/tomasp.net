Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub
  Protected WithEvents dropDrag As System.Web.UI.WebControls.DropDownList
  Protected WithEvents Label6 As System.Web.UI.WebControls.Label
  Protected WithEvents btnBob As System.Web.UI.WebControls.Button
  Protected WithEvents btnTwo As System.Web.UI.WebControls.Button
  Protected WithEvents Label5 As System.Web.UI.WebControls.Label
  Protected WithEvents popDocking As System.Web.UI.WebControls.DropDownList
  Protected WithEvents btn4Ever As System.Web.UI.WebControls.Button
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents clrStyle As System.Web.UI.WebControls.DropDownList
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents textTitle As System.Web.UI.WebControls.TextBox
  Protected WithEvents textFull As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents textMsg As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents btnPopup As System.Web.UI.WebControls.Button
  Protected WithEvents popupBob As EeekSoft.Web.PopupWin
  Protected WithEvents popupWin2 As EeekSoft.Web.PopupWin
  Protected WithEvents popupWin As EeekSoft.Web.PopupWin

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    popupBob.Visible = False
    popupWin.Visible = False
    popupWin2.Visible = False
  End Sub

  Private Sub btnPopup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPopup.Click
    popupWin.HideAfter = 5000
    popupWin.Visible = True
    popupWin.Title = textTitle.Text
    popupWin.Message = textMsg.Text
    popupWin.Text = textFull.Text
    popupWin.DragDrop = (dropDrag.SelectedIndex = 0)
    If popDocking.SelectedIndex = 0 Then popupWin.DockMode = EeekSoft.Web.PopupDocking.BottomLeft
    If popDocking.SelectedIndex = 1 Then popupWin.DockMode = EeekSoft.Web.PopupDocking.BottomRight
    popupWin.ColorStyle = Switch(clrStyle.SelectedIndex = 0, EeekSoft.Web.PopupColorStyle.Red, clrStyle.SelectedIndex = 1, EeekSoft.Web.PopupColorStyle.Green, clrStyle.SelectedIndex = 2, EeekSoft.Web.PopupColorStyle.Blue, clrStyle.SelectedIndex = 3, EeekSoft.Web.PopupColorStyle.Violet)
    popupWin2.Visible = False
  End Sub

  Private Sub btn4Ever_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4Ever.Click
    popupWin.HideAfter = -1
    popupWin.Visible = True
    popupWin.Title = textTitle.Text
    popupWin.Message = textMsg.Text
    popupWin.Text = textFull.Text
    popupWin.DragDrop = (dropDrag.SelectedIndex = 0)
    popupWin.DockMode = Switch(popDocking.SelectedIndex = 0, EeekSoft.Web.PopupDocking.BottomLeft, popDocking.SelectedIndex = 0, EeekSoft.Web.PopupDocking.BottomRight)
    popupWin.ColorStyle = Switch(clrStyle.SelectedIndex = 0, EeekSoft.Web.PopupColorStyle.Red, clrStyle.SelectedIndex = 1, EeekSoft.Web.PopupColorStyle.Green, clrStyle.SelectedIndex = 2, EeekSoft.Web.PopupColorStyle.Blue, clrStyle.SelectedIndex = 3, EeekSoft.Web.PopupColorStyle.Violet)
    popupWin2.Visible = False
  End Sub

  Private Sub btnBob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBob.Click
    popupBob.Visible = True
  End Sub

  Private Sub btnTwo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTwo.Click
    btnPopup_Click(sender, e)
    popupWin2.DockMode = popupWin.DockMode
    popupWin2.DragDrop = (dropDrag.SelectedIndex = 0)
    popupWin2.Visible = True
  End Sub
End Class
