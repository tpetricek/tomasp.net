using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using EeekSoft.Web;

namespace EeekSoft.PopupTest
{
	/// <summary>
	/// Testing page...
	/// </summary>
	public class Default : System.Web.UI.Page
	{
    #region Web Form Designer generated code

    protected System.Web.UI.WebControls.Button btnPopup;
    protected System.Web.UI.WebControls.Label Label1;
    protected System.Web.UI.WebControls.TextBox textMsg;
    protected System.Web.UI.WebControls.Label Label2;
    protected EeekSoft.Web.PopupWin popupWin;
    protected System.Web.UI.WebControls.TextBox TextTitle;
    protected System.Web.UI.WebControls.Label Label3;
    protected System.Web.UI.WebControls.TextBox textTitle;
    protected EeekSoft.Web.PopupWin PopupWin1;
    protected System.Web.UI.WebControls.DropDownList clrStyle;
    protected System.Web.UI.WebControls.Label Label4;
    protected System.Web.UI.WebControls.Button btn4Ever;
    protected System.Web.UI.WebControls.DropDownList popDocking;
    protected System.Web.UI.WebControls.Label Label5;
    protected EeekSoft.Web.PopupWin popupWin2;
    protected System.Web.UI.WebControls.Button btnTwo;
    protected System.Web.UI.WebControls.Label lblMsg;
    protected System.Web.UI.WebControls.Button btnBob;
    protected EeekSoft.Web.PopupWin popupBob;
    protected EeekSoft.Web.PopupWinAnchor PopupWinAnchor1;
    protected System.Web.UI.WebControls.HyperLink HyperLink1;
    protected System.Web.UI.WebControls.HyperLink HyperLink2;
    protected System.Web.UI.WebControls.Label Label6;
    protected System.Web.UI.WebControls.DropDownList dropDrag;
    protected System.Web.UI.WebControls.TextBox textFull;
  
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnPopup.Click += new System.EventHandler(this.btnPopup_Click);
			this.btn4Ever.Click += new System.EventHandler(this.btn4Ever_Click);
			this.popupWin2.PopupClosed += new System.EventHandler(this.popupWin2_PopupClose);
			this.popupWin2.LinkClicked += new System.EventHandler(this.popupWin2_LinkClick);
			this.btnTwo.Click += new System.EventHandler(this.btnTwo_Click);
			this.btnBob.Click += new System.EventHandler(this.btnBob_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e)
    {
      lblMsg.Visible=false;
      popupBob.Visible=popupWin2.Visible=popupWin.Visible=false;
    }

    private void btnPopup_Click(object sender, System.EventArgs e)
    {
      popupWin.HideAfter=(sender==null)?-1:5000;
      popupWin.Visible=true;
      popupWin.Title=textTitle.Text;
      popupWin.Message=textMsg.Text;
      popupWin.Text=textFull.Text;
      popupWin.DragDrop=(dropDrag.SelectedIndex==0);
      switch(popDocking.SelectedIndex)
      {
        case 0: popupWin.DockMode=EeekSoft.Web.PopupDocking.BottomLeft; break;
        case 1: popupWin.DockMode=EeekSoft.Web.PopupDocking.BottomRight; break;
      }
      switch(clrStyle.SelectedIndex)
      {
        case 0: popupWin.ColorStyle=EeekSoft.Web.PopupColorStyle.Red;break;
        case 1: popupWin.ColorStyle=EeekSoft.Web.PopupColorStyle.Green;break;
        case 2: popupWin.ColorStyle=EeekSoft.Web.PopupColorStyle.Blue;break;
        case 3: popupWin.ColorStyle=EeekSoft.Web.PopupColorStyle.Violet;break;
      }    
      popupWin2.Visible=false;
    }

    private void btn4Ever_Click(object sender, System.EventArgs e)
    {
      btnPopup_Click(null,null);
    }

    private void btnTwo_Click(object sender, System.EventArgs e)
    {
      btnPopup_Click(sender,e);
      popupWin2.DockMode=popupWin.DockMode;
      popupWin2.DragDrop=(dropDrag.SelectedIndex==0);
      popupWin2.Visible=true;
    }

    private void popupWin2_LinkClick(object sender, System.EventArgs e)
    {
      lblMsg.Text="Hey ! You clicked on link on second popup !!";
      lblMsg.Visible=true;
    }

    private void popupWin2_PopupClose(object sender, System.EventArgs e)
    {
      lblMsg.Text="Hey ! You closed second popup !!";
      lblMsg.Visible=true;
    }

    private void btnBob_Click(object sender, System.EventArgs e)
    {
      popupBob.Visible=true;
      popupBob.DragDrop=(dropDrag.SelectedIndex==0);
    }
	}
}
