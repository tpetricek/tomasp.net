{-# LANGUAGE MultiParamTypeClasses, RankNTypes #-}
{-# LANGUAGE FlexibleInstances, FlexibleContexts, UndecidableInstances #-}

import Control.Arrow
import Data.IORef
import Control.Monad.Trans
import Control.Monad.ST.Trans

-------------------------------------------------------------------------------

class Monad m => MonadAlias m where
  malias :: m a -> m (m a)

-------------------------------------------------------------------------------
-- Monad transformers

newtype CbV m a = CbV { runCbV :: m a }
newtype CbN m a = CbN { runCbN :: m a }
newtype CbL s m a = CbL { unCbL :: STT s m a }

instance Monad m => Monad (CbV m) where
  return v = CbV (return v)
  (CbV a) >>= f = CbV (a >>= (runCbV . f))

instance Monad m => Monad (CbN m) where
  return v = CbN (return v)
  (CbN a) >>= f = CbN (a >>= (runCbN . f))

instance Monad m => Monad (CbL s m) where
  return v = CbL (return v) 
  (CbL a) >>= f = CbL (a >>= (unCbL . f))


instance Monad m => MonadAlias (CbV m) where
  malias m = m >>= (return . return)

instance Monad m => MonadAlias (CbN m) where
  malias m = return m

instance Monad m => MonadAlias (CbL s m) where
  malias (CbL m) = CbL $ do
    r <- newSTRef Nothing
    return $ CbL $ do
      rv <- readSTRef r
      case rv of
        --Nothing -> m >>= \v -> writeSTRef r (Just v) >> return v
        Nothing -> m >>= uncurry (>>) . (writeSTRef r . Just &&& return)
        Just v -> return v

instance MonadTrans CbV where lift = CbV

instance MonadTrans CbN where lift = CbN

instance MonadTrans (CbL s) where
    lift = CbL . lift

runCbL :: Monad m => (forall s. CbL s m a) -> m a
runCbL cm = runST (unCbL cm)

-------------------------------------------------------------------------------
-- Pure sample

lookupInput s = 1

chooseSize :: Int -> Int -> Int
chooseSize fst snd = 
  if fst > 0 then fst else snd

fileSize :: Int  
fileSize =
  let fst = lookupInput "new_size"
      snd = lookupInput "legacy_size"
  in chooseSize fst snd

-------------------------------------------------------------------------------
-- Call-by-alias translation

class (MonadTrans t, MonadAlias (t m)) => AliasMonad t m
instance (MonadTrans t, MonadAlias (t m)) => AliasMonad t m

lookupInput_io :: String -> IO Int
lookupInput_io s = do
  putStrLn ("Reading " ++ s)
  readLn
    
chooseSize_ma :: MonadTrans t => MonadAlias (t IO) => t IO Int -> t IO Int -> t IO Int
chooseSize_ma fst snd = do
  fstVal <- fst
  if fstVal > 0 then fst else snd

fileSize_ma :: MonadTrans t => MonadAlias (t IO) => t IO Int  
fileSize_ma = do
  fst <- malias $ lift (lookupInput_io "new_size")
  snd <- malias $ lift (lookupInput_io "legacy_size")
  chooseSize_ma fst snd

-------------------------------------------------------------------------------

main = do
  putStrLn $ "Original: " ++ show fileSize
  putStrLn $ "\nMalias (CbV):"
  fsn <- runCbV fileSize_ma
  putStrLn $ "... " ++ show fsn

  putStrLn $ "\nMalias (CbN):"
  fsn <- runCbN fileSize_ma
  putStrLn $ "... " ++ show fsn

  putStrLn $ "\nMalias (CbL):"
  fsn <- runCbL fileSize_ma
  putStrLn $ "... " ++ show fsn

