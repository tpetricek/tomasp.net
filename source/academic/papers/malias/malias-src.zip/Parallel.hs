import Control.Monad
import Control.Monad.Par
import Data.Time.Clock (diffUTCTime, getCurrentTime)

-------------------------------------------------------------------------------

class Monad m => MonadAlias m where
  malias :: m a -> m (m a)

instance MonadAlias Par where
  malias p = do
    spawn_ p >>= return . get

-------------------------------------------------------------------------------

fibSeq :: Integer -> Integer
fibSeq 0 = 0
fibSeq 1 = 1
fibSeq n = fibSeq (n-1) + fibSeq (n-2)

-------------------------------------------------------------------------------

timer f = do
  putStrLn "starting..."
  start <- getCurrentTime
  putStrLn $ "Result: " ++ (show f)
  end <- getCurrentTime
  putStrLn $ show (end `diffUTCTime` start) ++ " elapsed."

fibPar n | n < 30 = return $ fibSeq n
fibPar n = do
    n1 <- malias $ fibPar (n - 1)
    n2 <- malias $ fibPar (n - 2)
    liftM2 (+) n1 n2

main = do
  timer (fibSeq 37)
  timer (runPar $ fibPar 37)

  