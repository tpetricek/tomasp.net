import Data.IORef

-- :cd C:\Tomas\Research\Joinads\Haskell.Alias
-- :load Samples.hs
-- :set -XParallelListComp
-- :set -XMonadComprehensions

{-# LANGUAGE ParallelListComp #-}
{-# LANGUAGE MonadComprehensions #-}

-------------------------------------------------------------------------------

class Monad m => MonadAlias m where
  malias :: m a -> m (m a)

-------------------------------------------------------------------------------

newtype CbV m a = CbV (m a)
unCbV (CbV a) = a

instance Monad m => Monad (CbV m) where
  return v = CbV (return v)
  (CbV a) >>= f = CbV (a >>= (unCbV . f))

instance Monad m => MonadAlias (CbV m) where
  malias m = m >>= (return . return)

-------------------------------------------------------------------------------

newtype CbN m a = CbN (m a)
unCbN (CbN a) = a

instance Monad m => Monad (CbN m) where
  return v = CbN (return v)
  (CbN a) >>= f = CbN (a >>= (unCbN . f))

instance Monad m => MonadAlias (CbN m) where
  malias m = return m

-------------------------------------------------------------------------------
-- Silly example

maybeValue = Nothing
  	
assertDefault_cbv cond value = do
  return $ if cond then value else 0

maybeInc_cbv arg = do
  inp <- maybeValue
  res <- assertDefault_cbv (arg == 0) inp
  return $ res + 1


assertDefault_cbn maybeCond value = do
  cond <- maybeCond
  if cond then value else return 0

maybeInc_cbn maybeArg = do
  let inp = maybeValue
  arg <- maybeArg
  res <- assertDefault_cbn (return (arg == 0)) inp
  return $ res + 1

-------------------------------------------------------------------------------

lookupInput s = 1

chooseSize :: Int -> Int -> Int
chooseSize fst snd = 
  if fst > 0 then fst else snd

fileSize :: Int  
fileSize =
  let fst = lookupInput "new_size"
      snd = lookupInput "legacy_size"
  in chooseSize fst snd

-------------------------------------------------------------------------------

lookupInput_io :: String -> IO Int
lookupInput_io s = do
  putStrLn ("Reading " ++ s)
  readLn


-- Call-by-value translation

chooseSize_cbv :: Int -> Int -> IO Int
chooseSize_cbv fst snd = 
  return (if fst > 0 then fst else snd)

fileSize_cbv :: IO Int  
fileSize_cbv = do
  fst <- lookupInput_io "new_size"
  snd <- lookupInput_io "legacy_size"
  chooseSize_cbv fst snd


-- Call-by-name translation

chooseSize_cbn :: IO Int -> IO Int -> IO Int
chooseSize_cbn fst snd = do
  fstVal <- fst
  if fstVal > 0 then fst else snd

fileSize_cbn :: IO Int  
fileSize_cbn = 
  let fst = lookupInput_io "new_size"
      snd = lookupInput_io "legacy_size"
  in chooseSize_cbn fst snd


-- Call-by-alias translation

instance MonadAlias IO where
  -- call-by-name
  -- malias = return

  -- call-by-value
  -- malias m = m >>= (return . return)

  -- call-by-need
  malias m = do
    r <- newIORef Nothing
    return $ do
      rv <- readIORef r
      case rv of
        Nothing -> do
          v <- m
          writeIORef r (Just v)
          return v
        Just a -> return a
    
chooseSize_ma :: IO Int -> IO Int -> IO Int
chooseSize_ma fst snd = do
  fstVal <- fst
  if fstVal > 0 then fst else snd

fileSize_ma :: IO Int  
fileSize_ma = do
  fst <- malias (lookupInput_io "new_size")
  snd <- malias (lookupInput_io "legacy_size")
  chooseSize_ma fst snd

-------------------------------------------------------------------------------

main = do
  putStrLn $ "Original: " ++ show fileSize
  
  putStrLn $ "\nCbv:"
  fsv <- fileSize_cbv
  putStrLn $ "... " ++ show fsv

  putStrLn $ "\nCbn:"
  fsn <- fileSize_cbn
  putStrLn $ "... " ++ show fsn

  putStrLn $ "\nMalias:"
  fsn <- fileSize_ma
  putStrLn $ "... " ++ show fsn
